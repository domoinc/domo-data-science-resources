#----------------#
# LOAD LIBRARIES #
#----------------#

suppressMessages({
    if (!"pacman" %in% rownames(installed.packages())) {
        install.packages("pacman")
    }
    pacman::p_load(
        "corrplot", "dplyr", "fastDummies",
        "fitdistrplus", "SimMultiCorrData",
        "domojupyter", "ggplot2", "reshape2",
        "CatEncoders", "cowplot", "gtools"
    )
})


#----------#
# SETTINGS #
#----------#

options(scipen = 999)
anchor_date <- as.Date("2020-01-01")


#------------------#
# HELPER FUNCTIONS #
#------------------#

undo_dummies <- function(df, cols) {
    for (col in names(cols)) {
        for (c in cols[[col]]) {
            df[, c] <- sapply(df[, c], function(x) if (x == 1) c else "")
        }
        df[, col] <- apply(df[cols[[col]]], 1, paste, collapse = "")
        df[df[, col] == "", col] <- "_OTHER_"
        df <- df[, !(names(df) %in% cols[[col]])]
    }
    df
}
                              
normalize <- function(x) {
    (x - min(x)) / (max(x) - min(x))
}

normalize2 <- function(x) {
    (x - min(x) + 0.0001) / (max(x) - min(x) + 0.0001)
}

unnormalize <- function(x, min, max) {
    (x * (max - min)) + min
}

clip <- function(x, a, b) {
    ifelse(x <= a,  a, ifelse(x >= b, b, x))
}

sort_category_by_corr <- function(df, category, anchor) {
    if (is.null(anchor)) {
        return (unique(df[, category]))
    }
    df <- dummy_cols(df[c(anchor, category)],
                    select_columns = c(category),
                    remove_selected_columns = T)
    r <- as.data.frame(cor(df))
    cats <- names(r[order(r[[anchor]], decreasing = T)][anchor, ])
    cats <- cats[cats != anchor]
    cats <- sapply(cats,
                function(s) substr(s, nchar(category) + 2, nchar(s)))
    cats
}

dummy_ords <- function(df, categories) {
    if (length(categories)) {
        dummy_cols(df,
                select_columns = categories,
                remove_selected_columns = T,
                remove_first_dummy = F)
    } else {
        return(df)
    }
}

as_type <- function(x, type) {
    if (type == "factor") return(as.factor(x))
    if (type == "double") return(as.double(x))
    if (type == "integer") return(as.integer(x))
    if (type == "character") return(as.character(x))
}

                   
#-----------#
# ANONYMIZE #
#-----------#
                              
anonymize <- function(df, dates, categories, anon_categories, n_anon, plot = FALSE) {

    #
    # STEP 1: initial adjustments
    #

    # make sure `df` is a dataframe
    df <- as.data.frame(df)

    # drop NA values and print warning if present
    if (nrow(df) != nrow(na.omit(df))) {
        warning(paste0("data has NA values, dropping via `na.omit`. ",
                    nrow(df), " -> ", nrow(na.omit(df))))
        df <- na.omit(df)
    }

    stdevs <- apply(select_if(df, is.numeric), 2, sd, na.rm = TRUE)
    for (col in names(stdevs)) {
        if (stdevs[[col]] == 0) {
            warning(paste0("StDev(", col, ") = 0, and can't be anomyized. Removing from dataset."))
            df <- df[, !names(df) %in% c(col)]
            dates <- dates[!dates %in% c(col)]
            categories <- categories[!categories %in% c(col)]
            anon_categories <- anon_categories[!anon_categories %in% c(col)]
        }
    }

    # make a copy of the input as `orig_df`
    # that we'll use as the target of anonymization
    orig_df <- df

    #
    # STEP 2: encode and transform columns
    #

    anonymize_values <- list()
    for (col in categories) {
        anonymize_values[[col]] <- col %in% anon_categories
    }

    cont_anchor <- NULL
    numerics <- names(select_if(df, is.numeric))
    if (length(numerics)) {
        for (col in numerics) {
            if (!col %in% categories) {
                cont_anchor <- col
                break
            }
        }
    }

    letters <- permutations(n = 26,
                            r = 2,
                            v = LETTERS,
                            repeats.allowed = TRUE)
    letters <- paste0(letters[, 1], letters[, 2])

    enc1 <- list()
    for (col in categories) {
        i <- 1
        enc <- list()
        df[, col] <- as.character(df[, col])
        for (cat in sort_category_by_corr(df, col, cont_anchor)) {
            enc[[as.character(i)]] <- cat
            df[, col] <- ifelse(df[, col] == cat, letters[i], df[, col])
            i <- i + 1
        }
        enc1[[col]] <- enc
    }

    enc2 <- list()
    for (col in categories) {
        enc <- LabelEncoder.fit(df[, col])
        df[, col] <- transform(enc, df[, col])
        enc2[[col]] <- enc
    }

    for (col in dates) {
        df[, col] <- as.Date(df[, col])
    }

    for (col in categories) {
        df[, col] <- as.ordered(df[, col])
    }

    categories <- names(select_if(df, is.ordered))
    dates <- names(select_if(df, function(x) inherits(x, "Date")))

    # convert date columns to a continuous range by subtracting
    # a fixed date and converting the diff to a number
    for (dcol in dates) {
        df[, dcol] <- as.numeric(df[, dcol] - anchor_date)
    }


    #
    # STEP 3: find best dist for continuous vars
    #

    fits <- list()
    continuous <- names(select_if(df, is.numeric))

    for (ccol in continuous) {
        x <- normalize2(df[[ccol]])
        min_aic <- Inf
        best_dist <- NA
        dists <- c("norm", "unif")
        for (dist in dists) {
            tryCatch({
                fit <- fitdist(x, dist)
                # cat(ccol, " ", dist, " ", fit$aic, "\n") 
                if (fit$aic < min_aic) {
                    min_aic <- fit$aic
                    best_dist <- dist
                }
            }, error = function(e) {})
        }

        fit <- fitdist(x, best_dist)
        fits[[ccol]] <- list(dist = best_dist,
                            params = as.numeric(fit$estimate))
        # cat("***", ccol, " ", best_dist, "\n\n")
    }


    #
    # STEP 4: build data blueprint
    #

    # re-order columns so ordinal is first,
    # which is what `rcorrvar` expects
    df <- df[append(categories, continuous)]

    # we need to map the dist names we used in the 
    # fit eval to the names that `calc_theory` uses
    dist_map <- list(
        "norm" = "Gaussian",
        "unif" = "Uniform",
        "beta" = "Beta"
    )

    # ordinal vars (categorical)
    i <- 1
    categorical <- list()
    for (col in categories) {
        o <- as.numeric(table(df[, col]) / nrow(df))
        for (j in seq(2, length(o))) {
            o[j] <- o[j] + o[j - 1]
        }
        categorical[[i]] <- o[1:length(o) - 1]
        df[, col] <- as.numeric(df[, col])
        i <- i + 1
    }
    ncat <- length(categorical)


    # continuous vars
    cont <- data.frame()
    for (ccol in continuous) {
        row <- round(calc_theory(Dist = dist_map[[fits[[ccol]]$dist]],
                                params = fits[[ccol]]$params), 4)
        cont <- rbind(cont, row)
    }
    names(cont) <- names(row)
    cont <- t(cont)
    ncont <- ncol(cont)

    # correlation matrix `rho`
    df_cor <- cor(df)


    #
    # STEP 5: create anonymized data
    #

    # hide the long output
    invisible(capture.output(
        anon <- rcorrvar(
            n = n_anon,
            k_cat = ncat,
            k_cont = ncont,
            method = "Polynomial",
            means = cont[1, ],
            vars = cont[2, ]^2,
            skews = cont[3, ],
            skurts = cont[4, ],
            fifths = cont[5, ],
            sixths = cont[6, ],
            marginal = categorical,
            rho = df_cor
        )
    ))

    anon_df <- data.frame(
        matrix(nrow = n_anon, ncol = 0)
    )

    if ("ordinal_variables" %in% names(anon)) {
        anon_df <- cbind(anon_df, anon$ordinal_variables)
    }

    if ("continuous_variables" %in% names(anon)) {
        anon_df <- cbind(anon_df, anon$continuous_variables)
    }

    names(anon_df) <- names(df)


    #
    # STEP 6: reverse transformations
    #

    # decode the feature with the 2nd-stage encoder if the
    # user indicated this feature's values should be anonymized,
    # otherwise, use the 1st-stage encoder which transforms
    # it back to the original category values
    for (col in categories) {
        if (anonymize_values[[col]]) {
            anon_df[, col] <- inverse.transform(enc2[[col]], anon_df[, col])
        } else {
            for (key in names(enc1[[col]])) {
                anon_df[, col] <- ifelse(anon_df[, col] == key,
                                        enc1[[col]][[key]],
                                        anon_df[, col])
            }
        }
    }

    # unnormalize the continuous columns data, then clip and
    # cast the data to match the source
    for (ccol in continuous) {
        anon_df[, ccol] <- unnormalize(anon_df[, ccol],
                                    min(df[, ccol]),
                                    max(df[, ccol]))
        anon_df[, ccol] <- clip(anon_df[, ccol],
                            min(df[, ccol]),
                            max(df[, ccol]))
        if (class(df[, ccol]) == "integer") {
            anon_df[, ccol] <- as.integer(anon_df[, ccol])
        }
    }

    # undo the date tranformation and covert to a date
    for (col in dates) {
        anon_df[, col] <- as.Date(anon_df[, col] + anchor_date)
    }

    # order columns to match the source
    tryCatch({
        anon_df <- anon_df[names(orig_df)]
    }, error = function(e) {
        cat("ERROR: Missing columns! Check your configuration and\n")
        cat("  make sure all columns in `df` can be anonymized\n")
        message(e)
    }, finally = {})

    # cast anon types to match orig
    types <- sapply(orig_df, typeof)
    ntypes <- names(types)
    for (i in seq(1, length(types))) {
        if (is.factor(orig_df[, ntypes[i]])) {
            types[i] <- "factor"
        }
        anon_df[, ntypes[i]] <- as_type(anon_df[, ntypes[i]], types[i])
    }

    if (plot) {
        comp_plots(orig_df, anon_df)
    }

    return(anon_df)
}
                             
comp_plots <- function(orig_df, anon_df) {
    orig_df2 <- dummy_ords(orig_df, categories)
    orig_df2 <- select_if(orig_df2, is.numeric)
    anon_df2 <- dummy_ords(anon_df, categories)
    anon_df2 <- select_if(anon_df2, is.numeric)

    orig_df3 <- melt(round(cor(orig_df2), 2))
    c1 <- ggplot(orig_df3, aes(Var1, Var2, fill = value)) +
        geom_tile(color = "white") +
        scale_fill_gradient2(
            low = "#ff3300", high = "#339933", mid = "white",
            midpoint = 0, limit = c(-1, 1)) +
        guides(fill = "none") +
        theme_minimal() +
        theme(
            axis.text.x = element_text(angle = 45, vjust = 1, size = 12, hjust = 1),
            axis.text.y = element_text(angle = 0, vjust = 1, size = 12, hjust = 1),
            axis.title.x = element_blank(),
            axis.title.y = element_blank(),
            plot.title = element_text(face = "bold", colour = "black", size = 24)
        ) +
        labs(title = "Original Correlations") +
        coord_fixed() +
        geom_text(aes(Var2, Var1, label = value), color = "black", size = 4)

    anon_df3 <- melt(round(cor(anon_df2), 2))
    c2 <- ggplot(anon_df3, aes(Var1, Var2, fill = value)) +
        geom_tile(color = "white") +
        scale_fill_gradient2(
            low = "#ff3300", high = "#339933", mid = "white",
            midpoint = 0, limit = c(-1, 1)) +
        guides(fill = "none") +
        theme_minimal() +
        theme(
            axis.text.x = element_text(angle = 45, vjust = 1, size = 12, hjust = 1),
            axis.text.y = element_text(angle = 0, vjust = 1, size = 12, hjust = 1),
            axis.title.x = element_blank(),
            axis.title.y = element_blank(),
            plot.title = element_text(face = "bold", colour = "black", size = 24)
        ) +
        labs(title = "Anonymized Correlations") +
        coord_fixed() +
        geom_text(aes(Var2, Var1, label = value), color = "black", size = 4)

    # orig_w <- getOption("repr.plot.width")
    # orig_h <- getOption("repr.plot.height")
    options(repr.plot.width = 15)
    options(repr.plot.height = 8)

    p <- plot_grid(c1, c2)
    print(p)

    d1 <- melt(orig_df2, id.vars = c())
    d2 <- melt(anon_df2, id.vars = c())

    d1$set <- "Original"
    d2$set <- "Anonymized"

    d <- rbind(d1, d2)
    n <- length(unique(d$variable))
    r <- ((n - 1) %/% 4) + 1

    options(repr.plot.width = 18)
    options(repr.plot.height = r * 4)

    p <- ggplot(d, aes(x = value, fill = set)) +
        facet_wrap(~variable, scales = "free", ncol = 4) +
        geom_histogram(aes(y = ..density..), bins = 20,
                       position = "identity", alpha = 0.5) +
        scale_fill_manual(values = c("red2", "blue2"), name = "dataset") +
        theme_minimal() +
        labs(title = "Feature Distributions") +
        theme(plot.title = element_text(face = "bold",
                                        colour = "black",
                                        size = 24)) +
        theme(strip.text.x = element_text(size = 12, colour = "black", angle = 0)) +
        theme(panel.spacing = unit(1, "cm"))
    print(p)

    options(repr.plot.width = 18)
    options(repr.plot.height = r * 4)

    p <- ggplot(d, aes(x = value, fill = set)) +
        facet_wrap(~variable, scales = "free", ncol = 4) +
        geom_density(alpha = 0.2) +
        scale_fill_manual(values = c("red2", "blue2"), name = "dataset") +
        theme_minimal() +
        labs(title = "")
        theme(plot.title = element_text(face = "bold", 
                                        colour = "black",
                                        size = 24)) +
        theme(strip.text.x = element_text(size = 12, colour = "black", angle = 0)) +
        theme(panel.spacing = unit(1, "cm"))
    print(p)
}