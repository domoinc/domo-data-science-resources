# Anonymizer Help

<!--

    Right-Click > Open With > Markdown Preview

-->

<br>

### Usage

1. Initialize the following variables:
    * `df` 🠤 the dataset you wish to anonymize. you can load this via `domojupyter` or `read.csv`
        * make sure all the columns in `df` are configured for anonymization. drop unnecessary columns after loading in the dataset to avoid any issues
    * `dates` 🠤 date-type columns
    * `categories` 🠤 categorical columns
        * Multi-class categories need to be a single column, NOT DUMMY / ENCODED COLUMNS!
        * If your mulit-class categories are dummy-ied / encoded values, use the `undo_dummies(...)` to undo the endcoding (see Example 2)
    * `anon_categories` 🠤 the categorical columns which values should stay anonymized (see Example 3)
    * `n_anon` 🠤 the number of rows you want in the anonymized (output) dataset
2. Run the `anonymize` function
3. Export the anonymized dataset (via `domojupyter` or `write.csv`)

<br>

### Notes

* The anonymizer doesn't fit bimodal distributions very well

<br>

### Examples

#### **Example 1**

Given the following dataset:

```
+---------+-----+--------+-------------+--------+------------+
| charges | bmi | smoker | gender_male | region | last_visit |
+---------+-----+--------+-------------+--------+------------+
|  33467  | 37  |  yes   |      1      |   SE   | 2017-07-23 |
|   5023  | 20  |  yes   |      1      |   NW   | 2020-03-30 |
|   6713  | 24  |   no   |      0      |   NE   | 2018-01-31 |
|  10056  | 21  |   no   |      1      |   SE   | 2021-06-02 |
+---------+-----+--------+-------------+--------+------------+
```

You might consider using the following configuration:

```r
df <- read.csv("charges.csv")
dates <- c("last_visit")
categories <- c("smoker", "gender_male", "region")
anon_categories <- c()
n_anon <- nrow(df)
```

<br>

#### **Example 2**

The anonymizer needs multi-class categorical variables to be in a single column, so if your dataset's multi-class vars are already one-hot-encoded, you'll need to collapse those features to a single column. For example, if your data looked something like this, you will want to use the `undo_dummies` function (defined in the notebook) to collapse the columns:

```
+---------+-----+------------+-----------+-----------+------------+
| charges | bmi | smoker_yes | region_NE | region_SE | last_visit |
+---------+-----+------------+-----------+-----------+------------+
|  33467  | 37  |      1     |     1     |     0     | 2017-07-23 |
|   5023  | 20  |      1     |     0     |     0     | 2020-03-30 |
|   6713  | 24  |      0     |     0     |     1     | 2018-01-31 |
|  10056  | 21  |      0     |     0     |     0     | 2021-06-02 |
+---------+-----+------------+-----------+-----------+------------+
```

```r
df <- read.csv("charges_dummies.csv")

# `smoker_yes` is a binary category, so its encoding
# doesn't need to be reversed
df <- undo_dummies(df,
                   list(region = c("region_NE", "region_SE")))

dates <- c("last_visit")
categories <- c("smoker_yes", "region")
anon_categories <- c()
n_anon <- nrow(df)
```

**NOTE:** If you don't collapse the multi-class categorical columns, and simply pass each dummied-feature to the `categories` input variable, the anonymizer will work for the most part, but there isn't a guarantee that the final encoded values with by mutually exclusive

<br>

#### **Example 3**

By default, the anonymized output will match the category values to the original set. Given this dataset, you might want to hide the actual `store` names in the output dataset:

```
+---------+--------+--------+
| revenue |  cogs  | store  |
+---------+--------+--------+
|  13486  |  7215  | SLC    |
|  78468  | 39754  | Draper |
|  64214  | 32658  | Murray |
|  34519  | 17548  | Provo  |
+---------+--------+--------+
```

The following configuration (namely the `anon_categories`) solves this issue:

```r
df <- read_dataframe("Store Sales")
dates <- c()
categories <- c("store")
anon_categories <- c("store")
n_anon <- 500
```
