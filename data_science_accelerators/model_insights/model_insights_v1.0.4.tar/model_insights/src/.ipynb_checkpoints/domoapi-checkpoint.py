import os
import gzip
from getpass import getpass
from io import StringIO
from time import sleep
from typing import Tuple

import pandas as pd
import requests
from requests import Response


class DomoAPI:
    """
    Interact with Domo via the "unofficial" API!

    Unofficial? Yes, the "official" API uses OAuth for authentication
    and documentation can be found @ developer.domo.com. It's great
    for creating/updating datasets and some other basic instance mgmt
    tasks. But...it can't be used for creating pages and cards (and a
    few other things you might want to automate!)

    That's where DomoAPI comes in! After authenticating with your
    username/password, a session cookie, or a access token, this library
    provides numerous functions interacting with your Domo instance.

    NOTE: A few of the core functions used in this class were borrowed from
    Domo's `domojupyter` library. Thanks!
    """

    #
    # AUTH INTERNALS
    #

    def __init__(
        self,
        instance: str,
        username: str = '',
        password: str = '',
        access_token: str = '',
        session_cookie: str = '',
    ):
        self.instance = instance
        self.api_base = 'https://' + instance + '.domo.com/api'
        self.auth_headers = {}

        if username:
            self._login_password(username, password)
        elif access_token:
            self._login_token(access_token)
        elif session_cookie:
            self._login_cookie(session_cookie)

    def _login_password(self, username: str, password: str='') -> None:
        if not password:
            password = getpass('Password: ')

        data = {
            'method': 'password',
            'emailAddress': username,
            'password': password
        }

        r = self._post(f'{self.api_base}/content/v2/authentication', data)
        if r.status_code == 200 and r.json()['success']:
            self.auth_headers = {
                'X-Domo-Authentication': r.json().get('sessionToken'),
            }
        else:
            raise Exception('Authentication error! Check your credentials.')

    def _login_token(self, token: str) -> None:
        self.auth_headers = {'X-DOMO-Developer-Token': token}

    def _login_cookie(self, cookie: str) -> None:
        self.auth_headers = {'X-Domo-Authentication': cookie}

    
    #
    # REQUEST INTERNALS
    #

    def _add_auth_headers(self, headers: dict) -> dict:
        return {**headers, **self.auth_headers}

    def _get(self, url: str, headers={'Accept': 'application/json'}) -> Response:
        headers = self._add_auth_headers(headers)
        return requests.get(url, headers=headers, timeout=10)

    def _put(self, url: str, data, headers={'Accept': 'application/json'}) -> Response:
        headers = self._add_auth_headers(headers)
        return requests.put(url, json=data, headers=headers, timeout=10)

    def _put_bytes(self, url: str, data, headers: dict={'Accept': 'application/json'}, params: dict={}) -> Response:
        headers = self._add_auth_headers(headers)
        return requests.put(url, data=data, headers=headers, params=params, timeout=10)

    def _post(self, url: str, data, headers={'Accept': 'application/json'}) -> Response:
        headers = self._add_auth_headers(headers)
        return requests.post(url, json=data, headers=headers, timeout=10)

    def _post_file(self, url: str, files: list, headers={'Accept': 'application/json'}) -> Response:
        headers = self._add_auth_headers(headers)
        return requests.post(url, files=files, headers=headers, timeout=10)

    def _delete(self, url: str, headers: dict={'Accept': 'application/json'}) -> Response:
        headers = self._add_auth_headers(headers)
        return requests.delete(url, headers=headers, timeout=10)

    
    #
    # MISC INTERNALS
    #

    def _convert_type(self, df_type: str) -> str:
        if df_type == 'object':
            return 'STRING'
        elif df_type == 'category':
            return 'STRING'
        elif df_type == 'int64':
            return 'LONG'
        elif df_type == 'float64':
            return 'DOUBLE'
        elif df_type == 'bool':
            return 'LONG'
        elif df_type == 'datetime64' or df_type == 'datetime64[ns]':
            return 'DATETIME'
        return 'STRING'

    def _convert_type_read(self, schema_type: str) -> str:
        if schema_type == 'STRING':
            return 'object'
        elif schema_type == 'LONG':
            return 'int64'
        elif schema_type == 'DOUBLE':
            return 'float64'
        elif schema_type == 'LONG':
            return 'bool'
        elif schema_type == 'DATETIME':
            return 'datetime64'
        elif schema_type == 'DATE':
            return 'datetime64'
        elif schema_type == 'DECIMAL':
            return 'float64'
        else:
            return 'object'

    def _build_schema(self, df: pd.DataFrame) -> dict:
        columns = [{'name': column, 'type': self._convert_type(
            df.dtypes[ind].name)} for ind, column in enumerate(df.columns)]
        return {'columns': columns}

    def _get_schema(self, dsid: str) -> list:
        url = f'{self.api_base}/query/v1/datasources/{dsid}/schema/indexed'
        headers = {
            'Accept': 'application/json'
        }
        r = self._get(url, headers)
        schema = r.json()
        if r.status_code != 200 or schema is None:
            raise Exception(f'Failed to obtain schema {r.json()}')

        return [{'name': col.get('name'), 'type': col.get('type')} for col in schema['tables'][0]['columns']]

    def _init_brick(self, brick_id: str, page_id: int) -> Tuple[int, str]:
        """
        INTERNAL method for initializing a Brick. It's only used by the `create_brick`
        method, but is kept separate cause it's a bit messy

        Args:
            brick_id (str): Brick ID as listed in the Domo AppStore
            page_id (str): Page ID where the Brick will reside

        Returns:
            2-element tuple
            **card_id** *(int)*: Card ID
            **app_domain** *(str)*: App Domain where this card can be accessed
        """
        
        data = {
            "appId": brick_id,
            "appType": "card",
            "appDeploymentType": {
                "deploymentType": "sample_data_deploy"
            },
            "userSpecifiedAppTitle": "DDX Blank",
            "parentPageId": page_id,
        }

        resp = self._post(f'{self.api_base}/library/v3/apps/deployments', data)

        card_id = resp.json()['installedId']
        app_id = list(resp.json()['deployedDomoApps'].values())[0]

        #
        # after making the card, we need to make this POST
        # to create the document (which we'll post to again with code)
        #
        # this is also a good time to find the app domain. TODO get some
        # more details on this if possible, cause I'm making quite a bit of
        # assumptions here, and since there is no way (AFAIK) to find this
        # via API, we're just gonna do the ol' guess-n-check
        #
        prod_id = 1
        max_prod_id = 8
        app_domain = ''
        for prod_id in range(1, max_prod_id + 1):
            resp = self._post(
                f'https://{app_id}.domoapps.prod{prod_id}.domo.com/domo/datastores/v1/collections/ddx_app_client_code/documents/',
                {'content': {"htmlBlank": {"js": "", "html": "", "css": "", }}},
            )
            if resp.status_code == 200:
                app_domain = f'{app_id}.domoapps.prod{prod_id}.domo.com'
                break

        if prod_id >= max_prod_id:
            raise Exception('Unable to find App Domain')

        return (card_id, app_domain)
    
    def _add_image(self, filepath, page_id):
        filename = os.path.basename(filepath)
        files = [
            ('file', ('image.jpg', open(filepath, 'rb'), 'image/jpeg'))
        ]
        r = self._post_file(f'{self.api_base}/data/v1/data-files', files)
        file_id = r.json()['dataFileId']
        data = {
            "type": "document",
            "description": filename,
            "metadata": {
                "title": filename,
                "documentId": f"{file_id}:undefined",
                "usingSampleData": "",
                "kpiType": "document",
                "description": filename
            }
        }
        r = self._post(f'{self.api_base}/content/v1/cards?pageId={page_id}', data)
        return int(r.json()['urn'])

    def _create_or_update(self, df, name, dsid: str) -> str:
        """
        
        """
        
        if dsid:
            self.write_dataset(df, dsid=dsid)
        else:
            dsid = self.write_dataset(df, name=name)
        return dsid

    def _save_page_filter(self, data, page_id, default=True) -> None:
        r = self._post(f'{self.api_base}/content/v3/pages/{page_id}/analyzer', data)
        analyzer_id = r.json()['analyzerId']
        if default:
            self._put(f'{self.api_base}/content/v3/pages/{page_id}/analyzer/{analyzer_id}/global', {})
    

    #
    # PAGES
    #

    def get_dashboard_layout_id(self, page_id: int) -> int:
        """
        Get the layout ID for a page/dashboard

        Args:
            page_id (int): Page ID

        Returns:
            **layout_id** *(int)*: Layout ID
        """
        
        r = self._post(f'{self.api_base}/content/v4/pages/{page_id}/layouts/convert/flowToLayout', {})
        
        #
        # i'm not sure how to find the layout_id except when converting a standard page to 
        # a design dashboard. so in the case when the page is already a design dashboard,
        # we convert it back to a standard page (layout -> flow), then take it back to a design
        # (flow -> layout) to get the layout_id
        #
        if r.status_code != 200:
            self._post(f'{self.api_base}/content/v4/pages/{page_id}/layouts/convert/layoutToFlow', {})
            sleep(3)
            r = self._post(f'{self.api_base}/content/v4/pages/{page_id}/layouts/convert/flowToLayout', {})
        
        return r.json()['layoutId']

    def set_dashboard_layout(self, layout_id: int, data: dict) -> None:
        """
        Set the layout for a dashboard

        Args:
            layout_id (int): Layout ID
            data (dict): JSON definition of the layout
        """
        
        self._put(f'{self.api_base}/content/v4/pages/layouts/{layout_id}/writelock', {})
        self._put(f'{self.api_base}/content/v4/pages/layouts/{layout_id}', data)
        self._delete(f'{self.api_base}/content/v4/pages/layouts/{layout_id}/writelock', {})

    def create_page(self, page_name: str, parent_page_id: int=0) -> int:
        """
        Create a new page

        Args:
            page_name (str): Page name
            parent_page_id (int): Optional. Provide this parameter to create a new subpage, otherwise create a top-level page

        Returns:
            **page_id** *(int)*: Page ID of the newly created page
        """
        
        data = {
            'parentPageId': parent_page_id,
            'title': page_name
        }
        r = self._post(f'{self.api_base}/content/v1/pages?layout=false', data)
        
        if r.status_code == 200:
            return r.json()['pageId']
        else:            
            raise Exception('Unable to create page!')


    #
    # CARDS
    #

    def build_card(self, data, page_id: int=-100000) -> int:
        """
        Build a card

        Args:
            data (dict): JSON definition of the card
            page (int): Optional. Page ID where the card will reside (defaults to Overview)

        Returns:
            **card_id** *(int)*: Card ID
        """
        
        r = self._put(f'{self.api_base}/content/v3/cards/kpi?pageId={page_id}', data)

        if r.status_code == 200:
            return r.json()['id']
        else:
            print(r.status_code)
            print(r.text)
            raise Exception('Error making card')

    def delete_card(self, card_id: int) -> None:
        self._delete(f'{self.api_base}/content/v2/badges/{card_id}')

    def create_notebook_card(self, page_id: int, html: str, markup: str) -> int:
        """
        Create a notebook card

        Args:
            card_id (int): Page ID
            html (str): HTML content
            markup (str): Markup content

        Returns:
            **card_id** *(int)*: Card ID
        """
        
        resp = self._post(
            f'{self.api_base}/content/v1/cards/notebook',
            {
                "text": "",
                "title": "Notebook Card",
                "encoding": "html",
                "dataFileIds": [],
                "pageId": page_id,
                "markup": "",
                "version": "v3"
            }
        )

        card_id = resp.json()['id']
        self.update_notebook_card(card_id, html, markup)

        return card_id

    def update_notebook_card(self, card_id: int, html: str, markup: str):
        """
        Update a notebook card

        Args:
            card_id (int): Card ID
            html (str): HTML content
            markup (str): Markup content
        """
        
        self._post(
            f'{self.api_base}/content/v1/cards/notebook/{card_id}/update',
            {
                "id": card_id,
                "markup": markup,
                "textHtml": html,
                "dynamicTextItems": {},
                "subscriptions": [],
                "formulas": []
            }
        )

    def create_brick(self, dsid: str, page_id: int, js: str='', html: str='', css: str='') -> Tuple[int, str]:
        """
        Create a Brick (custom card using HTML/JS/CSS). Bricks can support multiple datasets,
        but this function currently only supports a single dataset.

        Args:
            dsid (str): Dataset ID
            page_id (str): Page ID where the Brick will reside
            js (str): Optional. JavaScript for the Brick
            html (str): Optional. HTML for the Brick
            css (str): Optional. CSS for the Brick

        Returns:
            2-element tuple
            **card_id** *(int)*: Card ID
            **app_domain** *(str)*: App Domain where this card can be accessed
        """
        
        # Blank Brick
        brick_id = '13C84724BDB6BA1E76B352FE2EBF99E2266F982E982C940B0968FC615CD99338'
        card_id, app_domain = self._init_brick(brick_id, page_id)
        app_id = app_domain.split('.')[0]

        # get app context
        r = self._put(f'https://{self.instance}.domo.com/domoapps/apps/v2/{app_id}?fullpage=false&cardTitle=DDX Blank', {})
        context = r.json()['context']
        
        context_id = context['id']
        template_id = context['mapping'][0]['dataSetId']

        context['mapping'][0]['datasetId'] = dsid
        context['mapping'][1]['datasetId'] = dsid
        context['mapping'][2]['datasetId'] = dsid
        self._put(f'https://{self.instance}.domo.com/domoapps/apps/v2/contexts/{context_id}', context) 

        # get app doc id
        while True:
            resp = self._get(f'https://{app_domain}/domo/datastores/v1/collections/ddx_app_client_code/documents').json()
            if len(resp):
                break
            sleep(5)
        doc_id = resp[0]['id']

        data = {
            'content': {
                "htmlBlank": {
                    "html": html,
                    "js": js,
                    "css": css,
                }
            }
        }

        self._put(
            f'https://{app_domain}/domo/datastores/v1/collections/ddx_app_client_code/documents/{doc_id}',
            data,
            {'origin': f'https://{app_domain}'}
        )

        # delete those temp datasets AFTER our datasets have been updated
        sleep(10)
        self.delete_dataset(template_id, confirm=True)
        
        return (card_id, app_domain)

    
    #
    # DATASETS
    #

    def read_dataset(self, dsid: str, limit: int = 0, query: str='SELECT * FROM table', **kwargs) -> pd.DataFrame:
        """
        Read a dataset

        Args:
            dsid (str): Dataset ID
            limit (int): Optional, row limit
            query (str): Optional, SQL query

        Returns:
            **df** *(pd.DataFrame)*: Domo dataset as a Pandas DataFrame
        """
        
        if limit:
            query += f' LIMIT {limit}'

        url = f'{self.api_base}/query/v1/execute/export/{dsid}'
        body = {'sql': query}
        r = self._post(url, body, headers={'Accept': 'text/csv,application/json;q=0.1'})
        data = r.content.decode('utf-8')

        schema = self._get_schema(dsid)

        column_types = []
        date_cols = []
        type_dict = {}
        header = pd.read_csv(StringIO(data), index_col=False, header=0, nrows=0).columns.tolist()
        user_dtype = False
        user_parse_date = False

        for cols in schema:
            column_types.append(list(cols.values()))

        if kwargs:
            for key in kwargs.keys():
                if key == 'dtype':
                    user_dtype = True
                elif key == 'parse_dates':
                    user_parse_date = True

        for cols in column_types:
            column_name = cols[0]
            if column_name in header:
                dtype = self._convert_type_read(cols[1])
                if dtype == 'datetime64' and not user_parse_date:
                    date_cols.append(column_name)
                elif not user_dtype:
                    type_dict[column_name] = dtype

        if date_cols:
            kwargs['parse_dates'] = date_cols

        if type_dict:
            kwargs['dtype'] = type_dict

        return pd.read_csv(StringIO(data), **kwargs)

    def write_dataset(self, df: pd.DataFrame, name: str='', dsid: str='') -> str:
        """
        Create or update a dataset

        Args:
            df (pd.DataFrame): Dataframe
            name (str): Provide a dataset nane to create a new dataset
            dsid (str): Provide the dataset ID to update a dataset

        Returns:
            **dsid** *(str)*: Dataset ID
        """
        
        if not name and not dsid:
            raise ValueError

        if name:
            payload = {
                "transport": {
                    "type": "API",
                },
                "dataSource": {
                    "name": name,
                    "description": "",
                },
                "dataProvider": {
                    "key": "api",
                    "name": "api"
                },
                "schemaDefinition": self._build_schema(df)
            }
            resp = self._post(f'{self.api_base}/data/v1/streams', payload)
            dsid = resp.json()['dataSource']['id']

        gz_csv = gzip.compress(bytes(df.to_csv(index=False), 'utf-8'))

        # TODO implement chunks / parts

        # find the stream
        stream_search_url = f'{self.api_base}/data/v1/streams/search?q=dataSource.id:{dsid}'
        stream_id = self._get(stream_search_url).json()[0]['id']

        # start the execution
        start_exec_url = f'{self.api_base}/data/v1/streams/{stream_id}/executions'
        exec_id = self._post(start_exec_url, {}).json()['executionId']

        # upload the data
        upload_part_url = f'{self.api_base}/data/v1/streams/{stream_id}/executions/{exec_id}/part/1'
        resp = self._put_bytes(upload_part_url, gz_csv)

        # commit the stream
        commit_stream_url = f'{self.api_base}/data/v1/streams/{stream_id}/executions/{exec_id}/commit'
        resp = self._put(commit_stream_url, {})

        return dsid

    def delete_dataset(self, dsid: str, confirm: bool = False):
        """
        Delete a dataset

        Args:
            dsid (str): Dataset ID
            confirm (bool): Optional (well, kinda). As a safety measure, this must be set to `True` to delete the dataset
        """
       
        if confirm:
            self._delete(f'{self.api_base}/data/v3/datasources/{dsid}?deleteMethod=hard')
        else:
            raise Exception('Refusing to delete dataset without `confirm=True` parameter')