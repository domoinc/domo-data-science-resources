import numpy as np
import pandas as pd
from collections import Counter
from typing import Union

def calculate_psi(expected: Union[pd.DataFrame, pd.Series], actual: Union[pd.DataFrame, pd.Series], buckets=10):
    '''
    Authors:
        - (original)    Matthew Burke, github.com/mwburke, worksofchart.com 
        - (inspiration) https://www.giskard.ai/knowledge/how-to-test-ml-models-2-n-categorical-data-drift
        - (additions)   Davis Busteed
    '''

    min_prob = 0.0001

    def _psi(e_perc: float, a_perc: float):
        a_perc = max(a_perc, min_prob)
        e_perc = max(e_perc, min_prob)
        value = (e_perc - a_perc) * np.log(e_perc / a_perc)
        return value

    def numeric_psi(feature, expected_array, actual_array, buckets):
        def scale_range(arr, minn, maxx):
            arr += -(np.min(arr))
            arr /= np.max(arr) / (maxx - minn)
            arr += minn
            return arr

        breakpoints = np.arange(0, buckets + 1) / (buckets) * 100
        breakpoints = scale_range(breakpoints, np.min(expected_array), np.max(expected_array))

        expected_percents = np.histogram(expected_array, breakpoints)[0] / len(expected_array)
        actual_percents = np.histogram(actual_array, breakpoints)[0] / len(actual_array)

        df = pd.concat([
            pd.DataFrame({'feature': feature, 'sample': 'Training',
                         'group': breakpoints[:-1], 'perc': expected_percents}),
            pd.DataFrame({'feature': feature, 'sample': 'Scoring',
                         'group': breakpoints[:-1], 'perc': actual_percents}),
        ])

        psi_value = sum([_psi(expected_percents[i], actual_percents[i])
                        for i in range(0, len(expected_percents))])
        df['psi'] = psi_value

        return df

    def categorical_psi(feature, expected_array, actual_array, buckets):
        exp_count = Counter(expected_array)
        act_count = Counter(actual_array)

        cats = list(set(expected_array).union(set(actual_array)))
        counts = {c: [exp_count.get(c, 0), act_count.get(c, 0)] for c in cats}

        if len(counts) > buckets:
            top_cats = [(k, sum(v)) for k, v in counts.items()]
            top_cats = sorted(top_cats, key=lambda x: x[1], reverse=True)[
                :buckets-1]
            top_cats = [c[0] for c in top_cats]
            counts = {k: v for k, v in counts.items() if k in top_cats}
            counts['OTHER'] = [
                len(expected_array) - sum([counts[c][0] for c in top_cats]),
                len(actual_array) - sum([counts[c][1] for c in top_cats]),
            ]
            print(counts)

        rows = []
        psi = 0
        for cat, (e_count, a_count) in counts.items():
            e_perc = e_count / len(expected_array)
            a_perc = a_count / len(actual_array)
            psi += _psi(e_perc, a_perc)

            rows.extend([
                [feature, 'Training', cat, e_perc],
                [feature, 'Scoring', cat, a_perc],
            ])

        df = pd.DataFrame(rows, columns=['feature', 'sample', 'group', 'perc'])
        df['psi'] = psi

        return df

    if isinstance(expected, pd.Series): expected = pd.DataFrame(expected)
    if isinstance(actual, pd.Series): actual = pd.DataFrame(actual)

    if not isinstance(expected, pd.DataFrame) or not isinstance(actual, pd.DataFrame):
        raise Exception("darn")

    df = pd.DataFrame()
    for col, dtype in expected.dtypes.items():
        if dtype == 'object' or expected[col].unique().shape[0] <= 10:       # type: ignore
            _df = categorical_psi(col, expected[col], actual[col], buckets)  # type: ignore
        else:
            _df = numeric_psi(col, expected[col], actual[col], buckets)      # type: ignore
        df = pd.concat([df, _df])

    return df