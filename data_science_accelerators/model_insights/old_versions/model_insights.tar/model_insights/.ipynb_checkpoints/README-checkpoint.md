<!--
    if you are reading this message (and not here to edit this file),
    right-click on this file in the file explorer > Open With > Markdown Preview
-->

# Model Insights V1

---

## About

Model Insights is a tool for quickly building a model dashboard from Jupyter Workspaces.

<br>

## Workflow

The tool is primarily designed for the following use case:

1. Train (and save) a **model** with **training data** in Jupyter Workspaces
1. Deploy the model (maybe in Jupyter), and save the **live data** along with the new **predictions** and **actuals** (when they become available)
1. Use the bold items in the previous step to run the Model Insights tool by passing these objects (and a few other params) to the `run_insights` function
1. Use the saved configuration from the initial run of `run_insights` to process subsequent updates

Because the tool handles the dashboard building, you're only responsible for the data engineering and model development. The following diagram shows an example end-to-end workflow, where a model is trained on training data, and feed of "live" data is scored and captured in a historical dataset. These datasets (and the model object itself) is passed to the Model Insights tool.

![flowchart](./examples/model_insights.drawio.png)

<br>

## Examples

Check out the `examples/` folder for a few notebooks which train a model, score a live dataset, create the Model Insights dashboard, and update the dashboard on subsequent updates.

<!-- TODO add link to screencast demo -->

<br>

## Usage

If you're reading this, you've already unpacked the archive containing this README and source code. Congrats!

When you're ready to interact with Model Insights, it's recommended to do so *above* this directory, i.e. your notebook would be at the same level as the archive you unpacked.

From there, you can import the Model Insights class in the following manner:

```python
from model_insights.src import ModelInsights
```

<br>

## Authentication

Authentication is provided when initializing the Model Insights object. There are a few options for doing this:

```python
#
# username / password. you can pass the password as a param,
# or omit it and you'll be prompted to enter it
#
mi = ModelInsights(
    instance='modocorp',
    username='david.jones@modocorp.com',
)

#
# session cookie (found in your browser tools). this is 
# convenient but not the best option for configuraions
# with longer timeframes since it is transient
#
mi = ModelInsights(
    instance='modocorp',
    session_cookie='...'
)

#
# access token (from the Admin tab in Domo). this is the
# preferred option for scheduled notebooks IMO, since 
# it's easier to share a token with team members
#
mi = ModelInsights(
    instance='modocorp',
    access_token='...'
)
```

<br>

## Help

If you have any questions, please reach out to the Domo Data Science Team