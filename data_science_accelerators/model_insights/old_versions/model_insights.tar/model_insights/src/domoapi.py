import gzip
import pandas as pd
import requests
import os
from datetime import datetime
from getpass import getpass
from io import StringIO
from time import sleep
from typing import Union


class DomoAPI:
    '''
    Interact with your Domo instance via the "unofficial" API!

    This class borrows heavily from the `domojupyter` library.
    '''

    def __init__(
        self,
        instance: str,
        username: str = '',
        password: str = '',
        access_token: str = '',
        session_cookie: str = '',
    ):
        self.instance = instance
        self.api_base = 'https://' + instance + '.domo.com/api'
        self.auth_headers = {}

        if username:
            self._login_password(username, password)
        elif access_token:
            self._login_token(access_token)
        elif session_cookie:
            self._login_cookie(session_cookie)

    def _login_password(self, username: str, password: str = '') -> None:
        if not password:
            password = getpass('Password: ')

        data = {
            'method': 'password',
            'emailAddress': username,
            'password': password
        }

        r = self._post(f'{self.api_base}/content/v2/authentication', data)
        if r.status_code == 200 and r.json()['success']:
            self.auth_headers = {
                'X-Domo-Authentication': r.json().get('sessionToken'),
            }
        else:
            raise Exception('Authentication error! Check your credentials.')

    def _login_token(self, token: str) -> None:
        self.auth_headers = {'X-DOMO-Developer-Token': token}

    def _login_cookie(self, cookie: str) -> None:
        self.auth_headers = {'X-Domo-Authentication': cookie}
    
    def _add_auth_headers(self, headers: dict) -> dict:
        return {**headers, **self.auth_headers}

    def _get(self, url: str='', headers={'Accept': 'application/json'}) -> requests.Response:
        headers = self._add_auth_headers(headers)
        return requests.get(url, headers=headers)

    def _put(self, url: str, data, headers={'Accept': 'application/json'}) -> requests.Response:
        headers = self._add_auth_headers(headers)
        return requests.put(url, json=data, headers=headers)

    def _put_bytes(self, url: str, data, headers: dict={'Accept': 'application/json'}, params: dict={}) -> requests.Response:
        headers = self._add_auth_headers(headers)
        return requests.put(url, data=data, headers=headers, params=params)

    def _post(self, url: str, data, headers={'Accept': 'application/json'}) -> requests.Response:
        headers = self._add_auth_headers(headers)
        return requests.post(url, json=data, headers=headers)

    def _post_file(self, url: str, files: dict, headers={'Accept': 'application/json'}) -> requests.Response:
        headers = self._add_auth_headers(headers)
        return requests.post(url, files=files, headers=headers)

    def _delete(self, url: str, headers: dict={'Accept': 'application/json'}) -> requests.Response:
        headers = self._add_auth_headers(headers)
        return requests.delete(url, headers=headers)

    def _convert_type(self, df_type: str) -> str:
        if df_type == 'object':
            return 'STRING'
        elif df_type == 'category':
            return 'STRING'
        elif df_type == 'int64':
            return 'LONG'
        elif df_type == 'float64':
            return 'DOUBLE'
        elif df_type == 'bool':
            return 'LONG'
        elif df_type == 'datetime64' or df_type == 'datetime64[ns]':
            return 'DATETIME'
        return 'STRING'

    def _convert_type_read(self, schema_type: str) -> str:
        if schema_type == 'STRING':
            return 'object'
        elif schema_type == 'LONG':
            return 'int64'
        elif schema_type == 'DOUBLE':
            return 'float64'
        elif schema_type == 'LONG':
            return 'bool'
        elif schema_type == 'DATETIME':
            return 'datetime64'
        elif schema_type == 'DATE':
            return 'datetime64'
        elif schema_type == 'DECIMAL':
            return 'float64'
        else:
            return 'object'

    def _build_schema(self, df: pd.DataFrame) -> dict:
        columns = [{'name': column, 'type': self._convert_type(
            df.dtypes[ind].name)} for ind, column in enumerate(df.columns)]
        return {'columns': columns}

    def _get_schema(self, dsid: str) -> list:
        url = f'{self.api_base}/query/v1/datasources/{dsid}/schema/indexed'
        headers = {
            'Accept': 'application/json'
        }
        r = self._get(url, headers)
        schema = r.json()
        if r.status_code != 200 or schema is None:
            raise Exception(f'Failed to obtain schema {r.json()}')

        return [{'name': col.get('name'), 'type': col.get('type')} for col in schema['tables'][0]['columns']]

    def _init_ddx_brick(self, brick_id: str, page_id: int):
        data = {
            "appId": brick_id,
            "appType": "card",
            "appDeploymentType": {
                "deploymentType": "sample_data_deploy"
            },
            "userSpecifiedAppTitle": "DDX Blank",
            "parentPageId": page_id,
        }

        resp = self._post(f'{self.api_base}/library/v3/apps/deployments', data)

        card_id = resp.json()['installedId']
        app_id = list(resp.json()['deployedDomoApps'].values())[0]

        #
        # after making the card, we need to make this POST
        # to create the document (which we'll post to again with code)
        #
        # this is also a good time to find the app domain. TODO get some
        # more details on this if possible, cause I'm making quite a bit of
        # assumptions here, and since there is no way (AFAIK) to find this
        # via API, we're just gonna do the ol' guess-n-check
        #
        prod_id = 1
        max_prod_id = 8
        app_domain = ''
        for prod_id in range(1, max_prod_id + 1):
            resp = self._post(
                f'https://{app_id}.domoapps.prod{prod_id}.domo.com/domo/datastores/v1/collections/ddx_app_client_code/documents/',
                {'content': {"htmlBlank": {"js": "", "html": "", "css": "", }}},
            )
            if resp.status_code == 200:
                app_domain = f'{app_id}.domoapps.prod{prod_id}.domo.com'
                break

        if prod_id >= max_prod_id:
            raise Exception('Unable to find App Domain')

        return (card_id, app_domain)

    def _get_app_doc_id(self, app_domain):
        while True:
            resp = self._get(
                f'https://{app_domain}/domo/datastores/v1/collections/ddx_app_client_code/documents').json()
            if len(resp):
                break
            sleep(5)
        return resp[0]['id']

    def _get_app_context(self, app_id):
        resp = self._put(
            f'https://{self.instance}.domo.com/domoapps/apps/v2/{app_id}?fullpage=false&cardTitle=DDX Blank', {})
        return resp.json()['context']

    def _build_card(self, data, page_id: int=-100000):
        resp = self._put(
            f'{self.api_base}/content/v3/cards/kpi?pageId={page_id}',
            data,
        )

        if resp.status_code == 200:
            return resp.json()['id']
        else:
            print(resp.status_code)
            print(resp.text)
            raise Exception('Error making card')

    def _create_notebook_card(self, page_id: int) -> int:
        resp = self._post(
            f'{self.api_base}/content/v1/cards/notebook',
            {
                "text": "",
                "title": "Notebook Card",
                "encoding": "html",
                "dataFileIds": [],
                "pageId": page_id,
                "markup": "",
                "version": "v3"
            }
        )

        return resp.json()['id']

    def _update_notebook_card(self, card_id: int, html: str, mark: str):
        self._post(
            f'{self.api_base}/content/v1/cards/notebook/{card_id}/update',
            {
                "id": card_id,
                "markup": mark,
                "textHtml": html,
                "dynamicTextItems": {},
                "subscriptions": [],
                "formulas": []
            }
        )

    def _build_notebook_card(self, page_id: int, html: str, mark: str) -> int:
        card_id = self._create_notebook_card(page_id)
        self._update_notebook_card(card_id, html, mark)
        return card_id

    def _get_dashboard_layout(self, page_id):
        r = self._post(f'{self.api_base}/content/v4/pages/{page_id}/layouts/convert/flowToLayout', {})
        
        #
        # i'm not sure how to find the layout_id except when converting a standard page to 
        # a design dashboard. so in the case when the page is already a design dashboard,
        # we convert it back to a standard page (layout -> flow), then take it back to a design
        # (flow -> layout) to get the layout_id
        #
        if r.status_code != 200:
            self._post(f'{self.api_base}/content/v4/pages/{page_id}/layouts/convert/layoutToFlow', {})
            sleep(3)
            r = self._post(f'{self.api_base}/content/v4/pages/{page_id}/layouts/convert/flowToLayout', {})
        
        return r.json()['layoutId']

    def _add_dashboard_layout(self, layout_id, data) -> None:
        self._put(f'{self.api_base}/content/v4/pages/layouts/{layout_id}/writelock', {})
        self._put(f'{self.api_base}/content/v4/pages/layouts/{layout_id}', data)
        self._delete(f'{self.api_base}/content/v4/pages/layouts/{layout_id}/writelock', {})

    def _add_image(self, filepath, page_id):
        filename = os.path.basename(filepath)
        files = [
            ('file', ('sherpa.jpg', open(filepath,'rb'),'image/jpeg'))
        ]
        r = mi._post_file(f'{self.api_base}/data/v1/data-files', files)
        file_id = r.json()['dataFileId']
        data = {
            "type": "document",
            "description": filename,
            "metadata": {
                "title": filename,
                "documentId": f"{file_id}:undefined",
                "usingSampleData": "",
                "kpiType": "document",
                "description": filename
            }
        }
        r = mi._post(f'{self.api_base}/content/v1/cards?pageId={page_id}', data)
        return int(r.json()['urn'])

    def _create_or_update(self, df, name, dsid: str) -> str:
        if dsid:
            self.write_dataset(df, dsid=dsid)
        else:
            dsid = self.write_dataset(df, name=name)
        return dsid

    def _save_page_filter(self, data, page_id, default=True) -> None:
        r = self._post(f'{self.api_base}/content/v3/pages/{page_id}/analyzer', data)
        analyzer_id = r.json()['analyzerId']
        if default:
            self._put(f'{self.api_base}/content/v3/pages/{page_id}/analyzer/{analyzer_id}/global', {})

    def __copy_dataflow(self, src_id: Union[int, str], dest_instance=None, dest_id: Union[int, str]=''):
        if not dest_instance:
            dest_instance = self

        print(self.api_base, ' -> ', dest_instance.api_base)

        r = self._get(f'{self.api_base}/dataprocessing/v2/dataflows/{src_id}')

        if dest_id:
            old = dest_instance._get(f'{dest_instance.api_base}/dataprocessing/v2/dataflows/{dest_id}')
            data = old.json()
            data['actions'] = r.json()['actions']
            r = dest_instance._put(f'{dest_instance.api_base}/dataprocessing/v1/dataflows/{dest_id}', data)
            print(r.status_code)

        else:
            data = {
                "documentVersion": 1,
                "databaseType": "MAGIC",
                "name": "",
                "settings": {},
                "description": "",
                "runState": "ENABLED",
                "neverAbandon": False,
                "actions": [],
                "onboardFlowVersion": {},
                "engineProperties": {
                    "kettle.mode": "STRICT"
                },
                "triggerSettings": None,
                "scheduleInfo": None
            }

            data['actions'] = []
            data['name'] = r.json()['name']

            print(data)

            r = dest_instance._post(f'{dest_instance.api_base}/dataprocessing/v1/dataflows', data)
            print(r.text)
            print(r.status_code)

    def _delete_dataset(self, dsid: str):
        self._delete(f'{self.api_base}/data/v3/datasources/{dsid}?deleteMethod=hard')

    def create_ddx_brick(self, dsid, page_id, js='', html='', css=''):
        ddx_id = '13C84724BDB6BA1E76B352FE2EBF99E2266F982E982C940B0968FC615CD99338'
        card_id, app_domain = self._init_ddx_brick(ddx_id, page_id)
        app_id = app_domain.split('.')[0]

        context = self._get_app_context(app_id)
        context_id = context['id']

        template_id = context['mapping'][0]['dataSetId']

        context['mapping'][0]['datasetId'] = dsid
        context['mapping'][1]['datasetId'] = dsid
        context['mapping'][2]['datasetId'] = dsid
        self._put(f'https://{self.instance}.domo.com/domoapps/apps/v2/contexts/{context_id}', context)

        doc_id = self._get_app_doc_id(app_domain)

        data = {
            'content': {
                "htmlBlank": {
                        "html": html,
                        "js": js,
                        "css": css,
                }
            }
        }

        self._put(
            f'https://{app_domain}/domo/datastores/v1/collections/ddx_app_client_code/documents/{doc_id}',
            data,
            {'origin': f'https://{app_domain}'}
        )

        # delete those temp datasets AFTER the datasets have been updated
        sleep(10)
        self._delete_dataset(template_id)
        
        return (card_id, app_domain)

    def create_page(self, page_name: str, parent_page_id: int=0) -> int:
        data = {
            'parentPageId': parent_page_id,
            'title': page_name
        }
        r = self._post(f'{self.api_base}/content/v1/pages?layout=false', data)
        if r.status_code == 200:
            return r.json()['pageId']
        else:
            raise Exception('yikes')

    def read_dataset(self, dsid: str, limit: int = 0, query: str = 'SELECT * FROM table', **kwargs) -> pd.DataFrame:
        if limit:
            query += f' LIMIT {limit}'

        url = f'{self.api_base}/query/v1/execute/export/{dsid}'
        body = {'sql': query}
        r = self._post(url, body, headers={'Accept': 'text/csv,application/json;q=0.1'})
        data = r.content.decode('utf-8')

        schema = self._get_schema(dsid)

        column_types = []
        date_cols = []
        type_dict = {}
        header = pd.read_csv(StringIO(data), index_col=False, header=0, nrows=0).columns.tolist()
        user_dtype = False
        user_parse_date = False

        for cols in schema:
            column_types.append(list(cols.values()))

        if kwargs:
            for key, value in kwargs.items():
                if key == 'dtype':
                    user_dtype = True
                elif key == 'parse_dates':
                    user_parse_date = True

        for cols in column_types:
            column_name = cols[0]
            if column_name in header:
                dtype = self._convert_type_read(cols[1])
                if dtype == 'datetime64' and not user_parse_date:
                    date_cols.append(column_name)
                elif not user_dtype:
                    type_dict[column_name] = dtype

        if date_cols:
            kwargs['parse_dates'] = date_cols

        if type_dict:
            kwargs['dtype'] = type_dict

        return pd.read_csv(StringIO(data), **kwargs)

    def write_dataset(self, df: pd.DataFrame, name: str='', dsid: str='') -> str:
        if not name and not dsid:
            raise ValueError

        if name:
            payload = {
                "transport": {
                    "type": "API",
                },
                "dataSource": {
                    "name": name,
                    "description": "",
                },
                "dataProvider": {
                    "key": "api",
                    "name": "api"
                },
                "schemaDefinition": self._build_schema(df)
            }
            resp = self._post(f'{self.api_base}/data/v1/streams', payload)
            dsid = resp.json()['dataSource']['id']

        gz_csv = gzip.compress(bytes(df.to_csv(index=False), 'utf-8'))

        # find the stream
        stream_search_url = f'{self.api_base}/data/v1/streams/search?q=dataSource.id:{dsid}'
        stream_id = self._get(stream_search_url).json()[0]['id']

        # start the execution
        start_exec_url = f'{self.api_base}/data/v1/streams/{stream_id}/executions'
        exec_id = self._post(start_exec_url, {}).json()['executionId']

        # upload the data
        upload_part_url = f'{self.api_base}/data/v1/streams/{stream_id}/executions/{exec_id}/part/1'
        resp = self._put_bytes(upload_part_url, gz_csv)

        # commit the stream
        commit_stream_url = f'{self.api_base}/data/v1/streams/{stream_id}/executions/{exec_id}/commit'
        resp = self._put(commit_stream_url, {})

        return dsid
