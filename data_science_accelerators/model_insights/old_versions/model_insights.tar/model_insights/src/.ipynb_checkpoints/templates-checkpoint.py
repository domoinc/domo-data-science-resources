summary_table = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature",
                            "mapping": "VALUE",
                            "alias": "..."
                        },
                        {
                            "column": "feature2",
                            "mapping": "VALUE",
                            "alias": "..."
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "summary"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_basic_table",
                    "overrides": {
                        "header_row_font_color": "#E8E8E8FF",
                        "padding": "Medium",
                        "header_row_fill_color": "#E8E8E8FF",
                        "header_row_font_size": "Smallest",
                        "font_size": "Largest"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Summary Table",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682957399000,
            "noDateRange": true,
            "title": "Summary Table",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

data_status = r'''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature",
                            "mapping": "VALUE",
                            "alias": "Type"
                        },
                        {
                            "formulaId": "calculation_cee1e3fa-2680-416c-8970-e883857c200b",
                            "mapping": "VALUE",
                            "alias": "Name"
                        },
                        {
                            "column": "index",
                            "mapping": "VALUE",
                            "alias": "Status"
                        },
                        {
                            "formulaId": "calculation_6e9154f6-3158-4e28-9aaf-689abd3f8cc6",
                            "mapping": "VALUE",
                            "alias": "Last Update"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "dataflow_status"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "formulaId": "calculation_6e9154f6-3158-4e28-9aaf-689abd3f8cc6",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": [
                    {
                        "templateId": 10442,
                        "id": "calculation_cee1e3fa-2680-416c-8970-e883857c200b",
                        "name": "name_link",
                        "formula": "CONCAT('<a href=\"', `feature2`, '\" target=\"_blank\">', `feature3`, '</a>')",
                        "status": "VALID",
                        "persistedOnDataSource": false,
                        "columnPositions": [
                            {
                                "columnName": "`feature2`",
                                "columnPosition": 20
                            },
                            {
                                "columnName": "`feature3`",
                                "columnPosition": 54
                            }
                        ],
                        "cacheWindow": "non_dynamic",
                        "locked": false,
                        "owner": 352859788,
                        "certificationStatus": "EXPIRED",
                        "usedByOtherCards": false,
                        "isAnalytic": false,
                        "referenceCount": 1,
                        "dataType": "string",
                        "isAggregatable": true,
                        "bignumber": false
                    },
                    {
                        "templateId": 10431,
                        "id": "calculation_6e9154f6-3158-4e28-9aaf-689abd3f8cc6",
                        "name": "last_run",
                        "formula": "FROM_UNIXTIME(`value` / 1000)",
                        "status": "VALID",
                        "persistedOnDataSource": false,
                        "columnPositions": [
                            {
                                "columnName": "`value`",
                                "columnPosition": 14
                            }
                        ],
                        "cacheWindow": "none",
                        "locked": false,
                        "owner": 352859788,
                        "usedByOtherCards": false,
                        "isAnalytic": false,
                        "referenceCount": 1,
                        "dataType": "datetime",
                        "isAggregatable": true,
                        "bignumber": false
                    }
                ]
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [
                    {
                        "condition": {
                            "column": "index",
                            "values": [
                                "SUCCESS"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "IN"
                        },
                        "format": {
                            "color": "#80C25DFF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "index",
                            "values": [
                                "SUCCESS"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "NOT_IN"
                        },
                        "format": {
                            "color": "#FD7F76FF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    }
                ],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_basic_table",
                    "overrides": {
                        "padding": "Medium",
                        "font_size": "Normal"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Data Status",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1680280983000,
            "noDateRange": true,
            "title": "Data Status",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

shap_summ = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "value2",
                            "aggregation": "AVG",
                            "mapping": "VALUE"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "_BASELINE"
                            ],
                            "filterType": "LEGACY",
                            "operand": "NOT_IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "shap_train"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "formulaId": "calculation_cea1705e-900e-4dd2-8a9b-79209eba37ad",
                            "order": "DESCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "feature"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": [
                    {
                        "templateId": 10251,
                        "id": "calculation_cea1705e-900e-4dd2-8a9b-79209eba37ad",
                        "name": "abs_avg_shap_value",
                        "formula": "ABS(AVG(`value2`))",
                        "status": "VALID",
                        "persistedOnDataSource": false,
                        "columnPositions": [
                            {
                                "columnName": "`value2`",
                                "columnPosition": 8
                            }
                        ],
                        "cacheWindow": "non_dynamic",
                        "locked": false,
                        "owner": 352859788,
                        "certificationStatus": "EXPIRED",
                        "usedByOtherCards": false,
                        "isAnalytic": false,
                        "referenceCount": 1,
                        "dataType": "numeric",
                        "isAggregatable": false,
                        "bignumber": false
                    }
                ]
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#80C25DFF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "LESS_THAN"
                        },
                        "format": {
                            "color": "#FD7F76FF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    }
                ],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_horiz_stackedbar",
                    "overrides": {
                        "lrg_legend_position": "Hide",
                        "suppress_minmaxavg": "true",
                        "details_legend_position": "Hide"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Feature Importance",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1680106668000,
            "noDateRange": true,
            "title": "Feature Importance",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

shap_dep_filter = '''
{
    "definition": {
        "subscriptions": {
            "main": {
                "name": "main",
                "dataSourceId": "<DSID>",
                "columns": [
                    {
                        "column": "feature",
                        "mapping": "ITEM"
                    },
                    {
                        "column": "feature",
                        "aggregation": "COUNT",
                        "mapping": "VALUE"
                    }
                ],
                "filters": [
                    {
                        "column": "feature",
                        "values": [
                            "_BASELINE"
                        ],
                        "filterType": "LEGACY",
                        "operand": "NOT_IN",
                        "dataType": "string",
                        "label": "feature"
                    },
                    {
                        "column": "table",
                        "values": [
                            "shap_train"
                        ],
                        "filterType": "LEGACY",
                        "operand": "IN",
                        "dataType": "string",
                        "label": "table"
                    }
                ],
                "orderBy": [
                    {
                        "column": "feature",
                        "order": "ASCENDING"
                    }
                ],
                "groupBy": [
                    {
                        "column": "feature"
                    }
                ],
                "fiscal": false,
                "projection": false,
                "distinct": false
            }
        },
        "formulas": {
            "dsUpdated": [],
            "dsDeleted": [],
            "card": []
        },
        "annotations": {
            "new": [],
            "modified": [],
            "deleted": []
        },
        "conditionalFormats": {
            "card": [],
            "datasource": []
        },
        "controls": [],
        "segments": {
            "active": [],
            "create": [],
            "update": [],
            "delete": []
        },
        "charts": {
            "main": {
                "component": "main",
                "chartType": "badge_dropdown_selector",
                "overrides": {
                    "dropdown_label_pos": "Above",
                    "dropdown_label_text": "Filter by Feature"
                },
                "goal": null
            }
        },
        "dynamicTitle": {
            "text": [
                {
                    "text": "Feature Selector",
                    "type": "TEXT"
                }
            ]
        },
        "dynamicDescription": {
            "text": [],
            "displayOnCardDetails": true
        },
        "chartVersion": "9",
        "allowTableDrill": true,
        "modified": 1677270988000,
        "noDateRange": true,
        "title": "Feature Selector",
        "description": ""
    },
    "dataProvider": {
        "dataSourceId": "<DSID>"
    },
    "variables": true
}
'''

shap_dep = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "mapping": "XTIME"
                        },
                        {
                            "column": "value2",
                            "mapping": "VALUE"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "_BASELINE"
                            ],
                            "filterType": "LEGACY",
                            "operand": "NOT_IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "shap_train"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#80C25DFF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "LESS_THAN"
                        },
                        "format": {
                            "color": "#FD7F76FF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    }
                ],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_xybubble",
                    "overrides": {
                        "title_x": "Feature Value",
                        "title_y": "Shap Value"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Feature Dependence",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1680106886000,
            "noDateRange": true,
            "title": "Feature Dependence",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

feat_filter_1 = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "dataSourceId": "<DSID>",
                    "columns": [
                        {
                            "column": "feature",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "feature",
                            "aggregation": "COUNT",
                            "mapping": "VALUE"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "_BASELINE"
                            ],
                            "filterType": "LEGACY",
                            "operand": "NOT_IN",
                            "dataType": "string",
                            "label": "feature"
                        }
                    ],
                    "orderBy": [
                        {
                            "column": "feature",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "feature"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_dropdown_selector",
                    "overrides": {
                        "dropdown_label_pos": "Above",
                        "dropdown_label_text": "Filter by Feature"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Feature Selector",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1675262446000,
            "noDateRange": true,
            "title": "Feature Selector",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

shap_dep = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "dataSourceId": "<DSID>",
                    "columns": [
                        {
                            "column": "value",
                            "mapping": "XTIME"
                        },
                        {
                            "column": "value2",
                            "mapping": "VALUE"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "_BASELINE"
                            ],
                            "filterType": "LEGACY",
                            "operand": "NOT_IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "shap_train"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#80C25DFF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "LESS_THAN"
                        },
                        "format": {
                            "color": "#FD7F76FF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    }
                ],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_xybubble",
                    "overrides": {
                        "title_x": "Feature Value",
                        "title_y": "Shap Value"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Feature Dependence",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1683203964000,
            "noDateRange": true,
            "title": "Feature Dependence",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

shap_waterfall = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature",
                            "mapping": "VALUE1"
                        },
                        {
                            "column": "value2",
                            "aggregation": "AVG",
                            "mapping": "VALUE2"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "shap_pred"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "column": "feature",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "feature"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_vert_waterfall",
                    "overrides": {
                        "datalabel_fnt_clr": "Black",
                        "final_summary_text": "Prediction",
                        "bridging_lines": "false",
                        "datalabel_position": "Outside Top",
                        "start_bar_fill_color": "#90C4E4FF",
                        "end_bar_fill_color": "#4E8CBAFF",
                        "font_size": "Default",
                        "show_summary_bars": "false",
                        "sum_initial_group": "false",
                        "datalabel_fill": "false",
                        "datalabel_text": "%_VALUE "
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Prediction Breakdown (",
                        "type": "TEXT"
                    },
                    {
                        "prefix": "obs=",
                        "defaultText": "averaged",
                        "columns": [
                            "index"
                        ],
                        "type": "FILTER"
                    },
                    {
                        "text": ")",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1676558836000,
            "noDateRange": true,
            "title": "Prediction Breakdown (averaged)",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

obs_table = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature",
                            "mapping": "VALUE",
                            "alias": "Feature"
                        },
                        {
                            "column": "value",
                            "aggregation": "AVG",
                            "mapping": "VALUE",
                            "alias": "Value"
                        },
                        {
                            "column": "value2",
                            "aggregation": "AVG",
                            "mapping": "VALUE",
                            "alias": "Shap Value"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "shap_pred"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "column": "feature",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "feature"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#A0D771FF",
                            "textColor": "#222c19",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "LESS_THAN"
                        },
                        "format": {
                            "color": "#FD9A93FF",
                            "textColor": "#382422",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    }
                ],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_basic_table",
                    "overrides": {
                        "use_heatmap_colors": "false",
                        "show_diverging": "false"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Observation Values (",
                        "type": "TEXT"
                    },
                    {
                        "prefix": "obs=",
                        "defaultText": "averaged",
                        "columns": [
                            "index"
                        ],
                        "type": "FILTER"
                    },
                    {
                        "text": ")",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1676560308000,
            "noDateRange": true,
            "title": "Observation Values (averaged)",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

feat_filter_2 = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "dataSourceId": "<DSID>",
                    "columns": [
                        {
                            "column": "feature2",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "feature2",
                            "aggregation": "COUNT",
                            "mapping": "VALUE"
                        }
                    ],
                    "filters": [],
                    "orderBy": [
                        {
                            "column": "feature2",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "feature2"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_dropdown_selector",
                    "overrides": {
                        "dropdown_label_pos": "Above",
                        "dropdown_label_text": "Filter by Feature (for Partial Dependence)"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Feature Selector 2",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1675263630000,
            "noDateRange": true,
            "title": "Feature Selector 2",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

partial_obs_filter_1 = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "index",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "index",
                            "aggregation": "SUM",
                            "mapping": "VALUE"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "shap_pred"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "column": "index",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "index"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_dropdown_selector",
                    "overrides": {
                        "dropdown_label_text": "Filter by Observation",
                        "dropdown_label_pos": "Above"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Shapley Values TEST",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1676558366000,
            "noDateRange": true,
            "title": "Shapley Values TEST",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

partial_obs_filter_2 = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "index",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "index",
                            "aggregation": "SUM",
                            "mapping": "VALUE"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "shap_pred"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "column": "index",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "index"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_dropdown_selector",
                    "overrides": {
                        "dropdown_label_text": "Filter by Observation",
                        "dropdown_label_pos": "Above"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Shapley Values TEST",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1676558366000,
            "noDateRange": true,
            "title": "Shapley Values TEST",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

partial_feat_filter = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature2",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "feature2",
                            "aggregation": "COUNT",
                            "mapping": "VALUE"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "partial"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "column": "feature2",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "feature2"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_dropdown_selector",
                    "overrides": {
                        "dropdown_label_pos": "Above",
                        "dropdown_label_text": "Filter by Feature"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Feature Selector 2",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1677594656000,
            "noDateRange": true,
            "title": "Feature Selector 2",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

partial = '''
    {
        "definition": {
            "subscriptions": {
                "big_number": {
                    "name": "big_number",
                    "dataSourceId": "<DSID>",
                    "columns": [
                        {
                            "column": "value3",
                            "aggregation": "SUM",
                            "alias": "Actual Feature Value",
                            "format": {
                                "type": "abbreviated",
                                "format": "0.00"
                            }
                        }
                    ],
                    "filters": [],
                    "orderBy": [],
                    "groupBy": [],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false,
                    "limit": 1
                },
                "main": {
                    "name": "main",
                    "dataSourceId": "<DSID>",
                    "columns": [
                        {
                            "column": "value",
                            "mapping": "ITEM",
                            "format": {
                                "type": "number",
                                "format": "###,###.000",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 3
                            }
                        },
                        {
                            "column": "value2",
                            "aggregation": "SUM",
                            "mapping": "VALUE"
                        },
                        {
                            "column": "feature2",
                            "mapping": "SERIES"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "partial"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "column": "value",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "feature2"
                        },
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_two_trendline",
                    "overrides": {
                        "suppress_minmaxavg": "true",
                        "title_x": "Feature Value",
                        "fill_missing_dates": "true",
                        "title_y": "Prediction",
                        "cat_scale_show_labels": "Default",
                        "no_trellis_line_breaks": "false",
                        "series_filter": "none",
                        "hide_area_fill": "true",
                        "hide_value_gridlines": "false",
                        "show_line_labels": "false",
                        "line_style": "Plain with Symbols",
                        "range_filter_y": "none",
                        "range_filter_time": "none",
                        "range_filter_x": "none",
                        "hide_empty_values": "true",
                        "line_thickness": "Default",
                        "log_scale_y": "false",
                        "hide_series": "none",
                        "row_filter": "none"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Partial Dependence (",
                        "type": "TEXT"
                    },
                    {
                        "prefix": "obs=",
                        "defaultText": "obs=ALL",
                        "columns": [
                            "index"
                        ],
                        "type": "FILTER"
                    },
                    {
                        "text": ", ",
                        "type": "TEXT"
                    },
                    {
                        "prefix": "feature=",
                        "defaultText": "feature=ALL",
                        "columns": [
                            "feature2"
                        ],
                        "type": "FILTER"
                    },
                    {
                        "text": ")",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1677596718000,
            "noDateRange": true,
            "title": "Partial Dependence (obs=ALL, feature=ALL)",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

corr_matrix = '''
{
    "definition": {
        "subscriptions": {
            "main": {
                "name": "main",
                "columns": [
                    {
                        "column": "feature",
                        "mapping": "ITEM"
                    },
                    {
                        "column": "value",
                        "mapping": "VALUE"
                    },
                    {
                        "column": "feature2",
                        "mapping": "SERIES"
                    }
                ],
                "filters": [
                    {
                        "column": "table",
                        "values": [
                            "correlation"
                        ],
                        "filterType": "LEGACY",
                        "operand": "IN",
                        "dataType": "string",
                        "label": "table"
                    }
                ],
                "orderBy": [
                    {
                        "column": "feature",
                        "order": "ASCENDING"
                    },
                    {
                        "column": "feature2",
                        "order": "ASCENDING"
                    }
                ],
                "groupBy": [
                    {
                        "column": "feature2"
                    },
                    {
                        "column": "feature"
                    },
                    {
                        "column": "value"
                    }
                ],
                "fiscal": false,
                "projection": false,
                "distinct": false
            }
        },
        "formulas": {
            "dsUpdated": [],
            "dsDeleted": [],
            "card": []
        },
        "annotations": {
            "new": [],
            "modified": [],
            "deleted": []
        },
        "conditionalFormats": {
            "card": [],
            "datasource": []
        },
        "controls": [],
        "segments": {
            "active": [],
            "create": [],
            "update": [],
            "delete": []
        },
        "charts": {
            "main": {
                "component": "main",
                "chartType": "badge_heatmap",
                "overrides": {
                    "show_midpoint": "false",
                    "lower_color_theme": "default",
                    "range_6_min": ".10",
                    "range_8_max": ".85",
                    "range_6_color": "#B7DAF5FF",
                    "inner_margin": "3",
                    "range_4_color": "#B7DAF5FF",
                    "range_2_min": "-.85",
                    "reverse_color_direction": "false",
                    "range_7_max": ".65",
                    "range_9_color": "#4E8CBAFF",
                    "range_1_color": "#4E8CBAFF",
                    "range_3_max": "-.40",
                    "range_2_color": "#73B0D7FF",
                    "balanced_distribution": "false",
                    "range_8_min": ".65",
                    "range_7_min": ".40",
                    "range_6_max": ".40",
                    "range_7_color": "#90C4E4FF",
                    "range_3_min": "-.65",
                    "range_2_max": "-.65",
                    "datalabel_text": "%_VALUE ",
                    "range_5_color": "#FFFFFFFF",
                    "range_4_min": "-.40",
                    "range_9_min": ".85",
                    "disable_animation": "false",
                    "upper_color_theme": "default",
                    "range_1_max": "-.85",
                    "color_theme": "gradient-8",
                    "range_5_max": ".10",
                    "show_diverging": "false",
                    "range_4_max": "-.10",
                    "range_9_max": "1",
                    "range_5_min": "-.10",
                    "range_8_color": "#73B0D7FF",
                    "zero_like_no_data": "false",
                    "range_1_min": "-1",
                    "range_3_color": "#90C4E4FF",
                    "hide_legend": "true"
                },
                "goal": null
            }
        },
        "dynamicTitle": {
            "text": [
                {
                    "text": "Feature Correlation",
                    "type": "TEXT"
                }
            ]
        },
        "dynamicDescription": {
            "text": [],
            "displayOnCardDetails": true
        },
        "chartVersion": "9",
        "allowTableDrill": true,
        "modified": 1676476453000,
        "noDateRange": true,
        "title": "Feature Correlation",
        "description": ""
    },
    "dataProvider": {
        "dataSourceId": "<DSID>"
    },
    "variables": true
}
'''

vif = '''
{
    "definition": {
        "subscriptions": {
            "main": {
                "name": "main",
                "columns": [
                    {
                        "column": "feature",
                        "mapping": "ITEM"
                    },
                    {
                        "column": "value2",
                        "aggregation": "AVG",
                        "mapping": "VALUE"
                    }
                ],
                "filters": [
                    {
                        "column": "table",
                        "values": [
                            "correlation"
                        ],
                        "filterType": "LEGACY",
                        "operand": "IN",
                        "dataType": "string",
                        "label": "table"
                    }
                ],
                "orderBy": [
                    {
                        "column": "value2",
                        "order": "DESCENDING"
                    }
                ],
                "groupBy": [
                    {
                        "column": "feature"
                    },
                    {
                        "column": "value2"
                    }
                ],
                "fiscal": false,
                "projection": false,
                "distinct": false
            }
        },
        "formulas": {
            "dsUpdated": [],
            "dsDeleted": [],
            "card": []
        },
        "annotations": {
            "new": [],
            "modified": [],
            "deleted": []
        },
        "conditionalFormats": {
            "card": [],
            "datasource": []
        },
        "controls": [],
        "segments": {
            "active": [],
            "create": [],
            "update": [],
            "delete": []
        },
        "charts": {
            "main": {
                "component": "main",
                "chartType": "badge_horiz_stackedbar",
                "overrides": {
                    "datalabel_show_total": "false",
                    "suppress_minmaxavg": "true"
                },
                "goal": null
            }
        },
        "dynamicTitle": {
            "text": [
                {
                    "text": "Variance Inflation Factor",
                    "type": "TEXT"
                }
            ]
        },
        "dynamicDescription": {
            "text": [],
            "displayOnCardDetails": true
        },
        "chartVersion": "9",
        "allowTableDrill": true,
        "modified": 1676476456000,
        "noDateRange": true,
        "title": "Variance Inflation Factor",
        "description": ""
    },
    "dataProvider": {
        "dataSourceId": "<DSID>"
    },
    "variables": true
}
'''

live_r2 = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "Accuracy",
                                "R2"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "live_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "R2",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1683145801000,
            "noDateRange": true,
            "title": "R2",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_mae = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "number",
                                "format": "###,###.00",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 2
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "MAE"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "live_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "MAE",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682611395000,
            "noDateRange": true,
            "title": "MAE",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_mape = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "MAPE"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "live_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "MAPE",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1683135124000,
            "noDateRange": true,
            "title": "MAPE",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_rmse = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "number",
                                "format": "###,###.00",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 2
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "RMSE"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "live_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "RMSE",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682611418000,
            "noDateRange": true,
            "title": "RMSE",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_history_1 = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature2",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "value",
                            "mapping": "VALUE"
                        },
                        {
                            "column": "feature",
                            "mapping": "SERIES"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "MAPE",
                                "R2"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "live_perf_history"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "feature"
                        },
                        {
                            "column": "feature2"
                        },
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_two_trendline",
                    "overrides": {
                        "suppress_max": "true",
                        "dual_y_scales": "true",
                        "suppress_min": "true",
                        "hide_value_gridlines": "false",
                        "hide_area_fill": "true",
                        "calculated_line": "None",
                        "line_style": "Plain with Symbols"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "R2 / MAPE History",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1683135305000,
            "noDateRange": true,
            "title": "R2 / MAPE History",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_history_2 = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature2",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "value",
                            "mapping": "VALUE"
                        },
                        {
                            "column": "feature",
                            "mapping": "SERIES"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "MAE",
                                "RMSE"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "live_perf_history"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "feature"
                        },
                        {
                            "column": "feature2"
                        },
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_two_trendline",
                    "overrides": {
                        "suppress_max": "true",
                        "dual_y_scales": "true",
                        "suppress_min": "true",
                        "hide_value_gridlines": "false",
                        "hide_area_fill": "false",
                        "calculated_line": "None",
                        "line_style": "Plain with Symbols"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "MAE / RMSE History",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682689815000,
            "noDateRange": true,
            "title": "MAE / RMSE History",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

train_r2 = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "Accuracy",
                                "R2"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "R2",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1683145801000,
            "noDateRange": true,
            "title": "R2",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

train_mae = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "number",
                                "format": "###,###.00",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 2
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "MAE"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "MAE",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682611395000,
            "noDateRange": true,
            "title": "MAE",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

train_mape = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "MAPE"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "MAPE",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1683135124000,
            "noDateRange": true,
            "title": "MAPE",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

train_rmse = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "number",
                                "format": "###,###.00",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 2
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "RMSE"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "RMSE",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682611418000,
            "noDateRange": true,
            "title": "RMSE",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

target_drift_label = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "index",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "drift_y"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_textbox",
                    "overrides": {
                        "font_size": "Large",
                        "gauge_sizing": "Fixed size - 1.0x"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Drift Label",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1677174542000,
            "noDateRange": true,
            "title": "Drift Label",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

feature_drift_label = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "index",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "drift"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_textbox",
                    "overrides": {
                        "font_size": "Large",
                        "gauge_sizing": "Fixed size - 1.0x"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Drift Label",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1677174542000,
            "noDateRange": true,
            "title": "Drift Label",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

feature_drift_filter = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                ""
                            ],
                            "filterType": "LEGACY",
                            "operand": "NOT_IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "drift"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "column": "feature",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_dropdown_selector",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Filter",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1677085080000,
            "noDateRange": true,
            "title": "Filter",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

target_drift = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "mapping": "ITEM",
                            "format": {
                                "type": "number",
                                "format": "###,###.00",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 2
                            }
                        },
                        {
                            "column": "value2",
                            "aggregation": "AVG",
                            "mapping": "VALUE"
                        },
                        {
                            "column": "feature2",
                            "mapping": "SERIES"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "drift_y"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "feature2"
                        },
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_vert_multibar",
                    "overrides": {
                        "auto_center": "false",
                        "title_x": "Prediction",
                        "title_y": "Stability Index",
                        "fill_missing_dates": "true"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Prediction Drift",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1677246489000,
            "noDateRange": true,
            "title": "Prediction Drift",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

feature_drift = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "value2",
                            "aggregation": "SUM",
                            "mapping": "VALUE"
                        },
                        {
                            "column": "feature2",
                            "mapping": "SERIES"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature2",
                            "values": [
                                "Scoring",
                                "Training"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature2"
                        },
                        {
                            "column": "table",
                            "values": [
                                "drift"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "feature2"
                        },
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_vert_multibar",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Feature Drift",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1677083002000,
            "noDateRange": true,
            "title": "Feature Drift",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

drift_scatter = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "mapping": "XTIME",
                            "alias": "Feature Importance"
                        },
                        {
                            "column": "value3",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "alias": "Drfit"
                        },
                        {
                            "column": "feature",
                            "mapping": "SERIES"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "drift_fi"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "feature"
                        },
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [
                    {
                        "condition": {
                            "column": "value3",
                            "values": [
                                ".1"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "LESS_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#80C25DFF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    },
                    {
                        "condition": {
                            "column": "value3",
                            "values": [
                                ".2"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "LESS_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#FBAD56FF",
                            "textColor": "#986f3e",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    },
                    {
                        "condition": {
                            "column": "value3",
                            "values": [
                                ".2"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREATER_THAN"
                        },
                        "format": {
                            "color": "#E45850FF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    }
                ],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_xybubble",
                    "overrides": {
                        "lrg_legend_position": "Hide",
                        "xy_symbol_size": "Small",
                        "title_x": "Feature Importance",
                        "title_y": "Stability Index",
                        "series_filter": "none",
                        "xy_symbol_type": "Circle",
                        "hover_text": "%_SERIES_NAME (%_XVALUE , %_YVALUE)",
                        "hide_all_grids": "false",
                        "range_filter_y": "none",
                        "range_filter_time": "none",
                        "details_legend_position": "Hide",
                        "range_filter_x": "none",
                        "show_regression_lines": "false",
                        "hide_series": "none",
                        "row_filter": "none",
                        "datalabel_text": "%_SERIES_NAME "
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Drift by Feature Importance",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "9",
            "allowTableDrill": true,
            "modified": 1676498779000,
            "noDateRange": true,
            "title": "Drift by Feature Importance",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

threshold_dropdown = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value2",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "value2",
                            "aggregation": "SUM",
                            "mapping": "VALUE"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value2"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_dropdown_selector",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Dropdown",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682426507000,
            "noDateRange": true,
            "title": "Dropdown",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_accuracy = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "Accuracy"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "live_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Accuracy",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682357441000,
            "noDateRange": true,
            "title": "Accuracy",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_precision = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "Precision"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "live_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Precision",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682358287000,
            "noDateRange": true,
            "title": "Precision",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_recall = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "Recall"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "live_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Recall",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682358315000,
            "noDateRange": true,
            "title": "Recall",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_specificity = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "Specificity"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "live_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Specificity",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682358408000,
            "noDateRange": true,
            "title": "Specificity",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_f1 = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "F1"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "live_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "column": "feature",
                            "aggregation": "COUNT",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "F1",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682357974000,
            "noDateRange": true,
            "title": "F1",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_cm = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature2",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE"
                        },
                        {
                            "column": "feature",
                            "mapping": "SERIES"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "live_confusion"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "column": "feature",
                            "order": "DESCENDING"
                        },
                        {
                            "column": "feature2",
                            "order": "ASCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "feature"
                        },
                        {
                            "column": "feature2"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_heatmap",
                    "overrides": {
                        "cat_scale_y_title": "Actual",
                        "inner_margin": "5",
                        "font_size": "Largest",
                        "color_theme": "gradient-2",
                        "cat_scale_x_title": "Prediction",
                        "datalabel_text": "%_VALUE ",
                        "hide_legend": "true"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Confusion Matrix",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682530988000,
            "noDateRange": true,
            "title": "Confusion Matrix",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

live_history = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature2",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE"
                        },
                        {
                            "column": "feature",
                            "mapping": "SERIES"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "live_perf_history"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "feature"
                        },
                        {
                            "column": "feature2"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_two_trendline",
                    "overrides": {
                        "value_scale_min_right": "0",
                        "fill_missing_dates": "true",
                        "series_filter": "none",
                        "line_style": "Plain with Symbols",
                        "range_filter_y": "none",
                        "range_filter_time": "none",
                        "value_scale_max": "1",
                        "dual_y_scales": "true",
                        "range_filter_x": "none",
                        "hide_series": "none",
                        "row_filter": "none",
                        "value_scale_min": "0",
                        "value_scale_max_right": "1"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Historical Performance",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682514993000,
            "noDateRange": true,
            "title": "Historical Performance",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

train_accuracy = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "Accuracy"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Accuracy",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682426563000,
            "noDateRange": true,
            "title": "Accuracy",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

train_precision = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "Precision"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Precision",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682426608000,
            "noDateRange": true,
            "title": "Precision",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

train_recall = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "Recall"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Recall",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682426618000,
            "noDateRange": true,
            "title": "Recall",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

train_specificity = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "Specificity"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Specificity",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1683051127000,
            "noDateRange": true,
            "title": "Specificity",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

train_f1 = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "format": {
                                "type": "percent",
                                "format": "###,###.0",
                                "commas": true,
                                "percentMultiplied": true,
                                "precision": 1,
                                "percent": true
                            }
                        },
                        {
                            "column": "value",
                            "mapping": "ITEM"
                        }
                    ],
                    "filters": [
                        {
                            "column": "feature",
                            "values": [
                                "F1"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "feature"
                        },
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_singlevalue",
                    "overrides": {},
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "F1",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682426597000,
            "noDateRange": true,
            "title": "F1",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

train_cm = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "feature2",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE"
                        },
                        {
                            "column": "feature",
                            "mapping": "SERIES"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "train_confusion"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [
                        {
                            "column": "feature",
                            "order": "DESCENDING"
                        },
                        {
                            "column": "feature2",
                            "order": "DESCENDING"
                        }
                    ],
                    "groupBy": [
                        {
                            "column": "feature"
                        },
                        {
                            "column": "feature2"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": []
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_heatmap",
                    "overrides": {
                        "cat_scale_y_title": "Actual",
                        "inner_margin": "5",
                        "font_size": "Largest",
                        "color_theme": "gradient-2",
                        "cat_scale_x_title": "Prediction",
                        "datalabel_text": "%_VALUE ",
                        "hide_legend": "true"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Confusion Matrix",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682959332000,
            "noDateRange": true,
            "title": "Confusion Matrix",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

threshold_lines = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value2",
                            "mapping": "ITEM"
                        },
                        {
                            "column": "value",
                            "mapping": "VALUE"
                        },
                        {
                            "column": "feature",
                            "mapping": "SERIES"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "feature"
                        },
                        {
                            "column": "value2"
                        },
                        {
                            "column": "value"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": [
                    {
                        "templateId": 10458,
                        "id": "calculation_f81fe50b-eefb-47cd-bf66-8fa2ad10d235",
                        "name": "test",
                        "formula": "case when `feature` = 'Recall' and `value2` > .9 then 1 else 0 end",
                        "status": "VALID",
                        "persistedOnDataSource": false,
                        "columnPositions": [
                            {
                                "columnName": "`feature`",
                                "columnPosition": 10
                            },
                            {
                                "columnName": "`value2`",
                                "columnPosition": 35
                            }
                        ],
                        "cacheWindow": "non_dynamic",
                        "locked": false,
                        "owner": 352859788,
                        "usedByOtherCards": false,
                        "isAnalytic": false,
                        "referenceCount": 0,
                        "dataType": "numeric",
                        "isAggregatable": true,
                        "bignumber": false
                    }
                ]
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#D9EBFDFF",
                            "textColor": "#242a2c",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                ".2"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#B7DAF5FF",
                            "textColor": "#202b2f",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                ".4"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#90C4E4FF",
                            "textColor": "#1d2b33",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                ".6"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#73B0D7FF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                ".8"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#4E8CBAFF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#D9EBFDFF",
                            "textColor": "#242a2c",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value",
                            "values": [
                                ".2"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#B7DAF5FF",
                            "textColor": "#202b2f",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    },
                    {
                        "condition": {
                            "column": "value",
                            "values": [
                                ".4"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#90C4E4FF",
                            "textColor": "#1d2b33",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    },
                    {
                        "condition": {
                            "column": "value",
                            "values": [
                                ".6"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#73B0D7FF",
                            "textColor": "#1a2b36",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    },
                    {
                        "condition": {
                            "column": "value",
                            "values": [
                                ".8"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#4E8CBAFF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    }
                ],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_two_trendline",
                    "overrides": {
                        "line_thickness": "Medium",
                        "line_style": "Default"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Metrics by Thresholds",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1682425424000,
            "noDateRange": true,
            "title": "Metrics by Thresholds",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

threshold_table = '''
    {
        "definition": {
            "subscriptions": {
                "main": {
                    "name": "main",
                    "columns": [
                        {
                            "column": "value2",
                            "mapping": "ROW",
                            "alias": "Threshold"
                        },
                        {
                            "column": "feature",
                            "mapping": "COLUMN",
                            "alias": "Metric"
                        },
                        {
                            "column": "value",
                            "aggregation": "SUM",
                            "mapping": "VALUE",
                            "alias": "Train"
                        }
                    ],
                    "filters": [
                        {
                            "column": "table",
                            "values": [
                                "train_perf"
                            ],
                            "filterType": "LEGACY",
                            "operand": "IN",
                            "dataType": "string",
                            "label": "table"
                        }
                    ],
                    "orderBy": [],
                    "groupBy": [
                        {
                            "column": "feature"
                        },
                        {
                            "column": "value2"
                        }
                    ],
                    "fiscal": false,
                    "projection": false,
                    "distinct": false
                }
            },
            "formulas": {
                "dsUpdated": [],
                "dsDeleted": [],
                "card": [
                    {
                        "templateId": 10438,
                        "id": "calculation_5b9b5b66-08ba-4753-b7b1-4540a1f92ee0",
                        "name": "test",
                        "formula": "case when `feature` = 'Recall' and `value2` > .9 then 1 else 0 end",
                        "status": "VALID",
                        "persistedOnDataSource": false,
                        "columnPositions": [
                            {
                                "columnName": "`feature`",
                                "columnPosition": 10
                            },
                            {
                                "columnName": "`value2`",
                                "columnPosition": 35
                            }
                        ],
                        "cacheWindow": "non_dynamic",
                        "locked": false,
                        "owner": 352859788,
                        "usedByOtherCards": false,
                        "isAnalytic": false,
                        "referenceCount": 0,
                        "dataType": "numeric",
                        "isAggregatable": true,
                        "bignumber": false
                    }
                ]
            },
            "annotations": {
                "new": [],
                "modified": [],
                "deleted": []
            },
            "conditionalFormats": {
                "card": [
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#D9EBFDFF",
                            "textColor": "#242a2c",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                ".2"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#B7DAF5FF",
                            "textColor": "#202b2f",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                ".4"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#90C4E4FF",
                            "textColor": "#1d2b33",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                ".6"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#73B0D7FF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value2",
                            "values": [
                                ".8"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#4E8CBAFF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value",
                            "values": [
                                "0"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#D9EBFDFF",
                            "textColor": "#242a2c",
                            "textStyle": "PLAIN",
                            "applyToRow": false
                        }
                    },
                    {
                        "condition": {
                            "column": "value",
                            "values": [
                                ".2"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#B7DAF5FF",
                            "textColor": "#202b2f",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    },
                    {
                        "condition": {
                            "column": "value",
                            "values": [
                                ".4"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#90C4E4FF",
                            "textColor": "#1d2b33",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    },
                    {
                        "condition": {
                            "column": "value",
                            "values": [
                                ".6"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#73B0D7FF",
                            "textColor": "#1a2b36",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    },
                    {
                        "condition": {
                            "column": "value",
                            "values": [
                                ".8"
                            ],
                            "dataSourceId": "<DSID>",
                            "filterType": "LEGACY",
                            "operand": "GREAT_THAN_EQUALS_TO"
                        },
                        "format": {
                            "color": "#4E8CBAFF",
                            "textColor": "#ffffff",
                            "textStyle": "PLAIN",
                            "applyToRow": true
                        }
                    }
                ],
                "datasource": []
            },
            "controls": [],
            "segments": {
                "active": [],
                "create": [],
                "update": [],
                "delete": []
            },
            "charts": {
                "main": {
                    "component": "main",
                    "chartType": "badge_pivot_table",
                    "overrides": {
                        "header_row_fill_color": "#31689BFF",
                        "total_row": "false",
                        "subtotal_rows": "true",
                        "total_col": "false",
                        "attr_header_row": "Default",
                        "subtotal_columns": "true"
                    },
                    "goal": null
                }
            },
            "dynamicTitle": {
                "text": [
                    {
                        "text": "Table",
                        "type": "TEXT"
                    }
                ]
            },
            "dynamicDescription": {
                "text": [],
                "displayOnCardDetails": true
            },
            "chartVersion": "10",
            "allowTableDrill": true,
            "modified": 1683051521000,
            "noDateRange": true,
            "title": "Table",
            "description": ""
        },
        "dataProvider": {
            "dataSourceId": "<DSID>"
        },
        "variables": true
    }
'''

roc_curve = (
    '''let domo = window.domo;\nlet datasets = window.datasets;\n\nlet fields = [\'value\', \'value2\', \'value3\', \'feature2\', \'index\'];\nlet where = [\'table=roc\', \'feature=roc\'];\nlet query = `/data/v1/${datasets[0]}?fields=${fields.join()}&filter=${where.join()}`;\n\ndomo\n  .get(query)\n  .then(res => {\n  \n  \tlet fpr1 = res.filter(r => r.value3 === 1).map(r => r.value)\n    let tpr1 = res.filter(r => r.value3 === 1).map(r => r.value2)\n    let t1 = res.filter(r => r.value3 === 1).map(r => r.feature2)\n    \n    let fpr0 = res.map(r => r.value)\n    let tpr0 = res.map(r => r.value2)\n    let t0 = res.map(r => r.feature2)\n    \n    let auc = res.map(r => r.index)[0]\n    \n    let trace1 = {\n      x: [0, 1],\n      y: [0, 1],\n      mode: \'lines\',\n      type: \'scatter\',\n      line: {\n        dash: \'dot\',\n        width: 2,\n        color: \'gray\',\n      }\n    };\n\n    let trace3 = {\n      x: fpr1,\n      y: tpr1,\n      text: t1,\n      mode: \'markers\',\n      type: \'scatter\',\n\t\t\tmarker: {\n      \tcolor: \'#31689B\',\n        size: 8,\n      },\n      hovertemplate: \n      \t"<b>Threshold: %{text}</b><br><br>" +\n        "%{yaxis.title.text}: %{y:.1%}<br>" +\n        "%{xaxis.title.text}: %{x:.1%}<br>" +\n        "<extra></extra>"\n    };\n  \n\t\tlet trace2 = {\n      x: fpr0,\n      y: tpr0,\n      text: t0,\n      mode: \'lines+markers\',\n      type: \'scatter\',\n      fill: \'tozeroy\',\n      fillcolor: \'#B7DAF555\',\n      line: {\n      \twidth: 2,\n        color: \'#31689B\',\n      },\n      marker: {\n      \tcolor: \'#31689B\',\n        size:  5,\n      },\n      hovertemplate: \n      \t"<b>Threshold: %{text}</b><br><br>" +\n        "%{yaxis.title.text}: %{y:.1%}<br>" +\n        "%{xaxis.title.text}: %{x:.1%}<br>" +\n        "<extra></extra>"\n    };\n\n    let data = [trace1, trace2, trace3];\n\n  \tlet layout = {\n    \tshowlegend: false,\n      title: `ROC Curve, AUC=${Number(auc).toFixed(2)}`,\n      xaxis: {\n        title: \'False Positive Rate\',\n        range: [-0.02, 1.02]\n      },\n      yaxis: {\n        title: \'True Positive Rate\',\n        range: [-0.02, 1.02]\n      },\n      hoverlabel: { bgcolor: "#FFF" },\n      margin: {\n        l: 70,\n        r: 40,\n        b: 70,\n        t: 70,\n        pad: 5\n      },\n    }\n  \n    let config = {\n  \t\tdisplayModeBar: false,\n\t\t}\n  \n    Plotly.newPlot(\'plot\', data, layout, config)\n\t})\n''',
    '''<script src=\"https://cdn.plot.ly/plotly-2.18.2.min.js\"></script>\n\n<div id=\"plot\"></div>''',
    '',
)

pr_curve = (
    '''let domo = window.domo;\nlet datasets = window.datasets;\n\nlet fields = ['value', 'value2', 'value3', 'index', 'feature2'];\nlet where = ['table=roc', 'feature=pr'];\nlet query = `/data/v1/${datasets[0]}?fields=${fields.join()}&filter=${where.join()}`;\n\ndomo\n  .get(query)\n  .then(res => {\n\t\t\n    let p1 = res.filter(r => r.value3 === 1).map(r => r.value)\n    let r1 = res.filter(r => r.value3 === 1).map(r => r.value2)\n    let t1 = res.filter(r => r.value3 === 1).map(r => r.feature2)\n    let p0 = res.map(r => r.value)\n    let r0 = res.map(r => r.value2)\n    let t0 = res.map(r => r.feature2)\n    let auc = res.map(r => r.index)[0]\n    \n  \tlet trace3 = {\n      x: r1,\n      y: p1,\n      text: t1,\n      mode: 'markers',\n      type: 'scatter',\n\t\t\tmarker: {\n      \tcolor: '#31689B',\n        size: 8,\n      },\n      hovertemplate: \n      \t\"<b>Threshold: %{text}</b><br><br>\" +\n        \"%{yaxis.title.text}: %{y:.1%}<br>\" +\n        \"%{xaxis.title.text}: %{x:.1%}<br>\" +\n        \"<extra></extra>\"\n    };\n  \n    let trace2 = {\n      x: r0,\n      y: p0,\n      text: t0,\n      mode: 'lines+markers',\n      type: 'scatter',\n      fill: 'tozeroy',\n      fillcolor: '#B7DAF555',\n      line: {\n      \twidth: 2,\n        color: '#31689B',\n      },\n      marker: {\n      \tcolor: '#31689B',\n        size:  5,\n      },\n      hovertemplate: \n      \t\"<b>Threshold: %{text}</b><br><br>\" +\n        \"%{yaxis.title.text}: %{y:.1%}<br>\" +\n        \"%{xaxis.title.text}: %{x:.1%}<br>\" +\n        \"<extra></extra>\"\n    };\n\n    let data = [trace2, trace3];\n\n  \tlet layout = {\n    \tshowlegend: false,\n      title: `Precision-Recall Curve, AP=${Number(auc).toFixed(2)}`,\n      xaxis: {\n        title: 'Recall',\n        range: [-0.02, 1.02]\n      },\n      yaxis: {\n        title: 'Precision',\n        range: [-0.02, 1.02]\n      },\n      hoverlabel: { bgcolor: \"#FFF\" },\n      margin: {\n        l: 70,\n        r: 40,\n        b: 70,\n        t: 70,\n        pad: 5\n      },\n    }\n  \n    let config = {\n  \t\tdisplayModeBar: false,\n\t\t}\n  \n    Plotly.newPlot('plot', data, layout, config)\n\t})\n\t''',
    '''<script src=\"https://cdn.plot.ly/plotly-2.18.2.min.js\"></script>\n<div id=\"plot\"></div>''',
    '',
)

nav_btn_big = (
    '''<div class="centerAlignedContent"><div style='white-space: pre-wrap'><div style="text-align:center"><span style="font-weight:600;font-size:32px"><TEXT></span></div></div></div>''',
    '''{"object":"value","document":{"object":"document","data":{"vertAlignment":"center"},"nodes":[{"object":"block","type":"p","data":{"alignment":"center"},"nodes":[{"object":"text","leaves":[{"object":"leaf","text":"<TEXT>","marks":[{"object":"mark","type":"strong","data":{}},{"object":"mark","type":"header","data":{}}]}]}]}]}}'''
)

# this is actually the same as `header`, position and colors defined by layout
nav_btn = (
    '''<div class="centerAlignedContent"><div style='white-space: pre-wrap'><div style="text-align:center"><span style="font-size:24px;font-weight:600"><TEXT></span></div></div></div>''',
    '''{"object":"value","document":{"object":"document","data":{"vertAlignment":"center"},"nodes":[{"object":"block","type":"p","data":{"alignment":"center"},"nodes":[{"object":"text","leaves":[{"object":"leaf","text":"<TEXT>","marks":[{"object":"mark","type":"strong","data":{}},{"object":"mark","type":"h1","data":{}}]}]}]}]}}'''
)

header = (
    '''<div class="centerAlignedContent"><div style='white-space: pre-wrap'><div style="text-align:center"><span style="font-size:24px;font-weight:600"><TEXT></span></div></div></div>''',
    '''{"object":"value","document":{"object":"document","data":{"vertAlignment":"center"},"nodes":[{"object":"block","type":"p","data":{"alignment":"center"},"nodes":[{"object":"text","leaves":[{"object":"leaf","text":"<TEXT>","marks":[{"object":"mark","type":"h1","data":{}},{"object":"mark","type":"strong","data":{}}]}]}]}]}}'''
)

subheader = (
    '''<div class="bottomAlignedContent"><div style='white-space: pre-wrap'><div><span style="font-weight:600;font-size:24px"><TEXT></span></div></div></div>''',
    '''{"object":"value","document":{"object":"document","data":{"vertAlignment":"bottom"},"nodes":[{"object":"block","type":"p","data":{},"nodes":[{"object":"text","leaves":[{"object":"leaf","text":"<TEXT>","marks":[{"object":"mark","type":"strong","data":{}},{"object":"mark","type":"h1","data":{}}]}]}]}]}}''',
)

blank = (
    '''"<div style='white-space: pre-wrap'><div></div><div></div><div></div></div>"'''
    '''{"object":"value","document":{"object":"document","data":{},"nodes":[{"object":"block","type":"p","data":{},"nodes":[{"object":"text","leaves":[{"object":"leaf","text":"","marks":[]}]}]}]}}'''
)

page0_layout = '''
    {
        "layoutId": <LAYOUT_ID>,
        "pageUrn": "<PAGE_0>",
        "printFriendly": true,
        "background": {
            "id": 22862,
            "cropHeight": null,
            "cropWidth": null,
            "x": null,
            "y": null,
            "dataFileId": null,
            "imageBrightness": null,
            "imageHeight": null,
            "imageWidth": null,
            "selectedColor": "#E8E8E8",
            "textColor": "#4A4A4A",
            "type": "COLOR",
            "darkMode": false,
            "alpha": 1,
            "src": null
        },
        "isDynamic": false,
        "content": [
            {
                "id": 54220,
                "contentKey": 0,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_3>,
                "cardUrn": "<NAV_PAGE_3>",
                "backgroundId": 22863,
                "background": {
                    "id": 22863,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_3>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_3>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 54221,
                "contentKey": 2,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <SUMMARY_TABLE>,
                "cardUrn": "<SUMMARY_TABLE>",
                "type": "CARD"
            },
            {
                "id": 54222,
                "contentKey": 3,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_0>,
                "cardUrn": "<NAV_PAGE_0>",
                "backgroundId": 22864,
                "background": {
                    "id": 22864,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#4E8CBA",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_0>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_0>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 54223,
                "contentKey": 7,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <DATA_STATUS>,
                "cardUrn": "<DATA_STATUS>",
                "type": "CARD"
            },
            {
                "id": 54224,
                "contentKey": 14,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_1>,
                "cardUrn": "<NAV_PAGE_1>",
                "backgroundId": 22865,
                "background": {
                    "id": 22865,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_1>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_1>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 54225,
                "contentKey": 20,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_4>,
                "cardUrn": "<NAV_PAGE_4>",
                "backgroundId": 22866,
                "background": {
                    "id": 22866,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_4>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_4>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 54226,
                "contentKey": 21,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_2>,
                "cardUrn": "<NAV_PAGE_2>",
                "backgroundId": 22867,
                "background": {
                    "id": 22867,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_2>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_2>"
                    }
                },
                "type": "CARD"
            }
        ],
        "standard": {
            "aspectRatio": 1.67,
            "width": 60,
            "frameMargin": null,
            "framePadding": null,
            "type": "STANDARD",
            "template": [
                {
                    "contentKey": 3,
                    "x": 0,
                    "y": 0,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 0,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 21,
                    "x": 15,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 0,
                    "x": 30,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 20,
                    "x": 45,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 16,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 0,
                    "y": 19,
                    "width": 60,
                    "height": 21,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 0,
                    "y": 40,
                    "width": 60,
                    "height": 19,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "compact": {
            "aspectRatio": 1,
            "width": 12,
            "frameMargin": null,
            "framePadding": null,
            "type": "COMPACT",
            "template": [
                {
                    "contentKey": 3,
                    "x": 0,
                    "y": 0,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 0,
                    "y": 6,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 20,
                    "x": 0,
                    "y": 12,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 18,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 21,
                    "x": 0,
                    "y": 24,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 30,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 0,
                    "y": 31,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 0,
                    "y": 37,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "hasPageBreaks": false
    }
'''

page1_layout_c = '''
    {
        "layoutId": <LAYOUT_ID>,
        "pageUrn": "<PAGE_1>",
        "printFriendly": true,
        "background": {
            "id": 8994,
            "cropHeight": null,
            "cropWidth": null,
            "x": null,
            "y": null,
            "dataFileId": null,
            "imageBrightness": null,
            "imageHeight": null,
            "imageWidth": null,
            "selectedColor": "#E8E8E8",
            "textColor": "#4A4A4A",
            "type": "COLOR",
            "darkMode": false,
            "alpha": 1,
            "src": null
        },
        "isDynamic": false,
        "content": [
            {
                "id": 53569,
                "contentKey": 0,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_1>,
                "cardUrn": "<HEADER_1>",
                "backgroundId": 22416,
                "background": {
                    "id": 22416,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 53570,
                "contentKey": 1,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_ACCURACY>,
                "cardUrn": "<LIVE_ACCURACY>",
                "type": "CARD"
            },
            {
                "id": 53571,
                "contentKey": 2,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_CM>,
                "cardUrn": "<LIVE_CM>",
                "type": "CARD"
            },
            {
                "id": 53572,
                "contentKey": 3,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_F1>,
                "cardUrn": "<LIVE_F1>",
                "type": "CARD"
            },
            {
                "id": 53573,
                "contentKey": 4,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_PRECISION>,
                "cardUrn": "<LIVE_PRECISION>",
                "type": "CARD"
            },
            {
                "id": 53574,
                "contentKey": 5,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_RECALL>,
                "cardUrn": "<LIVE_RECALL>",
                "type": "CARD"
            },
            {
                "id": 53575,
                "contentKey": 7,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_1>,
                "cardUrn": "<NAV_PAGE_1>",
                "backgroundId": 22417,
                "background": {
                    "id": 22417,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#4E8CBA",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_1>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_1>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53576,
                "contentKey": 8,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_3>,
                "cardUrn": "<NAV_PAGE_3>",
                "backgroundId": 22418,
                "background": {
                    "id": 22418,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_3>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_3>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53577,
                "contentKey": 9,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TARGET_DRIFT>,
                "cardUrn": "<TARGET_DRIFT>",
                "type": "CARD"
            },
            {
                "id": 53578,
                "contentKey": 10,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TARGET_DRIFT_LABEL>,
                "cardUrn": "<TARGET_DRIFT_LABEL>",
                "type": "CARD"
            },
            {
                "id": 53579,
                "contentKey": 11,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_HISTORY>,
                "cardUrn": "<LIVE_HISTORY>",
                "type": "CARD"
            },
            {
                "id": 53580,
                "contentKey": 13,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <DRIFT_SCATTER>,
                "cardUrn": "<DRIFT_SCATTER>",
                "type": "CARD"
            },
            {
                "id": 53581,
                "contentKey": 14,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <FEATURE_DRIFT>,
                "cardUrn": "<FEATURE_DRIFT>",
                "type": "CARD"
            },
            {
                "id": 53582,
                "contentKey": 15,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <FEATURE_DRIFT_LABEL>,
                "cardUrn": "<FEATURE_DRIFT_LABEL>",
                "type": "CARD"
            },
            {
                "id": 53583,
                "contentKey": 16,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_2>,
                "cardUrn": "<HEADER_2>",
                "backgroundId": 22419,
                "background": {
                    "id": 22419,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 53584,
                "contentKey": 17,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <PAGE1_BLANK>,
                "cardUrn": "<PAGE1_BLANK>",
                "backgroundId": 22420,
                "background": {
                    "id": 22420,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#E8E8E8",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 53585,
                "contentKey": 18,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_4>,
                "cardUrn": "<NAV_PAGE_4>",
                "backgroundId": 22421,
                "background": {
                    "id": 22421,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_4>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_4>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53586,
                "contentKey": 20,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_SPECIFICITY>,
                "cardUrn": "<LIVE_SPECIFICITY>",
                "type": "CARD"
            },
            {
                "id": 53587,
                "contentKey": 21,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_0>,
                "cardUrn": "<NAV_PAGE_0>",
                "backgroundId": 22422,
                "background": {
                    "id": 22422,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_0>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_0>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53588,
                "contentKey": 22,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_2>,
                "cardUrn": "<NAV_PAGE_2>",
                "backgroundId": 22423,
                "background": {
                    "id": 22423,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_2>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_2>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53589,
                "contentKey": 23,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <FEATURE_DRIFT_FILTER>,
                "cardUrn": "<FEATURE_DRIFT_FILTER>",
                "interaction": {
                    "type": "STANDARD",
                    "config": {
                        "openInNewWindow": false,
                        "allowCardToCardInteractions": true,
                        "selectedCardUrns": [
                            "<FEATURE_DRIFT_LABEL>",
                            "<FEATURE_DRIFT>",
                            "<FEATURE_DRIFT_FILTER>"
                        ],
                        "selectIndividualCards": true
                    }
                },
                "type": "CARD"
            }
        ],
        "standard": {
            "aspectRatio": 1.67,
            "width": 60,
            "frameMargin": null,
            "framePadding": null,
            "type": "STANDARD",
            "template": [
                {
                    "contentKey": 21,
                    "x": 0,
                    "y": 0,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 0,
                    "y": 8,
                    "width": 16,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 22,
                    "x": 16,
                    "y": 8,
                    "width": 14,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 30,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 18,
                    "x": 45,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 0,
                    "y": 16,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 19,
                    "width": 60,
                    "height": 7,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 26,
                    "width": 20,
                    "height": 15,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 3,
                    "x": 20,
                    "y": 26,
                    "width": 20,
                    "height": 15,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 40,
                    "y": 26,
                    "width": 20,
                    "height": 30,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 4,
                    "x": 0,
                    "y": 41,
                    "width": 13,
                    "height": 15,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 13,
                    "y": 41,
                    "width": 13,
                    "height": 15,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 20,
                    "x": 26,
                    "y": 41,
                    "width": 14,
                    "height": 15,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 189,
                    "x": 0,
                    "y": 56,
                    "width": 60,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 11,
                    "x": 0,
                    "y": 56,
                    "width": 60,
                    "height": 30,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 12,
                    "x": 0,
                    "y": 86,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 16,
                    "x": 0,
                    "y": 89,
                    "width": 60,
                    "height": 7,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 190,
                    "x": 0,
                    "y": 96,
                    "width": 60,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 9,
                    "x": 0,
                    "y": 96,
                    "width": 60,
                    "height": 30,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 0,
                    "y": 126,
                    "width": 60,
                    "height": 9,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 17,
                    "x": 0,
                    "y": 135,
                    "width": 60,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 191,
                    "x": 0,
                    "y": 141,
                    "width": 60,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 13,
                    "x": 0,
                    "y": 141,
                    "width": 30,
                    "height": 38,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 23,
                    "x": 30,
                    "y": 141,
                    "width": 30,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 30,
                    "y": 149,
                    "width": 30,
                    "height": 30,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 15,
                    "x": 0,
                    "y": 179,
                    "width": 60,
                    "height": 9,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "compact": {
            "aspectRatio": 1,
            "width": 12,
            "frameMargin": null,
            "framePadding": null,
            "type": "COMPACT",
            "template": [
                {
                    "contentKey": 21,
                    "x": 0,
                    "y": 0,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 22,
                    "x": 0,
                    "y": 6,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 18,
                    "x": 0,
                    "y": 12,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 0,
                    "y": 18,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 0,
                    "y": 24,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 0,
                    "y": 30,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 31,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 37,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 4,
                    "x": 0,
                    "y": 43,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 20,
                    "x": 0,
                    "y": 49,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 3,
                    "x": 0,
                    "y": 55,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 0,
                    "y": 61,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 0,
                    "y": 67,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 189,
                    "x": 0,
                    "y": 73,
                    "width": 12,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false,
                    "isHidden": true
                },
                {
                    "contentKey": 11,
                    "x": 0,
                    "y": 73,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 12,
                    "x": 0,
                    "y": 79,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 16,
                    "x": 0,
                    "y": 80,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 190,
                    "x": 0,
                    "y": 86,
                    "width": 12,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false,
                    "isHidden": true
                },
                {
                    "contentKey": 9,
                    "x": 0,
                    "y": 86,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 0,
                    "y": 92,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 17,
                    "x": 0,
                    "y": 98,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 191,
                    "x": 0,
                    "y": 104,
                    "width": 12,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false,
                    "isHidden": true
                },
                {
                    "contentKey": 13,
                    "x": 0,
                    "y": 104,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 23,
                    "x": 0,
                    "y": 110,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 0,
                    "y": 116,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 15,
                    "x": 0,
                    "y": 122,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "hasPageBreaks": false
    }
'''

page1_layout_r = '''
    {
        "layoutId": <LAYOUT_ID>,
        "pageUrn": "<PAGE_1>",
        "printFriendly": true,
        "background": {
            "id": 22490,
            "cropHeight": null,
            "cropWidth": null,
            "x": null,
            "y": null,
            "dataFileId": null,
            "imageBrightness": null,
            "imageHeight": null,
            "imageWidth": null,
            "selectedColor": "#E8E8E8",
            "textColor": "#4A4A4A",
            "type": "COLOR",
            "darkMode": false,
            "alpha": 1,
            "src": null
        },
        "isDynamic": false,
        "content": [
            {
                "id": 56824,
                "contentKey": 0,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_0>,
                "cardUrn": "<NAV_PAGE_0>",
                "backgroundId": 23533,
                "background": {
                    "id": 23533,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_0>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_0>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 56825,
                "contentKey": 1,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_1>,
                "cardUrn": "<NAV_PAGE_1>",
                "backgroundId": 23534,
                "background": {
                    "id": 23534,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#4E8CBA",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_1>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_1>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 56826,
                "contentKey": 2,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_2>,
                "cardUrn": "<NAV_PAGE_2>",
                "backgroundId": 23535,
                "background": {
                    "id": 23535,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_2>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_2>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 56827,
                "contentKey": 3,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_3>,
                "cardUrn": "<NAV_PAGE_3>",
                "backgroundId": 23536,
                "background": {
                    "id": 23536,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_3>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_3>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 56828,
                "contentKey": 4,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_4>,
                "cardUrn": "<NAV_PAGE_4>",
                "backgroundId": 23537,
                "background": {
                    "id": 23537,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_4>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_4>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 56829,
                "contentKey": 5,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_R2>,
                "cardUrn": "<LIVE_R2>",
                "type": "CARD"
            },
            {
                "id": 56830,
                "contentKey": 6,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_MAE>,
                "cardUrn": "<LIVE_MAE>",
                "type": "CARD"
            },
            {
                "id": 56831,
                "contentKey": 7,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_RMSE>,
                "cardUrn": "<LIVE_RMSE>",
                "type": "CARD"
            },
            {
                "id": 56832,
                "contentKey": 9,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_1>,
                "cardUrn": "<HEADER_1>",
                "backgroundId": 23538,
                "background": {
                    "id": 23538,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 56833,
                "contentKey": 10,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_HISTORY_1>,
                "cardUrn": "<LIVE_HISTORY_1>",
                "type": "CARD"
            },
            {
                "id": 56834,
                "contentKey": 12,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_2>,
                "cardUrn": "<HEADER_2>",
                "backgroundId": 23539,
                "background": {
                    "id": 23539,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 56835,
                "contentKey": 13,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TARGET_DRIFT>,
                "cardUrn": "<TARGET_DRIFT>",
                "type": "CARD"
            },
            {
                "id": 56836,
                "contentKey": 14,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TARGET_DRIFT_LABEL>,
                "cardUrn": "<TARGET_DRIFT_LABEL>",
                "type": "CARD"
            },
            {
                "id": 56837,
                "contentKey": 15,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <PAGE1_BLANK>,
                "cardUrn": "<PAGE1_BLANK>",
                "backgroundId": 23540,
                "background": {
                    "id": 23540,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#E8E8E8",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 56838,
                "contentKey": 16,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <FEATURE_DRIFT_FILTER>,
                "cardUrn": "<FEATURE_DRIFT_FILTER>",
                "interaction": {
                    "type": "STANDARD",
                    "config": {
                        "openInNewWindow": false,
                        "allowCardToCardInteractions": true,
                        "selectedCardUrns": [
                            "<FEATURE_DRIFT>",
                            "<FEATURE_DRIFT_FILTER>"
                        ],
                        "selectIndividualCards": true
                    }
                },
                "type": "CARD"
            },
            {
                "id": 56839,
                "contentKey": 17,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <FEATURE_DRIFT>,
                "cardUrn": "<FEATURE_DRIFT>",
                "type": "CARD"
            },
            {
                "id": 56840,
                "contentKey": 18,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <DRIFT_SCATTER>,
                "cardUrn": "<DRIFT_SCATTER>",
                "type": "CARD"
            },
            {
                "id": 56841,
                "contentKey": 19,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <FEATURE_DRIFT_LABEL>,
                "cardUrn": "<FEATURE_DRIFT_LABEL>",
                "type": "CARD"
            },
            {
                "id": 56842,
                "contentKey": 20,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_HISTORY_2>,
                "cardUrn": "<LIVE_HISTORY_2>",
                "type": "CARD"
            },
            {
                "id": 56843,
                "contentKey": 21,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <LIVE_MAPE>,
                "cardUrn": "<LIVE_MAPE>",
                "type": "CARD"
            }
        ],
        "standard": {
            "aspectRatio": 1.67,
            "width": 60,
            "frameMargin": null,
            "framePadding": null,
            "type": "STANDARD",
            "template": [
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 0,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 15,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 3,
                    "x": 30,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 4,
                    "x": 45,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 0,
                    "y": 16,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 9,
                    "x": 0,
                    "y": 19,
                    "width": 60,
                    "height": 7,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 0,
                    "y": 26,
                    "width": 15,
                    "height": 14,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 21,
                    "x": 15,
                    "y": 26,
                    "width": 15,
                    "height": 14,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 30,
                    "y": 26,
                    "width": 15,
                    "height": 14,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 45,
                    "y": 26,
                    "width": 15,
                    "height": 14,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 0,
                    "y": 40,
                    "width": 30,
                    "height": 27,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 20,
                    "x": 30,
                    "y": 40,
                    "width": 30,
                    "height": 27,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 11,
                    "x": 0,
                    "y": 67,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 77,
                    "x": 0,
                    "y": 70,
                    "width": 60,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 12,
                    "x": 0,
                    "y": 70,
                    "width": 60,
                    "height": 7,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 13,
                    "x": 0,
                    "y": 77,
                    "width": 60,
                    "height": 30,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 0,
                    "y": 107,
                    "width": 60,
                    "height": 9,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 15,
                    "x": 0,
                    "y": 116,
                    "width": 60,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 78,
                    "x": 0,
                    "y": 122,
                    "width": 60,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 18,
                    "x": 0,
                    "y": 122,
                    "width": 30,
                    "height": 37,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 16,
                    "x": 30,
                    "y": 122,
                    "width": 30,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 17,
                    "x": 30,
                    "y": 130,
                    "width": 30,
                    "height": 29,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 19,
                    "x": 0,
                    "y": 159,
                    "width": 60,
                    "height": 9,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "compact": {
            "aspectRatio": 1,
            "width": 12,
            "frameMargin": null,
            "framePadding": null,
            "type": "COMPACT",
            "template": [
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 0,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 6,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 4,
                    "x": 0,
                    "y": 12,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 3,
                    "x": 0,
                    "y": 18,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 0,
                    "y": 24,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 0,
                    "y": 30,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 9,
                    "x": 0,
                    "y": 31,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 0,
                    "y": 37,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 0,
                    "y": 43,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 0,
                    "y": 49,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 21,
                    "x": 0,
                    "y": 55,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 0,
                    "y": 61,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 20,
                    "x": 0,
                    "y": 67,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 11,
                    "x": 0,
                    "y": 73,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 77,
                    "x": 0,
                    "y": 74,
                    "width": 12,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false,
                    "isHidden": true
                },
                {
                    "contentKey": 12,
                    "x": 0,
                    "y": 74,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 13,
                    "x": 0,
                    "y": 80,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 0,
                    "y": 86,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 15,
                    "x": 0,
                    "y": 92,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 78,
                    "x": 0,
                    "y": 98,
                    "width": 12,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false,
                    "isHidden": true
                },
                {
                    "contentKey": 18,
                    "x": 0,
                    "y": 98,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 16,
                    "x": 0,
                    "y": 104,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 17,
                    "x": 0,
                    "y": 110,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 19,
                    "x": 0,
                    "y": 116,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "hasPageBreaks": false
    }
'''

page2_layout = '''
    {
        "layoutId": <LAYOUT_ID>,
        "pageUrn": "<PAGE_2>",
        "printFriendly": true,
        "background": {
            "id": 9080,
            "cropHeight": null,
            "cropWidth": null,
            "x": null,
            "y": null,
            "dataFileId": null,
            "imageBrightness": null,
            "imageHeight": null,
            "imageWidth": null,
            "selectedColor": "#E8E8E8",
            "textColor": "#4A4A4A",
            "type": "COLOR",
            "darkMode": false,
            "alpha": 1,
            "src": null
        },
        "isDynamic": false,
        "content": [
            {
                "id": 53904,
                "contentKey": 0,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_2>,
                "cardUrn": "<NAV_PAGE_2>",
                "backgroundId": 22669,
                "background": {
                    "id": 22669,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#4E8CBA",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_2>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_2>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53905,
                "contentKey": 1,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_0>,
                "cardUrn": "<NAV_PAGE_0>",
                "backgroundId": 22670,
                "background": {
                    "id": 22670,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_0>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_0>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53906,
                "contentKey": 2,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <PARTIAL_FEAT_FILTER>,
                "cardUrn": "<PARTIAL_FEAT_FILTER>",
                "interaction": {
                    "type": "STANDARD",
                    "config": {
                        "openInNewWindow": false,
                        "allowCardToCardInteractions": true,
                        "selectedCardUrns": [
                            "<PARTIAL_FEAT_FILTER>",
                            "<PARTIAL>"
                        ],
                        "selectIndividualCards": true
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53907,
                "contentKey": 3,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <SHAP_WATERFALL>,
                "cardUrn": "<SHAP_WATERFALL>",
                "type": "CARD"
            },
            {
                "id": 53908,
                "contentKey": 4,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <PARTIAL>,
                "cardUrn": "<PARTIAL>",
                "type": "CARD"
            },
            {
                "id": 53909,
                "contentKey": 5,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <OBS_TABLE>,
                "cardUrn": "<OBS_TABLE>",
                "type": "CARD"
            },
            {
                "id": 53910,
                "contentKey": 6,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_4>,
                "cardUrn": "<NAV_PAGE_4>",
                "backgroundId": 22671,
                "background": {
                    "id": 22671,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_4>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_4>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53911,
                "contentKey": 8,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <PARTIAL_OBS_FILTER_1>,
                "cardUrn": "<PARTIAL_OBS_FILTER_1>",
                "interaction": {
                    "type": "STANDARD",
                    "config": {
                        "openInNewWindow": false,
                        "allowCardToCardInteractions": true,
                        "selectedCardUrns": [
                            "<SHAP_WATERFALL>",
                            "<PARTIAL_OBS_FILTER_2>",
                            "<OBS_TABLE>",
                            "<PARTIAL_OBS_FILTER_1>",
                            "<PARTIAL>"
                        ],
                        "selectIndividualCards": true
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53912,
                "contentKey": 9,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_1>,
                "cardUrn": "<NAV_PAGE_1>",
                "backgroundId": 22672,
                "background": {
                    "id": 22672,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_1>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_1>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53913,
                "contentKey": 10,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_3>,
                "cardUrn": "<NAV_PAGE_3>",
                "backgroundId": 22673,
                "background": {
                    "id": 22673,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_3>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_3>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53914,
                "contentKey": 11,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_2>,
                "cardUrn": "<HEADER_2>",
                "backgroundId": 22674,
                "background": {
                    "id": 22674,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 53915,
                "contentKey": 12,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_1>,
                "cardUrn": "<HEADER_1>",
                "backgroundId": 22675,
                "background": {
                    "id": 22675,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 53916,
                "contentKey": 13,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <PARTIAL_OBS_FILTER_2>,
                "cardUrn": "<PARTIAL_OBS_FILTER_2>",
                "interaction": {
                    "type": "STANDARD",
                    "config": {
                        "openInNewWindow": false,
                        "allowCardToCardInteractions": true,
                        "selectedCardUrns": [
                            "<SHAP_WATERFALL>",
                            "<PARTIAL_OBS_FILTER_2>",
                            "<OBS_TABLE>",
                            "<PARTIAL_OBS_FILTER_1>",
                            "<PARTIAL>"
                        ],
                        "selectIndividualCards": true
                    }
                },
                "type": "CARD"
            }
        ],
        "standard": {
            "aspectRatio": 1.67,
            "width": 60,
            "frameMargin": null,
            "framePadding": null,
            "type": "STANDARD",
            "template": [
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 0,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 9,
                    "x": 0,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 0,
                    "x": 15,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 30,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 45,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 0,
                    "y": 16,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 12,
                    "x": 0,
                    "y": 19,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 0,
                    "y": 27,
                    "width": 23,
                    "height": 10,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 3,
                    "x": 23,
                    "y": 27,
                    "width": 37,
                    "height": 38,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 0,
                    "y": 37,
                    "width": 23,
                    "height": 28,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 0,
                    "y": 65,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 74,
                    "x": 0,
                    "y": 68,
                    "width": 60,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 11,
                    "x": 0,
                    "y": 68,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 13,
                    "x": 0,
                    "y": 76,
                    "width": 23,
                    "height": 10,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 23,
                    "y": 76,
                    "width": 37,
                    "height": 10,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 4,
                    "x": 0,
                    "y": 86,
                    "width": 60,
                    "height": 34,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "compact": {
            "aspectRatio": 1,
            "width": 12,
            "frameMargin": null,
            "framePadding": null,
            "type": "COMPACT",
            "template": [
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 0,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 6,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 9,
                    "x": 0,
                    "y": 12,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 0,
                    "y": 18,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 0,
                    "y": 24,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 0,
                    "y": 30,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 12,
                    "x": 0,
                    "y": 31,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 0,
                    "y": 37,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 0,
                    "y": 43,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 3,
                    "x": 0,
                    "y": 49,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 0,
                    "y": 55,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 74,
                    "x": 0,
                    "y": 56,
                    "width": 12,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false,
                    "isHidden": true
                },
                {
                    "contentKey": 11,
                    "x": 0,
                    "y": 56,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 13,
                    "x": 0,
                    "y": 62,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 0,
                    "y": 68,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 4,
                    "x": 0,
                    "y": 74,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "hasPageBreaks": false
    }
'''

page3_layout_c = '''
    {
        "layoutId": <LAYOUT_ID>,
        "pageUrn": "<PAGE_3>",
        "printFriendly": true,
        "background": {
            "id": 19160,
            "cropHeight": null,
            "cropWidth": null,
            "x": null,
            "y": null,
            "dataFileId": null,
            "imageBrightness": null,
            "imageHeight": null,
            "imageWidth": null,
            "selectedColor": "#E8E8E8",
            "textColor": "#4A4A4A",
            "type": "COLOR",
            "darkMode": false,
            "alpha": 1,
            "src": null
        },
        "isDynamic": false,
        "content": [
            {
                "id": 53603,
                "contentKey": 0,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_0>,
                "cardUrn": "<NAV_PAGE_0>",
                "backgroundId": 22432,
                "background": {
                    "id": 22432,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_0>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_0>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53604,
                "contentKey": 2,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_1>,
                "cardUrn": "<NAV_PAGE_1>",
                "backgroundId": 22433,
                "background": {
                    "id": 22433,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_1>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_1>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53605,
                "contentKey": 3,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_3>,
                "cardUrn": "<NAV_PAGE_3>",
                "backgroundId": 22434,
                "background": {
                    "id": 22434,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#4E8CBA",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_3>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_3>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53606,
                "contentKey": 4,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_4>,
                "cardUrn": "<NAV_PAGE_4>",
                "backgroundId": 22435,
                "background": {
                    "id": 22435,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_4>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_4>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53607,
                "contentKey": 5,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_2>,
                "cardUrn": "<NAV_PAGE_2>",
                "backgroundId": 22436,
                "background": {
                    "id": 22436,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_2>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_2>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53608,
                "contentKey": 6,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TRAIN_ACCURACY>,
                "cardUrn": "<TRAIN_ACCURACY>",
                "type": "CARD"
            },
            {
                "id": 53609,
                "contentKey": 7,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TRAIN_F1>,
                "cardUrn": "<TRAIN_F1>",
                "type": "CARD"
            },
            {
                "id": 53610,
                "contentKey": 8,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TRAIN_CM>,
                "cardUrn": "<TRAIN_CM>",
                "type": "CARD"
            },
            {
                "id": 53611,
                "contentKey": 9,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TRAIN_PRECISION>,
                "cardUrn": "<TRAIN_PRECISION>",
                "type": "CARD"
            },
            {
                "id": 53612,
                "contentKey": 10,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TRAIN_RECALL>,
                "cardUrn": "<TRAIN_RECALL>",
                "type": "CARD"
            },
            {
                "id": 53613,
                "contentKey": 11,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TRAIN_SPECIFICITY>,
                "cardUrn": "<TRAIN_SPECIFICITY>",
                "type": "CARD"
            },
            {
                "id": 53614,
                "contentKey": 12,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <THRESHOLD_LINES>,
                "cardUrn": "<THRESHOLD_LINES>",
                "type": "CARD"
            },
            {
                "id": 53615,
                "contentKey": 13,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <THRESHOLD_DROPDOWN>,
                "cardUrn": "<THRESHOLD_DROPDOWN>",
                "interaction": {
                    "type": "STANDARD",
                    "config": {
                        "openInNewWindow": false,
                        "allowCardToCardInteractions": true,
                        "selectedCardUrns": [
                            "<TRAIN_RECALL>",
                            "<TRAIN_F1>",
                            "<THRESHOLD_DROPDOWN>",
                            "<TRAIN_SPECIFICITY>",
                            "<TRAIN_ACCURACY>",
                            "<TRAIN_PRECISION>",
                            "<TRAIN_CM>"
                        ],
                        "selectIndividualCards": true
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53616,
                "contentKey": 15,
                "compactInteractionDefault": false,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <ROC_CURVE>,
                "cardUrn": "<ROC_CURVE>",
                "type": "CARD"
            },
            {
                "id": 53617,
                "contentKey": 16,
                "compactInteractionDefault": false,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <PR_CURVE>,
                "cardUrn": "<PR_CURVE>",
                "type": "CARD"
            },
            {
                "id": 53618,
                "contentKey": 17,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_1>,
                "cardUrn": "<HEADER_1>",
                "backgroundId": 22437,
                "background": {
                    "id": 22437,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 53619,
                "contentKey": 18,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <THRESHOLD_TABLE>,
                "cardUrn": "<THRESHOLD_TABLE>",
                "type": "CARD"
            },
            {
                "id": 53620,
                "contentKey": 19,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_2>,
                "cardUrn": "<HEADER_2>",
                "backgroundId": 22438,
                "background": {
                    "id": 22438,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            }
        ],
        "standard": {
            "aspectRatio": 1.67,
            "width": 60,
            "frameMargin": null,
            "framePadding": null,
            "type": "STANDARD",
            "template": [
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 0,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 0,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 15,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 3,
                    "x": 30,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 4,
                    "x": 45,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 16,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 17,
                    "x": 0,
                    "y": 19,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 13,
                    "x": 0,
                    "y": 27,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 0,
                    "y": 35,
                    "width": 20,
                    "height": 15,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 20,
                    "y": 35,
                    "width": 20,
                    "height": 15,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 40,
                    "y": 35,
                    "width": 20,
                    "height": 30,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 9,
                    "x": 0,
                    "y": 50,
                    "width": 14,
                    "height": 15,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 14,
                    "y": 50,
                    "width": 13,
                    "height": 15,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 11,
                    "x": 27,
                    "y": 50,
                    "width": 13,
                    "height": 15,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 0,
                    "y": 65,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 77,
                    "x": 0,
                    "y": 68,
                    "width": 60,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 19,
                    "x": 0,
                    "y": 68,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 12,
                    "x": 0,
                    "y": 76,
                    "width": 60,
                    "height": 30,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 78,
                    "x": 0,
                    "y": 106,
                    "width": 60,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 18,
                    "x": 0,
                    "y": 106,
                    "width": 60,
                    "height": 30,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 79,
                    "x": 0,
                    "y": 136,
                    "width": 60,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 15,
                    "x": 0,
                    "y": 136,
                    "width": 30,
                    "height": 38,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 16,
                    "x": 30,
                    "y": 136,
                    "width": 30,
                    "height": 38,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "compact": {
            "aspectRatio": 1,
            "width": 12,
            "frameMargin": null,
            "framePadding": null,
            "type": "COMPACT",
            "template": [
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 0,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 4,
                    "x": 0,
                    "y": 6,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 3,
                    "x": 0,
                    "y": 12,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 0,
                    "y": 18,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 0,
                    "y": 24,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 30,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 17,
                    "x": 0,
                    "y": 31,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 13,
                    "x": 0,
                    "y": 37,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 0,
                    "y": 43,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 0,
                    "y": 49,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 9,
                    "x": 0,
                    "y": 55,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 11,
                    "x": 0,
                    "y": 61,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 0,
                    "y": 67,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 0,
                    "y": 73,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 0,
                    "y": 79,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 77,
                    "x": 0,
                    "y": 80,
                    "width": 12,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false,
                    "isHidden": true
                },
                {
                    "contentKey": 19,
                    "x": 0,
                    "y": 80,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 12,
                    "x": 0,
                    "y": 86,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 78,
                    "x": 0,
                    "y": 92,
                    "width": 12,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false,
                    "isHidden": true
                },
                {
                    "contentKey": 18,
                    "x": 0,
                    "y": 92,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 79,
                    "x": 0,
                    "y": 98,
                    "width": 12,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false,
                    "isHidden": true
                },
                {
                    "contentKey": 15,
                    "x": 0,
                    "y": 98,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 16,
                    "x": 0,
                    "y": 104,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "hasPageBreaks": false
    }
'''

page3_layout_r = '''
    {
        "layoutId": <LAYOUT_ID>,
        "pageUrn": "<PAGE_3>",
        "printFriendly": true,
        "background": {
            "id": 22579,
            "cropHeight": null,
            "cropWidth": null,
            "x": null,
            "y": null,
            "dataFileId": null,
            "imageBrightness": null,
            "imageHeight": null,
            "imageWidth": null,
            "selectedColor": "#E8E8E8",
            "textColor": "#4A4A4A",
            "type": "COLOR",
            "darkMode": false,
            "alpha": 1,
            "src": null
        },
        "isDynamic": false,
        "content": [
            {
                "id": 56844,
                "contentKey": 0,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_0>,
                "cardUrn": "<NAV_PAGE_0>",
                "backgroundId": 23541,
                "background": {
                    "id": 23541,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_0>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_0>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 56845,
                "contentKey": 1,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_1>,
                "cardUrn": "<NAV_PAGE_1>",
                "backgroundId": 23542,
                "background": {
                    "id": 23542,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_1>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_1>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 56846,
                "contentKey": 2,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_2>,
                "cardUrn": "<NAV_PAGE_2>",
                "backgroundId": 23543,
                "background": {
                    "id": 23543,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_2>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_2>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 56847,
                "contentKey": 3,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_3>,
                "cardUrn": "<NAV_PAGE_3>",
                "backgroundId": 23544,
                "background": {
                    "id": 23544,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#4E8CBA",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_3>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_3>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 56848,
                "contentKey": 4,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_4>,
                "cardUrn": "<NAV_PAGE_4>",
                "backgroundId": 23545,
                "background": {
                    "id": 23545,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_4>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_4>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 56849,
                "contentKey": 6,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_1>,
                "cardUrn": "<HEADER_1>",
                "backgroundId": 23546,
                "background": {
                    "id": 23546,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 56850,
                "contentKey": 7,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TRAIN_MAE>,
                "cardUrn": "<TRAIN_MAE>",
                "type": "CARD"
            },
            {
                "id": 56851,
                "contentKey": 8,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TRAIN_RMSE>,
                "cardUrn": "<TRAIN_RMSE>",
                "type": "CARD"
            },
            {
                "id": 56852,
                "contentKey": 9,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TRAIN_MAPE>,
                "cardUrn": "<TRAIN_MAPE>",
                "type": "CARD"
            },
            {
                "id": 56853,
                "contentKey": 10,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <TRAIN_R2>,
                "cardUrn": "<TRAIN_R2>",
                "type": "CARD"
            }
        ],
        "standard": {
            "aspectRatio": 1.67,
            "width": 60,
            "frameMargin": null,
            "framePadding": null,
            "type": "STANDARD",
            "template": [
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 0,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 15,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 3,
                    "x": 30,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 4,
                    "x": 45,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 0,
                    "y": 16,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 0,
                    "y": 19,
                    "width": 60,
                    "height": 7,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 0,
                    "y": 26,
                    "width": 15,
                    "height": 14,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 9,
                    "x": 15,
                    "y": 26,
                    "width": 15,
                    "height": 14,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 30,
                    "y": 26,
                    "width": 15,
                    "height": 14,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 45,
                    "y": 26,
                    "width": 15,
                    "height": 14,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "compact": {
            "aspectRatio": 1,
            "width": 12,
            "frameMargin": null,
            "framePadding": null,
            "type": "COMPACT",
            "template": [
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 0,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 6,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 4,
                    "x": 0,
                    "y": 12,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 3,
                    "x": 0,
                    "y": 18,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 0,
                    "y": 24,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 0,
                    "y": 30,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 0,
                    "y": 31,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 0,
                    "y": 37,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 9,
                    "x": 0,
                    "y": 43,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 0,
                    "y": 49,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 0,
                    "y": 55,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "hasPageBreaks": false
    }
'''

page4_layout = '''
    {
        "layoutId": <LAYOUT_ID>,
        "pageUrn": "<PAGE_4>",
        "printFriendly": true,
        "background": {
            "id": 9025,
            "cropHeight": null,
            "cropWidth": null,
            "x": null,
            "y": null,
            "dataFileId": null,
            "imageBrightness": null,
            "imageHeight": null,
            "imageWidth": null,
            "selectedColor": "#E8E8E8",
            "textColor": "#4A4A4A",
            "type": "COLOR",
            "darkMode": false,
            "alpha": 1,
            "src": null
        },
        "isDynamic": false,
        "content": [
            {
                "id": 53590,
                "contentKey": 1,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_3>,
                "cardUrn": "<HEADER_3>",
                "backgroundId": 22424,
                "background": {
                    "id": 22424,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 53591,
                "contentKey": 2,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <SHAP_DEP>,
                "cardUrn": "<SHAP_DEP>",
                "type": "CARD"
            },
            {
                "id": 53592,
                "contentKey": 3,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <SHAP_DEP_FILTER>,
                "cardUrn": "<SHAP_DEP_FILTER>",
                "interaction": {
                    "type": "STANDARD",
                    "config": {
                        "openInNewWindow": false,
                        "allowCardToCardInteractions": true,
                        "selectedCardUrns": [
                            "<SHAP_DEP_FILTER>",
                            "<SHAP_DEP>"
                        ],
                        "selectIndividualCards": true
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53593,
                "contentKey": 4,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <CORR>,
                "cardUrn": "<CORR>",
                "type": "CARD"
            },
            {
                "id": 53594,
                "contentKey": 5,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_4>,
                "cardUrn": "<NAV_PAGE_4>",
                "backgroundId": 22425,
                "background": {
                    "id": 22425,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#4E8CBA",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_4>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_4>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53595,
                "contentKey": 6,
                "compactInteractionDefault": true,
                "hideTitle": false,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <VIF>,
                "cardUrn": "<VIF>",
                "type": "CARD"
            },
            {
                "id": 53596,
                "contentKey": 7,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": false,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <SHAP_SUMM>,
                "cardUrn": "<SHAP_SUMM>",
                "type": "CARD"
            },
            {
                "id": 53597,
                "contentKey": 8,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_1>,
                "cardUrn": "<HEADER_1>",
                "backgroundId": 22426,
                "background": {
                    "id": 22426,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 53598,
                "contentKey": 10,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <HEADER_2>,
                "cardUrn": "<HEADER_2>",
                "backgroundId": 22427,
                "background": {
                    "id": 22427,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#73B0D7",
                    "textColor": "#FFFFFF",
                    "type": "COLOR",
                    "darkMode": true,
                    "alpha": 1,
                    "src": null
                },
                "type": "CARD"
            },
            {
                "id": 53599,
                "contentKey": 11,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_0>,
                "cardUrn": "<NAV_PAGE_0>",
                "backgroundId": 22428,
                "background": {
                    "id": 22428,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_0>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_0>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53600,
                "contentKey": 13,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_1>,
                "cardUrn": "<NAV_PAGE_1>",
                "backgroundId": 22429,
                "background": {
                    "id": 22429,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_1>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_1>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53601,
                "contentKey": 14,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_2>,
                "cardUrn": "<NAV_PAGE_2>",
                "backgroundId": 22430,
                "background": {
                    "id": 22430,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_2>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_2>"
                    }
                },
                "type": "CARD"
            },
            {
                "id": 53602,
                "contentKey": 15,
                "compactInteractionDefault": true,
                "hideTitle": true,
                "hideDescription": true,
                "hideSummary": false,
                "summaryNumberOnly": false,
                "hideTimeframe": false,
                "hideFooter": true,
                "hideWrench": true,
                "hideMargins": false,
                "hasSummary": false,
                "fitToFrame": false,
                "hideBorder": false,
                "acceptFilters": true,
                "acceptDateFilter": true,
                "acceptSegments": true,
                "cardId": <NAV_PAGE_3>,
                "cardUrn": "<NAV_PAGE_3>",
                "backgroundId": 22431,
                "background": {
                    "id": 22431,
                    "cropHeight": null,
                    "cropWidth": null,
                    "x": null,
                    "y": null,
                    "dataFileId": null,
                    "imageBrightness": null,
                    "imageHeight": null,
                    "imageWidth": null,
                    "selectedColor": "#B7DAF5",
                    "textColor": "#4A4A4A",
                    "type": "COLOR",
                    "darkMode": false,
                    "alpha": 1,
                    "src": null
                },
                "interaction": {
                    "type": "DOMOLINK",
                    "config": {
                        "displayName": "",
                        "entityType": "page",
                        "entityId": "<PAGE_3>",
                        "openInNewWindow": false,
                        "persistFilters": false,
                        "url": "/page/<PAGE_3>"
                    }
                },
                "type": "CARD"
            }
        ],
        "standard": {
            "aspectRatio": 1.67,
            "width": 60,
            "frameMargin": null,
            "framePadding": null,
            "type": "STANDARD",
            "template": [
                {
                    "contentKey": 11,
                    "x": 0,
                    "y": 0,
                    "width": 60,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 13,
                    "x": 0,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 15,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 15,
                    "x": 30,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 45,
                    "y": 8,
                    "width": 15,
                    "height": 8,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 9,
                    "x": 0,
                    "y": 16,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 0,
                    "y": 19,
                    "width": 60,
                    "height": 7,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 0,
                    "y": 26,
                    "width": 60,
                    "height": 35,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 12,
                    "x": 0,
                    "y": 61,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 0,
                    "y": 64,
                    "width": 60,
                    "height": 7,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 94,
                    "x": 0,
                    "y": 71,
                    "width": 60,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 3,
                    "x": 0,
                    "y": 71,
                    "width": 60,
                    "height": 9,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 0,
                    "y": 80,
                    "width": 60,
                    "height": 41,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 121,
                    "width": 60,
                    "height": 3,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 124,
                    "width": 60,
                    "height": 7,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 95,
                    "x": 0,
                    "y": 131,
                    "width": 60,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 4,
                    "x": 0,
                    "y": 131,
                    "width": 30,
                    "height": 38,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 30,
                    "y": 131,
                    "width": 30,
                    "height": 38,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "compact": {
            "aspectRatio": 1,
            "width": 12,
            "frameMargin": null,
            "framePadding": null,
            "type": "COMPACT",
            "template": [
                {
                    "contentKey": 11,
                    "x": 0,
                    "y": 0,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 15,
                    "x": 0,
                    "y": 6,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 13,
                    "x": 0,
                    "y": 12,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 14,
                    "x": 0,
                    "y": 18,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 5,
                    "x": 0,
                    "y": 24,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 9,
                    "x": 0,
                    "y": 30,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 8,
                    "x": 0,
                    "y": 31,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 7,
                    "x": 0,
                    "y": 37,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 12,
                    "x": 0,
                    "y": 43,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 10,
                    "x": 0,
                    "y": 44,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 94,
                    "x": 0,
                    "y": 50,
                    "width": 12,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false,
                    "isHidden": true
                },
                {
                    "contentKey": 3,
                    "x": 0,
                    "y": 50,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 2,
                    "x": 0,
                    "y": 56,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 0,
                    "x": 0,
                    "y": 62,
                    "width": 12,
                    "height": 1,
                    "type": "SEPARATOR",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 1,
                    "x": 0,
                    "y": 63,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 95,
                    "x": 0,
                    "y": 69,
                    "width": 12,
                    "height": 0,
                    "type": "PAGE_BREAK",
                    "virtual": false,
                    "virtualAppendix": false,
                    "isHidden": true
                },
                {
                    "contentKey": 4,
                    "x": 0,
                    "y": 69,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                },
                {
                    "contentKey": 6,
                    "x": 0,
                    "y": 75,
                    "width": 12,
                    "height": 6,
                    "type": "CARD",
                    "virtual": false,
                    "virtualAppendix": false
                }
            ]
        },
        "hasPageBreaks": false
    }
'''

page1_filter = '''
    {
        "name": "<NAME>",
        "type": "NAMED",
        "filters": [
            {
                "column": "feature",
                "key": "feature:",
                "dataType": "string",
                "operand": "IN",
                "values": [
                    "<VALUE>"
                ],
                "dataSourceId": "<DSID>",
                "affectedCardUrns": [
                    "<FEATURE_DRIFT_LABEL>",
                    "<FEATURE_DRIFT>",
                    "<FEATURE_DRIFT_FILTER>"
                ]
            }
        ],
        "functionOverrides": {},
        "segmentIds": []
    }
'''

page2_filter = '''
    {
        "name": "<NAME>",
        "type": "NAMED",
        "filters": [
            {
                "column": "index",
                "operand": "IN",
                "values": [
                    "<VALUE_1>"
                ],
                "dataSourceId": "<DSID>",
                "dataType": "string",
                "affectedCardUrns": [
                    "<PARTIAL_OBS_FILTER_1>",
                    "<PARTIAL_OBS_FILTER_2>",
                    "<OBS_TABLE>",
                    "<SHAP_WATERFALL>",
                    "<PARTIAL>"
                ],
                "key": "index:"
            },
            {                
                "column": "feature2",
                "operand": "IN",
                "values": [
                    "<VALUE_2>"
                ],
                "dataSourceId": "<DSID>",
                "dataType": "string",
                "affectedCardUrns": [
                    "<PARTIAL_FEAT_FILTER>",
                    "<PARTIAL>"
                ],
                "key": "feature2:"
            }
        ],
        "functionOverrides": {},
        "segmentIds": []
    }
'''

page3_filter = '''
    {
        "name": "<NAME>",
        "type": "NAMED",
        "filters": [
            {
                "column": "value2",
                "operand": "IN",
                "values": [
                    <VALUE>
                ],
                "dataType": "numeric",
                "affectedCardUrns": [
                    "<TRAIN_ACCURACY>",
                    "<TRAIN_PRECISION>",
                    "<TRAIN_RECALL>",
                    "<TRAIN_SPECIFICITY>",
                    "<TRAIN_F1>",
                    "<TRAIN_CM>",
                    "<THRESHOLD_DROPDOWN>"
                ],
                "key": "value2:"
            }
        ],
        "functionOverrides": {},
        "segmentIds": []
    }
'''

page4_filter = '''
    {
        "name": "<NAME>",
        "type": "NAMED",
        "filters": [
            {
                "column": "feature",
                "key": "feature:",
                "dataType": "string",
                "operand": "IN",
                "values": [
                    "<VALUE>"
                ],
                "dataSourceId": "<DSID>",
                "affectedCardUrns": [
                    "<SHAP_DEP_FILTER>",
                    "<SHAP_DEP>"
                ]
            }
        ],
        "functionOverrides": {},
        "segmentIds": []
    }
'''
