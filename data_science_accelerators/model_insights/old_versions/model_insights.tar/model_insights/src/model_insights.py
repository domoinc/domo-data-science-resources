import json
import numpy as np
import pandas as pd
import pickle
import shap
from datetime import datetime
from enum import Enum
from sklearn.metrics import (
    accuracy_score, f1_score, recall_score, precision_score,
    r2_score, mean_absolute_error, mean_squared_error,
    confusion_matrix, roc_curve, roc_auc_score,
    precision_recall_curve, average_precision_score,
    mean_absolute_percentage_error, multilabel_confusion_matrix
)
from sklearn.utils.multiclass import unique_labels
from statsmodels.stats.outliers_influence import variance_inflation_factor as vif
from tqdm import tqdm
# from typing import Tuple, Union

from .domoapi import DomoAPI
from .extras import calculate_psi
from . import templates as t

import warnings
warnings.filterwarnings("ignore")

ModelType = Enum('ModelType', ['REGRESSION', 'BINARY_CLASSIFICATION', 'MULTI_CLASSIFICATION'])

class ModelInsights(DomoAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _build_summary(self, model_name, mdl_type: ModelType, mdl, model_train_date):
        self.pbar.set_description_str('calculating model summary...')
        
        rows = [
            ('Model Name', model_name),
            ('Model Type', mdl_type.name.replace('_', ' ').title()),
            ('Model Class', mdl.__class__.__qualname__),
            ('Model Train Date', model_train_date),
            ('Insights Last Update', datetime.now().strftime('%Y-%m-%d')),
        ]

        df = pd.DataFrame(rows, columns=['feature', 'feature2'])
        df.insert(0, 'table', 'summary')
        
        #self.pbar.update(1)
        return df

    def _build_perf(self, dsid, mdl, mdl_type: ModelType, X_train, yta, ytp, ysa, ysp):        
        self.pbar.set_description_str('calculating model performance...')

        def score(func, y_true, y_pred):
            if len(y_true) and len(y_pred):
                if func == mean_squared_error:
                    return np.sqrt(func(y_true, y_pred))
                else:
                    return func(y_true, y_pred)            
            return None
        
        def get_acc(tn, fp, fn, tp): return (tp + tn) / (tn + fp + fn + tp)
        def get_rec(tp, fn): return (tp) / (tp + fn)
        def get_prec(tp, fp): return (tp) / (tp + fp)
        def get_spec(tn, fp): return (tn) / (fp + tn)
        def get_f1(tp, fp, fn): return (2 * tp) / ((2 * tp) + fp + fn)

        if mdl_type == ModelType.REGRESSION:

            now = datetime.now().strftime('%Y-%m-%d %T')
            rows = [
                ('live_perf_history', 'R2',   now, None, score(r2_score, ysa, ysp), None),
                ('live_perf_history', 'RMSE', now, None, score(mean_squared_error, ysa, ysp), None),
                ('live_perf_history', 'MAE',  now, None, score(mean_absolute_error, ysa, ysp), None),
                ('live_perf_history', 'MAPE', now, None, score(mean_absolute_percentage_error, ysa, ysp), None),
                ('live_perf', 'R2',   None, None, score(r2_score, ysa, ysp), None),
                ('live_perf', 'RMSE', None, None, score(mean_squared_error, ysa, ysp), None),
                ('live_perf', 'MAE',  None, None, score(mean_absolute_error, ysa, ysp), None),
                ('live_perf', 'MAPE', None, None, score(mean_absolute_percentage_error, ysa, ysp), None),
                ('train_perf', 'R2',   None, None, score(r2_score, yta, ytp), None),
                ('train_perf', 'RMSE', None, None, score(mean_squared_error, yta, ytp), None),
                ('train_perf', 'MAE',  None, None, score(mean_absolute_error, yta, ytp), None),
                ('train_perf', 'MAPE', None, None, score(mean_absolute_percentage_error, yta, ytp), None),
            ]
            
            df = pd.DataFrame(rows, columns=['table', 'feature', 'feature2', 'feature3', 'value', 'value2'])
        
        elif mdl_type == ModelType.BINARY_CLASSIFICATION:
            
            tn, fp, fn, tp = confusion_matrix(ysa, ysp).ravel()
            now = datetime.now().strftime('%Y-%m-%d %T')
            rows = [
                ('live_perf_history', 'Accuracy',    now, None, get_acc(tn, fp, fn, tp), None),
                ('live_perf_history', 'Recall',      now, None, get_rec(tp, fn), None),
                ('live_perf_history', 'Precision',   now, None, get_prec(tp, fp), None),
                ('live_perf_history', 'Specificity', now, None, get_spec(tn, fp), None),
                ('live_perf_history', 'F1',          now, None, get_f1(tp, fp, fn), None),
                ('live_perf', 'Accuracy',    None, None, get_acc(tn, fp, fn, tp), None),
                ('live_perf', 'Recall',      None, None, get_rec(tp, fn), None),
                ('live_perf', 'Precision',   None, None, get_prec(tp, fp), None),
                ('live_perf', 'Specificity', None, None, get_spec(tn, fp), None),
                ('live_perf', 'F1',          None, None, get_f1(tp, fp, fn), None),
            ]

            #
            # train performance
            #
            if hasattr(mdl, 'predict_proba'):
                ytp = [y[1] for y in mdl.predict_proba(X_train.drop(columns=['__INDEX__']))]
                thresholds = list(np.arange(0.01, 1, 0.01))
                for th in thresholds:
                    th = round(th, 2)
                    ytp2 = [int(y > th) for y in ytp]
                    tn, fp, fn, tp = confusion_matrix(yta, ytp2).ravel()
                    rows.extend([
                        ('train_perf', 'Accuracy',    None, None, get_acc(tn, fp, fn, tp), th),
                        ('train_perf', 'Recall',      None, None, get_rec(tp, fn), th),
                        ('train_perf', 'Precision',   None, None, get_prec(tp, fp), th),
                        ('train_perf', 'Specificity', None, None, get_spec(tn, fp), th),
                        ('train_perf', 'F1',          None, None, get_f1(tp, fp, fn), th),
                    ])
            else:
                pass  # TODO
                # tn1, fp1, fn1, tp1 = confusion_matrix(yta, ytp).ravel()
                # tn2, fp2, fn2, tp2 = confusion_matrix(ysa, ysp).ravel()
                # rows.extend([
                #     ('Accuracy', get_acc(tn1, fp1, fn1, tp1), get_acc(tn2, fp2, fn2, tp2), th),
                #     ('Recall', get_rec(tp1, fn1), get_rec(tp2, fn2), th),
                #     ('Precision', get_prec(tp1, fp1), get_prec(tp2, fp2), th),
                #     ('Specificity', get_spec(tn1, fp1), get_spec(tn2, fp2), th),
                #     ('F1', get_f1(tp1, fp1, fn1), get_f1(tp2, fp2, fn2), th),
                # ])

            df = pd.DataFrame(rows, columns=['table', 'feature', 'feature2', 'feature3', 'value', 'value2'])
            
        elif mdl_type == ModelType.MULTI_CLASSIFICATION:
            
            #
            # live / historic performance, for multiclass we gotta do that 
            # "overall" (this block) and for each possible target values (next block)
            #
            cms = multilabel_confusion_matrix(ysa, ysp)
            tn, fp, fn, tp = cms.sum(axis=0).ravel()
            now = datetime.now().strftime('%Y-%m-%d %T')
            rows = [
                ('live_perf_history', 'Accuracy',    now, 'OVERALL', get_acc(tn, fp, fn, tp), None),
                ('live_perf_history', 'Recall',      now, 'OVERALL', get_rec(tp, fn), None),
                ('live_perf_history', 'Precision',   now, 'OVERALL', get_prec(tp, fp), None),
                ('live_perf_history', 'Specificity', now, 'OVERALL', get_spec(tn, fp), None),
                ('live_perf_history', 'F1',          now, 'OVERALL', get_f1(tp, fp, fn), None),
                ('live_perf', 'Accuracy',    None, 'OVERALL', get_acc(tn, fp, fn, tp), None),
                ('live_perf', 'Recall',      None, 'OVERALL', get_rec(tp, fn), None),
                ('live_perf', 'Precision',   None, 'OVERALL', get_prec(tp, fp), None),
                ('live_perf', 'Specificity', None, 'OVERALL', get_spec(tn, fp), None),
                ('live_perf', 'F1',          None, 'OVERALL', get_f1(tp, fp, fn), None),
            ]

            for cm, y in zip(cms, unique_labels(ysa, ysp)):
                tn, fp, fn, tp = cm.ravel()
                rows.extend([
                    ('live_perf_history', 'Accuracy',    now, y, get_acc(tn, fp, fn, tp), None),
                    ('live_perf_history', 'Recall',      now, y, get_rec(tp, fn), None),
                    ('live_perf_history', 'Precision',   now, y, get_prec(tp, fp), None),
                    ('live_perf_history', 'Specificity', now, y, get_spec(tn, fp), None),
                    ('live_perf_history', 'F1',          now, y, get_f1(tp, fp, fn), None),
                    ('live_perf', 'Accuracy',    None, y, get_acc(tn, fp, fn, tp), None),
                    ('live_perf', 'Recall',      None, y, get_rec(tp, fn), None),
                    ('live_perf', 'Precision',   None, y, get_prec(tp, fp), None),
                    ('live_perf', 'Specificity', None, y, get_spec(tn, fp), None),
                    ('live_perf', 'F1',          None, y, get_f1(tp, fp, fn), None),
                ])
            
            #
            # do the same for training peformance
            #
            cms = multilabel_confusion_matrix(yta, ytp)
            tn, fp, fn, tp = cms.sum(axis=0).ravel()
            rows.extend([
                ('train_perf', 'Accuracy',    None, 'OVERALL', get_acc(tn, fp, fn, tp), None),
                ('train_perf', 'Recall',      None, 'OVERALL', get_rec(tp, fn), None),
                ('train_perf', 'Precision',   None, 'OVERALL', get_prec(tp, fp), None),
                ('train_perf', 'Specificity', None, 'OVERALL', get_spec(tn, fp), None),
                ('train_perf', 'F1',          None, 'OVERALL', get_f1(tp, fp, fn), None),
            ])

            for cm, y in zip(cms, unique_labels(yta, ytp)):
                tn, fp, fn, tp = cm.ravel()
                rows.extend([                    
                    ('train_perf', 'Accuracy',    None, y, get_acc(tn, fp, fn, tp), None),
                    ('train_perf', 'Recall',      None, y, get_rec(tp, fn), None),
                    ('train_perf', 'Precision',   None, y, get_prec(tp, fp), None),
                    ('train_perf', 'Specificity', None, y, get_spec(tn, fp), None),
                    ('train_perf', 'F1',          None, y, get_f1(tp, fp, fn), None),
                ])

            df = pd.DataFrame(rows, columns=['table', 'feature', 'feature2', 'feature3', 'value', 'value2'])

        #
        # append the perf_history to the new dataset
        #
        if dsid:
            df2 = self.read_dataset(
                dsid,
                query='SELECT table, feature, feature2, feature3, value, value2 FROM table WHERE table=\'live_perf_history\''
            )
            df = pd.concat([df, df2])

        #self.pbar.update(1)
        return df

    def _build_shap(self, mdl, mdl_type, X, table_name):
        self.pbar.set_description_str('calculating model performance...')
        
        try:
            shap_exp = shap.Explainer(mdl)
            X2 = X.drop(columns=['__INDEX__'])
            shap_val = shap_exp(X2)
            X = X.reset_index()

            shap_df = pd.DataFrame()
            for i, f in enumerate(shap_val.feature_names):
                for c in range(len(mdl.classes_)):
                    _df = pd.DataFrame({
                        'feature': [f] * len(shap_val.data),
                        'feature2': mdl.classes_[c],
                        'value': shap_val.data[:, i],
                        'shap_value': shap_val.values[:, i, c],
                    })
                    _df['index'] = _df.index
                    shap_df = pd.concat([shap_df, _df])

            base_df = pd.DataFrame()
            for c in range(len(mdl.classes_)):
                _df = pd.DataFrame({
                    'feature': ['_BASELINE'] * len(shap_val.data),
                    'feature2': mdl.classes_[c],
                    'value': 0,
                    'shap_value': shap_val.base_values[:, c]
                })
                _df['index'] = _df.index
                base_df = pd.concat([base_df, _df])

            shap_df = pd.concat([shap_df, base_df])
            shap_df = pd.merge(shap_df, X, left_on='index', right_on=['index'])
            shap_df = shap_df.drop(columns=['index'])
            shap_df = shap_df.rename(columns={'shap_value': 'value2', '__INDEX__': 'index'})
            shap_df.insert(0, 'table', table_name)
            
            if mdl_type == ModelType.MULTI_CLASSIFICATION:
                overall = shap_df.groupby(['index', 'feature']).agg({'value': np.mean, 'value2': lambda x: np.std(x)}).reset_index()
                overall['feature2'] = 'OVERALL'
                overall['table'] = table_name
                shap_df = pd.concat([shap_df, overall])

            #self.pbar.update(1)
            return shap_df
        
        except:
            return pd.DataFrame(columns=[
                'table', 'feature', 'feature2', 'feature3',
                'value', 'value2', 'value3', 'index'
            ])

    def _build_partial(self, mdl, X_pred: pd.DataFrame, n_point: int = 10):
        if X_pred.empty:
            return pd.DataFrame()

        X = X_pred.drop(columns=['__INDEX__'])

        self.pbar.set_description_str('calculating partial dependence...')
        
        rows = []
        for col in X.columns:
            col = str(col)  # type hint
            gap = (X[col].max() - X[col].min()) / (n_point - 2)
            points = np.arange(X[col].min(), X[col].max() + gap, gap)
            if hasattr(mdl, 'predict_proba'):
                for idx, row in X.iterrows():
                    val = row[col]
                    if row[col] not in points:
                        rows.append(
                            [idx, col, row[col], mdl.predict_proba([row])[0][1], row[col]]
                        )
                    for p in points:
                        row[col] = p
                        rows.append(
                            [idx, col, row[col], mdl.predict_proba([row])[0][1], row[col] if p == val else 0]
                        )
            else:
                for idx, row in X.iterrows():
                    val = row[col]
                    if row[col] not in points:
                        rows.append(
                            [idx, col, row[col], mdl.predict([row])[
                                0], row[col]]
                        )
                    for p in points:
                        row[col] = p
                        rows.append(
                            [idx, col, row[col], mdl.predict(
                                [row])[0], row[col] if p == val else 0]
                        )

        df = pd.DataFrame(
            rows, columns=['internal_index', 'feature2', 'value', 'value2', 'value3'])
        df = pd.merge(df, X_pred, left_on='internal_index', right_index=True)
        df = df[['__INDEX__', 'feature2', 'value', 'value2', 'value3']]
        df = df.rename(columns={'__INDEX__': 'index'})
        df.insert(0, 'table', 'partial')
        
        #self.pbar.update(1)
        return df

    def _build_corr(self, X):
        self.pbar.set_description_str('calculating correlation, VIF...')
        
        to_dummy = []
        X = X.drop(columns=['__INDEX__'])
        for col in X.select_dtypes('O'):
            if X[col].unique().shape[0] <= 10:
                to_dummy.append(col)
        X = pd.get_dummies(X, columns=to_dummy)

        cor = X.corr(method='pearson')
        cor['feature'] = cor.index
        cor = cor.melt(id_vars='feature', var_name='feature2', value_name='value')

        vif_rows = [[col, vif(X, i)] for i, col in enumerate(X.columns)]
        cor = pd.merge(cor, pd.DataFrame(vif_rows, columns=['feature', 'value2']))
        cor.insert(0, 'table', 'correlation')
        
        #self.pbar.update(1)
        return cor

    def _build_binary_conf(self, mdl, X, y, ysa, ysp):
        self.pbar.set_description_str('calculating confusion matrix...')

        X = X.drop(columns=['__INDEX__'])
        y_pred = [y[1] for y in mdl.predict_proba(X)]
        rows = []

        thresholds = list(np.arange(0.01, 1, 0.01))
        for th in thresholds:
            th = round(th, 2)
            y2 = [int(y_perc > th) for y_perc in y_pred]
            cm = confusion_matrix(y, y2)
            labels = unique_labels(y, y2)
            rows.extend([(labels[iy], labels[ix], cm[iy, ix], th) for iy, ix in np.ndindex(cm.shape)])
        df = pd.DataFrame(rows, columns=['feature', 'feature2', 'value', 'value2'])
        df['value3'] = df['value'] / len(y_pred)
        df.insert(0, 'table', 'train_confusion')

        if len(ysa) and len(ysp):
            cm = confusion_matrix(ysa, ysp)
            labels = unique_labels(ysa, ysp)
            rows = [(labels[iy], labels[ix], cm[iy, ix]) for iy, ix in np.ndindex(cm.shape)]
            df2 = pd.DataFrame(rows, columns=['feature', 'feature2', 'value'])
            df2.insert(0, 'table', 'live_confusion')
            df2['value3'] = df2['value'] / len(ysp)
            df = pd.concat([df, df2])

        #self.pbar.update(1)
        return df

    def _build_multi_conf(self, yta, ytp, ysa, ysp):
        self.pbar.set_description_str('calculating confusion matrix...')

        labels = unique_labels(yta, ytp)
        cm = confusion_matrix(yta, ytp)
        cms = multilabel_confusion_matrix(yta, ytp)        
        rows = [(labels[iy], labels[ix], cm[iy, ix], 'OVERALL') for iy, ix in np.ndindex(cm.shape)]
        for cm, y in zip(cms, labels):
            labs = ['NOT ' + y, y]
            rows.extend([(labs[iy], labs[ix], cm[iy, ix], y) for iy, ix in np.ndindex(cm.shape)])
        df1 = pd.DataFrame(rows, columns=['feature', 'feature2', 'value', 'feature3'])
        df1.insert(0, 'table', 'train_confusion')

        labels = unique_labels(ysa, ysp)
        cm = confusion_matrix(ysa, ysp)
        cms = multilabel_confusion_matrix(ysa, ysp)        
        rows = [(labels[iy], labels[ix], cm[iy, ix], 'OVERALL') for iy, ix in np.ndindex(cm.shape)]
        for cm, y in zip(cms, labels):
            labs = ['NOT ' + y, y]
            rows.extend([(labs[iy], labs[ix], cm[iy, ix], y) for iy, ix in np.ndindex(cm.shape)])
        df2 = pd.DataFrame(rows, columns=['feature', 'feature2', 'value', 'feature3'])
        df2.insert(0, 'table', 'live_confusion')

        df = pd.concat([df1, df2])
        
        #self.pbar.update(1)
        return df

    def _build_drift(self, X_train: pd.DataFrame, X_pred: pd.DataFrame) -> pd.DataFrame:
        self.pbar.set_description_str('calculating data drift...')
        
        X_train = X_train.drop(columns=['__INDEX__'])
        X_pred = X_pred.drop(columns=['__INDEX__'])
        df = calculate_psi(X_train, X_pred)
        df.columns = ['feature', 'feature2', 'value', 'value2', 'value3']
        df['value'] = df['value'].round(4)
        df.insert(0, 'table', 'drift')

        #self.pbar.update(1)
        return df
            
    def _build_roc(self, y, y2):
        fpr, tpr = [], []
        thresh = list(np.arange(0, 1.01, .01))
        for t in thresh:
            y3 = [int(y >= t) for y in y2]
            tn, fp, fn, tp = confusion_matrix(y, y3).ravel()
            fpr.append(1 - round((tn / (tn + fp)), 4))
            tpr.append(round((tp / (tp + fn)), 4))

        roc = pd.DataFrame({'tpr': tpr, 'fpr': fpr, 'thresh': thresh})
        roc['optimal'] = False
        roc.loc[roc[(roc['fpr'] == 0.0) & (roc['tpr'] == 0.0)].index, 'optimal'] = True
        roc.loc[roc[(roc['fpr'] == 1.0) & (roc['tpr'] == 1.0)].index, 'optimal'] = True

        roc2 = roc.groupby('fpr').agg({'tpr': max}).reset_index()
        roc2 = roc2.groupby('tpr').agg({'fpr': min}).reset_index()
        roc2['optimal'] = True

        roc = pd.merge(roc, roc2, how='left', left_on=['tpr', 'fpr'], right_on=['tpr', 'fpr'])
        roc['optimal'] = roc['optimal_x'] | roc['optimal_y']
        roc['optimal'] = roc['optimal'].astype(int)

        roc = roc.groupby(['tpr', 'fpr']).agg({'thresh': [min, max], 'optimal': [max]})
        roc.columns = roc.columns.map('_'.join)
        roc = roc.reset_index()

        def thresh_range(row):
            if row['thresh_min'] == row['thresh_max']:
                return f"{row['thresh_min']:.3f}"
            else:
                return f"{row['thresh_min']:.3f} - {row['thresh_max']:.3f}"

        roc['thresh'] = roc.apply(thresh_range, axis=1)

        auc = roc_auc_score(y, y2)
        df = pd.DataFrame({
            'table': 'roc',
            'feature': 'roc',
            'feature2': roc['thresh'],  # putting this in feature2 for str type
            'value': roc['fpr'],
            'value2': roc['tpr'],
            'value3': roc['optimal_max'],
            'index': auc,
        })

        p, r = [], []
        thresh = list(np.arange(0, 1.01, .01))
        for t in thresh:
            y3 = [int(y >= t) for y in y2]
            p.append(precision_score(y, y3, zero_division=1))
            r.append(recall_score(y, y3, zero_division=1))

        pr = pd.DataFrame({'p': p, 'r': r, 'thresh': thresh})
        pr['optimal'] = False
        pr.loc[pr[(pr['p'] == 0.0) & (pr['r'] == 1.0)].index, 'optimal'] = True
        pr.loc[pr[(pr['p'] == 1.0) & (pr['r'] == 0.0)].index, 'optimal'] = True

        pr2 = pr.groupby('p').agg({'r': max}).reset_index()
        pr2 = pr2.groupby('r').agg({'p': max}).reset_index()
        pr2['optimal'] = True

        pr = pd.merge(pr, pr2, how='left', left_on=['p', 'r'], right_on=['p', 'r'])
        pr['optimal'] = pr['optimal_x'] | pr['optimal_y']
        pr['optimal'] = pr['optimal'].astype(int)

        pr = pr.groupby(['p', 'r']).agg({'thresh': [min, max], 'optimal': [max]})
        pr.columns = pr.columns.map('_'.join)
        pr = pr.reset_index()

        pr['thresh'] = pr.apply(thresh_range, axis=1)

        ap = average_precision_score(y, y2)
        df2 = pd.DataFrame({
            'table': 'roc',
            'feature': 'pr',
            'feature2': pr['thresh'],
            'value': pr['p'],
            'value2': pr['r'],
            'value3': pr['optimal_max'],
            'index': ap,
        })

        df2 = df2.sort_values(by=['feature2'])

        df = pd.concat([df, df2])

        #self.pbar.update(1)
        return df

    def _build_dataflow_status(self, dsids):
        set_ids = set()
        flow_ids = set()
        for dsid in dsids:
            r = self._get(f'{self.api_base}/data/v1/lineage/DATA_SOURCE/{dsid}?traverseDown=false')
            
            sets = {k:v for k,v in r.json().items() if k.startswith('DATA_SOURCE')}
            set_ids = set_ids.union([v['id'] for v in sets.values()])

            flows = {k:v for k,v in r.json().items() if k.startswith('DATAFLOW')}
            flow_ids = flow_ids.union([v['id'] for v in flows.values()])
        
        rows = []
        for dsid in set_ids:
            j = self._get(f'{self.api_base}/data/v3/datasources/{dsid}').json()
            rows.append([
                'dataflow_status', 'Dataset', f'https://{self.instance}.domo.com/datasources/{dsid}/details/overviewdsid', j['name'], j['lastUpdated'], j['status']
            ])

        for dfid in flow_ids:
            j = self._get(f'{self.api_base}/dataprocessing/v2/dataflows/{dfid}').json()
            rows.append([
                'dataflow_status', 'Dataflow', f'https://{self.instance}.domo.com/datacenter/dataflows/{dfid}/details#datasets', j['name'], j['lastExecution']['lastUpdated'], j['lastExecution']['state']
            ])

        df = pd.DataFrame(rows, columns=['table', 'feature', 'feature2', 'feature3', 'value', 'index'])
        return df

    def _create_or_replace_card(self, cards, name, dsid, page_id):
        #self.pbar.update(1)
        if name in cards:
            return cards[name]
        else:
            data = json.loads(getattr(t, name).replace('<DSID>', dsid))
            return self._build_card(data, page_id)

    def _create_or_replace_ddx(self, cards, name, dsid, page_id):
        #self.pbar.update(1)
        if name in cards:
            return cards[name]
        else:
            return self.create_ddx_brick(dsid, page_id, *getattr(t, name))

    def _create_or_replace_nb_card(self, cards, name, page_id):
        #self.pbar.update(1)
        if name in cards:
            return cards[name]
        else:
            temp_name = name[:-2]
            card_id = self._build_notebook_card(page_id, getattr(t, temp_name)[
                                                0], getattr(t, temp_name)[1])
            return card_id

    def _create_nb_from_template(self, cards, name, template, text, page_id):
        #self.pbar.update(1)
        if name in cards:
            return cards[name]
        else:
            html = getattr(t, template)[0].replace('<TEXT>', text)
            mark = getattr(t, template)[1].replace('<TEXT>', text)
            card_id = self._build_notebook_card(page_id, html, mark)
            return card_id

    def _try_create_page(self, pages, name, page_name, parent_page_id):
        self.pbar.set_description_str(f'creating page "{page_name}"...')
        #self.pbar.update(1)
        if name in pages:
            return pages[name]
        else:
            return self.create_page(page_name, parent_page_id=parent_page_id)

    def run_insights(
        self,
        model_name: str,
        model_type: str,  # ('regression'), ('classification' / 'binary_classification'), or ('multi_classification')
        mdl,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_index: str,
        X_pred: pd.DataFrame = pd.DataFrame(),
        page_id: int = 0,
        insights_dsid: str = '',
        pages: dict = {},
        cards: dict = {},
        actuals=pd.Series(),
        predictions=pd.Series(),
        model_train_date=None,
        monitor_dsids = [],
        save_config: bool = True,
        theme: dict = {
            'focus': '#4E8CBA',
            'header': '#73B0D7',
            'idle': '#B7DAF5',
            'heatmap': 'gradient-2',
            'background': '#E8E8E8'
        }
    ) -> None:

        self.pbar = tqdm(bar_format="[{elapsed}] {desc}")

        # region  parameter validation
        self.pbar.set_description_str('validating parameters...')
        
        if page_id == 0:
            raise ValueError('missing a valid `page_id`')
        else:
            page_id = int(page_id)

        if model_type[0].lower() in ('r'):
            mdl_type = ModelType.REGRESSION
        elif model_type[0].lower() in ('b', 'c'):
            mdl_type = ModelType.BINARY_CLASSIFICATION
        # elif model_type[0].lower() in ('m'):
        #     mdl_type = ModelType.MULTI_CLASSIFICATION
        else:
            raise ValueError("invalid `model_type`")

        if model_train_date:
            try:
                model_train_date = pd.to_datetime(model_train_date).date()
            except:
                model_train_date = 'Unknown'
        else:
            model_train_date = 'Unknown'

        if list(theme.keys()) != ['focus', 'header', 'idle', 'heatmap', 'background']:
            raise ValueError('invalid `theme`')
        
        #self.pbar.update(1)
        # endregion

        # region  setup data
        #
        # the variable names can get a bit out of hand, so
        # the following names are used internally:
        #   yta:  Y Train Actuals
        #   ytp:  Y Train Predictions (can be probabilities for classification)
        #   ytp2: Y Train Predictions (classified probabilities, if applicable)
        #   ysa:  Y Scoring Actuals
        #   ysp:  Y Scoring Predictions
        #

        # configure training sets
        X_train = X_train.rename(columns={X_index: '__INDEX__'})
        X_train = X_train.reset_index(drop=True)
        
        yta = y_train.copy()
        if mdl_type == ModelType.BINARY_CLASSIFICATION and hasattr(mdl, 'predict_proba'):
            ytp: pd.Series = pd.Series([y[1] for y in mdl.predict_proba(X_train.drop(columns=['__INDEX__']))], name=yta.name)
            ytp2 = (ytp >= 0.5).astype(int)
        else:
            ytp = pd.Series(mdl.predict(X_train.drop(columns=['__INDEX__'])), name=yta.name)
            ytp2 = ytp

        # configure scoring sets
        if not X_pred.empty:
            X_pred = X_pred.rename(columns={X_index: '__INDEX__'})
            X_pred = X_pred.reset_index(drop=True)
        
        ysa = list(actuals)
        ysp = list(predictions)
        # endregion

        # region  build datasets
        summ_df = self._build_summary(model_name, mdl_type, mdl, model_train_date)
        perf_df = self._build_perf(insights_dsid, mdl, mdl_type, X_train, yta, ytp, ysa, ysp)
        shp1_df = self._build_shap(mdl, mdl_type, X_train, 'shap_train')
        shp2_df = self._build_shap(mdl, mdl_type, X_pred, 'shap_pred')
        part_df = self._build_partial(mdl, X_pred)

        # can we assume this always works?
        train = pd.merge(X_train, y_train, right_index=True, left_index=True)
        corr_df = self._build_corr(train)
        
        rocc_df = self._build_roc(yta, ytp) if mdl_type == ModelType.BINARY_CLASSIFICATION else pd.DataFrame()

        drft_df = self._build_drift(X_train, X_pred)
        shp1_df.to_csv('out1.csv', index=False)
        drft_df.to_csv('out2.csv', index=False)
        
        # TODO consolidate all drift so a single function to clean this area up
        if mdl_type == ModelType.MULTI_CLASSIFICATION:
            feat_imp1 = shp1_df[shp1_df['feature'] != '_BASELINE'].groupby(['feature']).agg({'value2': lambda x: np.std(x)}).reset_index()
            feat_imp2 = shp1_df[(shp1_df['feature'] != '_BASELINE') & (shp1_df['feature2'] != 'OVERALL')].groupby(['feature', 'feature2']).agg({'value2': lambda x: np.mean(abs(x))}).reset_index()
            feat_imp = pd.concat([feat_imp1, feat_imp2]).fillna('OVERALL')
            feat_imp = feat_imp.rename(columns={'value2': 'feature_importance', 'feature2': 'feature3'})
            drft_feat_df = pd.merge(drft_df, feat_imp, how='left', left_on='feature', right_on='feature')
            drft_feat_df = drft_feat_df[['feature', 'feature3', 'value3', 'feature_importance']].drop_duplicates()
            drft_feat_df = drft_feat_df.rename(columns={'feature_importance': 'value'})
            drft_feat_df.insert(0, 'table', 'drift_fi')
        else:
            feat_imp = shp1_df[shp1_df['feature'] != '_BASELINE'].groupby('feature').agg({'value2': lambda x: np.mean(abs(x))})
            feat_imp = feat_imp.rename(columns={'value2': 'feature_importance'})
            drft_feat_df = pd.merge(drft_df, feat_imp, how='left', left_on='feature', right_index=True)
            drft_feat_df = drft_feat_df[['feature', 'value3', 'feature_importance']].drop_duplicates()
            drft_feat_df = drft_feat_df.rename(columns={'feature_importance': 'value'})
            drft_feat_df.insert(0, 'table', 'drift_fi')

        def psi_label(psi) -> str:
            if psi < .1:
                return 'NO SIGNIFICANT POPULATION CHANGE'
            elif psi < .2:
                return 'MODERATE POPULATION CHANGE'
            else:
                return 'SIGNIFICANT POPULATION CHANGE'

        def feature_psi_label(row) -> str:
            label = f"{row['feature'].upper()} has a Stability Index of {row['value3']:.2f}, which indicates {psi_label(row['value3'])}"
            return label

        drft_df['index'] = drft_df.apply(feature_psi_label, axis=1)

        avg_psi = drft_df['value3'].mean()
        drft_df.loc[len(drft_df.index)] = [  # type: ignore
            'drift', None, None, None, None, -1,
            f'The AVERAGE feature Stability Index is {avg_psi:.2f}, which indicates {psi_label(avg_psi)}'
        ]

        p_tmp = predictions.copy()
        p_tmp.name = ytp.name

        target_drift = calculate_psi(ytp2, p_tmp)
        target_drift.columns = ['feature', 'feature2', 'value', 'value2', 'value3']
        target_drift.insert(0, 'table', 'drift_y')
        psi = target_drift['value3'].iloc[0]
        target_drift['index'] = f'The TARGET has a Stability Index of {psi:.2f}, which indicates {psi_label(psi)}'

        # will we have the same length X and y? hmm not sure?
        # so what's the point of splitting then joining again?
        # could just say, pass the df_pred and the column names?

        columns = [
            'table', 'feature', 'feature2', 'feature3',
            'value', 'value2', 'value3', 'index'
        ]

        if mdl_type == ModelType.BINARY_CLASSIFICATION:
            conf_df = self._build_binary_conf(mdl, X_train, y_train, ysa, ysp)
        elif mdl_type == ModelType.MULTI_CLASSIFICATION:
            conf_df = self._build_multi_conf(yta, ytp, ysa, ysp)
        else:
            conf_df = pd.DataFrame(columns=columns)

        flow_df = self._build_dataflow_status(monitor_dsids) if monitor_dsids else pd.DataFrame(columns=columns)

        insights_df = pd.concat([
            summ_df,
            perf_df,
            shp1_df,
            shp2_df,
            part_df,
            corr_df,
            conf_df,
            drft_df,
            rocc_df,
            flow_df,
            target_drift,
            drft_feat_df
        ])
        # endregion

        # region  upload dataset
        insights_df = insights_df[columns]        
        insights_df['value2'] = insights_df['value2'].astype(float)
        insights_dsid = self._create_or_update(insights_df, f'{model_name} INSIGHTS', insights_dsid)
        # endregion

        # region  create subpages
        pages['page1'] = self._try_create_page(pages, 'page1', 'Monitoring', page_id)
        pages['page2'] = self._try_create_page(pages, 'page2', 'Prediction Explainer', page_id)
        pages['page3'] = self._try_create_page(pages, 'page3', 'Training Performance', page_id)
        pages['page4'] = self._try_create_page(pages, 'page4', 'Feature Importance', page_id)
        page1, page2, page3, page4 = pages.values()
        # endregion

        # region  Page 0 -- Overview
        self.pbar.set_description_str('adding cards to Overview...')
        layout0 = self._get_dashboard_layout(page_id)
        cards['nav_page0_0'] = self._create_nb_from_template(cards, 'nav_page0_0', 'nav_btn_big', 'Overview', page_id)
        cards['nav_page1_0'] = self._create_nb_from_template(cards, 'nav_page1_0', 'nav_btn', 'Monitoring', page_id)
        cards['nav_page2_0'] = self._create_nb_from_template(cards, 'nav_page2_0', 'nav_btn', 'Prediction Explainer', page_id)
        cards['nav_page3_0'] = self._create_nb_from_template(cards, 'nav_page3_0', 'nav_btn', 'Training Performance', page_id)
        cards['nav_page4_0'] = self._create_nb_from_template(cards, 'nav_page4_0', 'nav_btn', 'Feature Importance', page_id)
        cards['summary_table'] = self._create_or_replace_card(cards, 'summary_table', insights_dsid, page_id)
        cards['data_status'] = self._create_or_replace_card(cards, 'data_status', insights_dsid, page_id)
        
        self.pbar.set_description_str('arranging cards on page...')
        data = json.loads(
            t.page0_layout
            .replace('<LAYOUT_ID>', str(layout0))
            .replace('<PAGE_0>', str(page_id))
            .replace('<PAGE_1>', str(page1))
            .replace('<PAGE_2>', str(page2))
            .replace('<PAGE_3>', str(page3))
            .replace('<PAGE_4>', str(page4))
            .replace('<NAV_PAGE_0>', str(cards['nav_page0_0']))
            .replace('<NAV_PAGE_1>', str(cards['nav_page1_0']))
            .replace('<NAV_PAGE_2>', str(cards['nav_page2_0']))
            .replace('<NAV_PAGE_3>', str(cards['nav_page3_0']))
            .replace('<NAV_PAGE_4>', str(cards['nav_page4_0']))
            .replace('<SUMMARY_TABLE>', str(cards['summary_table']))
            .replace('<DATA_STATUS>', str(cards['data_status']))
        )
        self._add_dashboard_layout(layout0, data)
        #self.pbar.update(1)
        # endregion

        # region  Page 1 -- Monitoring
        self.pbar.set_description_str('adding cards to Monitoring...')
        cards['nav_page0_1'] = self._create_nb_from_template(cards, 'nav_page0_1', 'nav_btn_big', 'Overview', page1)
        cards['nav_page1_1'] = self._create_nb_from_template(cards, 'nav_page1_1', 'nav_btn', 'Monitoring', page1)
        cards['nav_page2_1'] = self._create_nb_from_template(cards, 'nav_page2_1', 'nav_btn', 'Prediction Explainer', page1)
        cards['nav_page3_1'] = self._create_nb_from_template(cards, 'nav_page3_1', 'nav_btn', 'Training Performance', page1)
        cards['nav_page4_1'] = self._create_nb_from_template(cards, 'nav_page4_1', 'nav_btn', 'Feature Importance', page1)
        if mdl_type == ModelType.REGRESSION:
            cards['live_r2'] = self._create_or_replace_card(cards, 'live_r2', insights_dsid, page1)
            cards['live_mae'] = self._create_or_replace_card(cards, 'live_mae', insights_dsid, page1)
            cards['live_mape'] = self._create_or_replace_card(cards, 'live_mape', insights_dsid, page1)
            cards['live_rmse'] = self._create_or_replace_card(cards, 'live_rmse', insights_dsid, page1)
            cards['live_history_1'] = self._create_or_replace_card(cards, 'live_history_1', insights_dsid, page1)
            cards['live_history_2'] = self._create_or_replace_card(cards, 'live_history_2', insights_dsid, page1)
        else:
            cards['live_accuracy'] = self._create_or_replace_card(cards, 'live_accuracy', insights_dsid, page1)
            cards['live_precision'] = self._create_or_replace_card(cards, 'live_precision', insights_dsid, page1)
            cards['live_recall'] = self._create_or_replace_card(cards, 'live_recall', insights_dsid, page1)
            cards['live_specificity'] = self._create_or_replace_card(cards, 'live_specificity', insights_dsid, page1)
            cards['live_f1'] = self._create_or_replace_card(cards, 'live_f1', insights_dsid, page1)
            cards['live_cm'] = self._create_or_replace_card(cards, 'live_cm', insights_dsid, page1)
            cards['live_history'] = self._create_or_replace_card(cards, 'live_history', insights_dsid, page1)
        cards['page1_h1'] = self._create_nb_from_template(cards, 'page1_h1', 'header', 'Prediction Accuracy', page1)
        cards['page1_h2'] = self._create_nb_from_template(cards, 'page1_h2', 'header', 'Data Drift', page1)
        cards['page1_blank'] = self._create_nb_from_template(cards, 'page1_blank', 'blank', '', page1)
        cards['target_drift_label'] = self._create_or_replace_card(cards, 'target_drift_label', insights_dsid, page1)
        cards['feature_drift_label'] = self._create_or_replace_card(cards, 'feature_drift_label', insights_dsid, page1)
        cards['target_drift'] = self._create_or_replace_card(cards, 'target_drift', insights_dsid, page1)
        cards['feature_drift'] = self._create_or_replace_card(cards, 'feature_drift', insights_dsid, page1)
        cards['drift_scatter'] = self._create_or_replace_card(cards, 'drift_scatter', insights_dsid, page1)
        cards['feature_drift_filter'] = self._create_or_replace_card(cards, 'feature_drift_filter', insights_dsid, page1)

        self.pbar.set_description_str('arranging cards on page...')
        layout1 = self._get_dashboard_layout(page1)
        if mdl_type == ModelType.REGRESSION:
            data = json.loads(
                t.page1_layout_r
                .replace('<LAYOUT_ID>', str(layout1))
                .replace('<PAGE_0>', str(page_id))
                .replace('<PAGE_1>', str(page1))
                .replace('<PAGE_2>', str(page2))
                .replace('<PAGE_3>', str(page3))
                .replace('<PAGE_4>', str(page4))
                .replace('<NAV_PAGE_0>', str(cards['nav_page0_1']))
                .replace('<NAV_PAGE_1>', str(cards['nav_page1_1']))
                .replace('<NAV_PAGE_2>', str(cards['nav_page2_1']))
                .replace('<NAV_PAGE_3>', str(cards['nav_page3_1']))
                .replace('<NAV_PAGE_4>', str(cards['nav_page4_1']))
                .replace('<HEADER_1>', str(cards['page1_h1']))
                .replace('<HEADER_2>', str(cards['page1_h2']))
                .replace('<PAGE1_BLANK>', str(cards['page1_blank']))
                .replace('<TARGET_DRIFT_LABEL>', str(cards['target_drift_label']))
                .replace('<FEATURE_DRIFT_LABEL>', str(cards['feature_drift_label']))
                .replace('<TARGET_DRIFT>', str(cards['target_drift']))
                .replace('<FEATURE_DRIFT>', str(cards['feature_drift']))
                .replace('<DRIFT_SCATTER>', str(cards['drift_scatter']))
                .replace('<FEATURE_DRIFT_FILTER>', str(cards['feature_drift_filter']))
                .replace('<LIVE_R2>', str(cards['live_r2']))
                .replace('<LIVE_MAE>', str(cards['live_mae']))
                .replace('<LIVE_MAPE>', str(cards['live_mape']))
                .replace('<LIVE_RMSE>', str(cards['live_rmse']))
                .replace('<LIVE_HISTORY_1>', str(cards['live_history_1']))
                .replace('<LIVE_HISTORY_2>', str(cards['live_history_2']))
            )
        else:
            data = json.loads(
                t.page1_layout_c
                .replace('<LAYOUT_ID>', str(layout1))
                .replace('<PAGE_0>', str(page_id))
                .replace('<PAGE_1>', str(page1))
                .replace('<PAGE_2>', str(page2))
                .replace('<PAGE_3>', str(page3))
                .replace('<PAGE_4>', str(page4))
                .replace('<NAV_PAGE_0>', str(cards['nav_page0_1']))
                .replace('<NAV_PAGE_1>', str(cards['nav_page1_1']))
                .replace('<NAV_PAGE_2>', str(cards['nav_page2_1']))
                .replace('<NAV_PAGE_3>', str(cards['nav_page3_1']))
                .replace('<NAV_PAGE_4>', str(cards['nav_page4_1']))
                .replace('<HEADER_1>', str(cards['page1_h1']))
                .replace('<HEADER_2>', str(cards['page1_h2']))
                .replace('<PAGE1_BLANK>', str(cards['page1_blank']))
                .replace('<TARGET_DRIFT_LABEL>', str(cards['target_drift_label']))
                .replace('<FEATURE_DRIFT_LABEL>', str(cards['feature_drift_label']))
                .replace('<TARGET_DRIFT>', str(cards['target_drift']))
                .replace('<FEATURE_DRIFT>', str(cards['feature_drift']))
                .replace('<DRIFT_SCATTER>', str(cards['drift_scatter']))
                .replace('<FEATURE_DRIFT_FILTER>', str(cards['feature_drift_filter']))
                .replace('<LIVE_ACCURACY>', str(cards['live_accuracy']))
                .replace('<LIVE_PRECISION>', str(cards['live_precision']))
                .replace('<LIVE_RECALL>', str(cards['live_recall']))
                .replace('<LIVE_SPECIFICITY>', str(cards['live_specificity']))
                .replace('<LIVE_F1>', str(cards['live_f1']))
                .replace('<LIVE_HISTORY>', str(cards['live_history']))
                .replace('<LIVE_CM>', str(cards['live_cm']))
            )
        self._add_dashboard_layout(layout1, data)
        #self.pbar.update(1)

        self.pbar.set_description_str('adding default filters...')
        col = [c for c in sorted(list(X_train.columns)) if c != '__INDEX__'][0]
        data = json.loads(
            t.page1_filter
            .replace('<NAME>', 'initial feature')
            .replace('<VALUE>', col)
            .replace('<DSID>', insights_dsid)
            .replace('<FEATURE_DRIFT_LABEL>', str(cards['feature_drift_label']))
            .replace('<FEATURE_DRIFT>', str(cards['feature_drift']))
            .replace('<FEATURE_DRIFT_FILTER>', str(cards['feature_drift_filter']))
        )
        self._save_page_filter(data, page1)
        #self.pbar.update(1)
        # endregion

        # region  Page 2 -- Prediction Explainer
        self.pbar.set_description_str('adding cards to Prediction Explainer...')
        cards['nav_page0_2'] = self._create_nb_from_template(cards, 'nav_page0_2', 'nav_btn_big', 'Overview', page2)
        cards['nav_page1_2'] = self._create_nb_from_template(cards, 'nav_page1_2', 'nav_btn', 'Monitoring', page2)
        cards['nav_page2_2'] = self._create_nb_from_template(cards, 'nav_page2_2', 'nav_btn','Prediction Explainer', page2)
        cards['nav_page3_2'] = self._create_nb_from_template(cards, 'nav_page3_2', 'nav_btn', 'Training Performance', page2)
        cards['nav_page4_2'] = self._create_nb_from_template(cards, 'nav_page4_2', 'nav_btn', 'Feature Importance', page2)
        cards['page2_h1'] = self._create_nb_from_template(cards, 'page2_h1', 'header', 'Feature Contributions', page2)
        cards['page2_h2'] = self._create_nb_from_template(cards, 'page2_h2', 'header', 'Partial Dependence', page2)
        cards['partial_obs_filter_1'] = self._create_or_replace_card(cards, 'partial_obs_filter_1', insights_dsid, page2)
        cards['partial_obs_filter_2'] = self._create_or_replace_card(cards, 'partial_obs_filter_2', insights_dsid, page2)
        cards['partial_feat_filter'] = self._create_or_replace_card(cards, 'partial_feat_filter', insights_dsid, page2)
        cards['obs_table'] = self._create_or_replace_card(cards, 'obs_table', insights_dsid, page2)
        cards['shap_waterfall'] = self._create_or_replace_card(cards, 'shap_waterfall', insights_dsid, page2)
        cards['partial'] = self._create_or_replace_card(cards, 'partial', insights_dsid, page2)

        self.pbar.set_description_str('arranging cards on page...')
        layout2 = self._get_dashboard_layout(page2)
        data = json.loads(
            t.page2_layout
            .replace('<LAYOUT_ID>', str(layout2))
            .replace('<PAGE_0>', str(page_id))
            .replace('<PAGE_1>', str(page1))
            .replace('<PAGE_2>', str(page2))
            .replace('<PAGE_3>', str(page3))
            .replace('<PAGE_4>', str(page4))
            .replace('<NAV_PAGE_0>', str(cards['nav_page0_2']))
            .replace('<NAV_PAGE_1>', str(cards['nav_page1_2']))
            .replace('<NAV_PAGE_2>', str(cards['nav_page2_2']))
            .replace('<NAV_PAGE_3>', str(cards['nav_page3_2']))
            .replace('<NAV_PAGE_4>', str(cards['nav_page4_2']))
            .replace('<HEADER_1>', str(cards['page2_h1']))
            .replace('<HEADER_2>', str(cards['page2_h2']))
            .replace('<PARTIAL_OBS_FILTER_1>', str(cards['partial_obs_filter_1']))
            .replace('<PARTIAL_OBS_FILTER_2>', str(cards['partial_obs_filter_2']))
            .replace('<PARTIAL_FEAT_FILTER>', str(cards['partial_feat_filter']))
            .replace('<OBS_TABLE>', str(cards['obs_table']))
            .replace('<SHAP_WATERFALL>', str(cards['shap_waterfall']))
            .replace('<PARTIAL>', str(cards['partial']))
        )
        self._add_dashboard_layout(layout2, data)
        #self.pbar.update(1)

        self.pbar.set_description_str('adding default filters...')
        col = [c for c in sorted(list(X_train.columns)) if c != '__INDEX__'][0]
        obs = str(X_pred['__INDEX__'][0])
        data = json.loads(
            t.page2_filter
            .replace('<NAME>', 'initial obs / feature')
            .replace('<VALUE_1>', obs)
            .replace('<VALUE_2>', col)
            .replace('<DSID>', insights_dsid)
            .replace('<PARTIAL_OBS_FILTER_1>', str(cards['partial_obs_filter_1']))
            .replace('<PARTIAL_OBS_FILTER_2>', str(cards['partial_obs_filter_2']))
            .replace('<PARTIAL_FEAT_FILTER>', str(cards['partial_feat_filter']))
            .replace('<OBS_TABLE>', str(cards['obs_table']))
            .replace('<SHAP_WATERFALL>', str(cards['shap_waterfall']))
            .replace('<PARTIAL>', str(cards['partial']))
        )
        self._save_page_filter(data, page2)
        #self.pbar.update(1)
        # endregion

        # region  Page 3 -- Training Performance
        self.pbar.set_description_str('adding cards to Training Performance...')
        cards['nav_page0_3'] = self._create_nb_from_template(cards, 'nav_page0_3', 'nav_btn_big', 'Overview', page3)
        cards['nav_page1_3'] = self._create_nb_from_template(cards, 'nav_page1_3', 'nav_btn', 'Monitoring', page3)
        cards['nav_page2_3'] = self._create_nb_from_template(cards, 'nav_page2_3', 'nav_btn', 'Prediction Explainer', page3)
        cards['nav_page3_3'] = self._create_nb_from_template(cards, 'nav_page3_3', 'nav_btn', 'Training Performance', page3)
        cards['nav_page4_3'] = self._create_nb_from_template(cards, 'nav_page4_3', 'nav_btn', 'Feature Importance', page3)
        cards['page3_h1'] = self._create_nb_from_template(cards, 'page3_h1', 'header', 'Training Accuracy', page3)
        if mdl_type == ModelType.REGRESSION:
            cards['train_r2'] = self._create_or_replace_card(cards, 'train_r2', insights_dsid, page3)
            cards['train_mae'] = self._create_or_replace_card(cards, 'train_mae', insights_dsid, page3)
            cards['train_mape'] = self._create_or_replace_card(cards, 'train_mape', insights_dsid, page3)
            cards['train_rmse'] = self._create_or_replace_card(cards, 'train_rmse', insights_dsid, page3)
        else:
            cards['page3_h2'] = self._create_nb_from_template(cards, 'page3_h2', 'header', 'Threshold Analysis', page3)
            cards['threshold_dropdown'] = self._create_or_replace_card(cards, 'threshold_dropdown', insights_dsid, page3)
            cards['train_accuracy'] = self._create_or_replace_card(cards, 'train_accuracy', insights_dsid, page3)
            cards['train_precision'] = self._create_or_replace_card(cards, 'train_precision', insights_dsid, page3)
            cards['train_recall'] = self._create_or_replace_card(cards, 'train_recall', insights_dsid, page3)
            cards['train_specificity'] = self._create_or_replace_card(cards, 'train_specificity', insights_dsid, page3)
            cards['train_f1'] = self._create_or_replace_card(cards, 'train_f1', insights_dsid, page3)
            cards['threshold_lines'] = self._create_or_replace_card(cards, 'threshold_lines', insights_dsid, page3)
            cards['threshold_table'] = self._create_or_replace_card(cards, 'threshold_table', insights_dsid, page3)
            cards['train_cm'] = self._create_or_replace_card(cards, 'train_cm', insights_dsid, page3)
            cards['roc_curve'] = self._create_or_replace_ddx(cards, 'roc_curve', insights_dsid, page3)
            cards['pr_curve'] = self._create_or_replace_ddx(cards, 'pr_curve', insights_dsid, page3)

        self.pbar.set_description_str('arranging cards on page...')
        layout3 = self._get_dashboard_layout(page3)
        if mdl_type == ModelType.REGRESSION:
            data = json.loads(
                t.page3_layout_r
                .replace('<LAYOUT_ID>', str(layout3))
                .replace('<PAGE_0>', str(page_id))
                .replace('<PAGE_1>', str(page1))
                .replace('<PAGE_2>', str(page2))
                .replace('<PAGE_3>', str(page3))
                .replace('<PAGE_4>', str(page4))
                .replace('<NAV_PAGE_0>', str(cards['nav_page0_3']))
                .replace('<NAV_PAGE_1>', str(cards['nav_page1_3']))
                .replace('<NAV_PAGE_2>', str(cards['nav_page2_3']))
                .replace('<NAV_PAGE_3>', str(cards['nav_page3_3']))
                .replace('<NAV_PAGE_4>', str(cards['nav_page4_3']))
                .replace('<HEADER_1>', str(cards['page3_h1']))
                .replace('<TRAIN_R2>', str(cards['train_r2']))
                .replace('<TRAIN_MAE>', str(cards['train_mae']))
                .replace('<TRAIN_MAPE>', str(cards['train_mape']))
                .replace('<TRAIN_RMSE>', str(cards['train_rmse']))
            )
        else:
            data = json.loads(
                t.page3_layout_c
                .replace('<LAYOUT_ID>', str(layout3))
                .replace('<PAGE_0>', str(page_id))
                .replace('<PAGE_1>', str(page1))
                .replace('<PAGE_2>', str(page2))
                .replace('<PAGE_3>', str(page3))
                .replace('<PAGE_4>', str(page4))
                .replace('<NAV_PAGE_0>', str(cards['nav_page0_3']))
                .replace('<NAV_PAGE_1>', str(cards['nav_page1_3']))
                .replace('<NAV_PAGE_2>', str(cards['nav_page2_3']))
                .replace('<NAV_PAGE_3>', str(cards['nav_page3_3']))
                .replace('<NAV_PAGE_4>', str(cards['nav_page4_3']))
                .replace('<HEADER_1>', str(cards['page3_h1']))
                .replace('<HEADER_2>', str(cards['page3_h2']))
                .replace('<TRAIN_ACCURACY>', str(cards['train_accuracy']))
                .replace('<TRAIN_PRECISION>', str(cards['train_precision']))
                .replace('<TRAIN_RECALL>', str(cards['train_recall']))
                .replace('<TRAIN_SPECIFICITY>', str(cards['train_specificity']))
                .replace('<TRAIN_F1>', str(cards['train_f1']))
                .replace('<TRAIN_CM>', str(cards['train_cm']))
                .replace('<THRESHOLD_DROPDOWN>', str(cards['threshold_dropdown']))
                .replace('<THRESHOLD_TABLE>', str(cards['threshold_table']))
                .replace('<THRESHOLD_LINES>', str(cards['threshold_lines']))
                .replace('<ROC_CURVE>', str(cards['roc_curve'][0]))  # <- these DDX bricks are (card_id, app_domain)
                .replace('<PR_CURVE>', str(cards['pr_curve'][0]))    # <- 
            )
        self._add_dashboard_layout(layout3, data)
        #self.pbar.update(1)

        if mdl_type != ModelType.REGRESSION:
            self.pbar.set_description_str('adding default filters...')
            data = json.loads(
                t.page3_filter
                .replace('<NAME>', 'init')
                .replace('<VALUE>', str(0.5))
                .replace('<DSID>', insights_dsid)
                .replace('<TRAIN_ACCURACY>', str(cards['train_accuracy']))
                .replace('<TRAIN_PRECISION>', str(cards['train_precision']))
                .replace('<TRAIN_RECALL>', str(cards['train_recall']))
                .replace('<TRAIN_SPECIFICITY>', str(cards['train_specificity']))
                .replace('<TRAIN_F1>', str(cards['train_f1']))
                .replace('<TRAIN_CM>', str(cards['train_cm']))
                .replace('<THRESHOLD_DROPDOWN>', str(cards['threshold_dropdown']))
            )
            self._save_page_filter(data, page3)
            #self.pbar.update(1)
        # endregion

        # region  Page 4 -- Feature Importance
        self.pbar.set_description_str('adding cards to Feature Importance...')
        cards['nav_page0_4'] = self._create_nb_from_template(cards, 'nav_page0_4', 'nav_btn_big', 'Overview', page4)
        cards['nav_page1_4'] = self._create_nb_from_template(cards, 'nav_page1_4', 'nav_btn', 'Monitoring', page4)
        cards['nav_page2_4'] = self._create_nb_from_template(cards, 'nav_page2_4', 'nav_btn', 'Prediction Explainer', page4)
        cards['nav_page3_4'] = self._create_nb_from_template(cards, 'nav_page3_4', 'nav_btn', 'Training Performance', page4)
        cards['nav_page4_4'] = self._create_nb_from_template(cards, 'nav_page4_4', 'nav_btn', 'Feature Importance', page4)
        cards['page4_h1'] = self._create_nb_from_template(cards, 'page4_h1', 'header', 'Overall Feature Importance', page4)
        cards['page4_h2'] = self._create_nb_from_template(cards, 'page4_h2', 'header', 'Feature Dependence', page4)
        cards['page4_h3'] = self._create_nb_from_template(cards, 'page4_h3', 'header', 'Feature Correlation', page4)
        cards['shap_summ'] = self._create_or_replace_card(cards, 'shap_summ', insights_dsid, page4)
        cards['shap_dep'] = self._create_or_replace_card(cards, 'shap_dep', insights_dsid, page4)
        cards['shap_dep_filter'] = self._create_or_replace_card(cards, 'shap_dep_filter', insights_dsid, page4)
        cards['vif'] = self._create_or_replace_card(cards, 'vif', insights_dsid, page4)
        cards['corr_matrix'] = self._create_or_replace_card(cards, 'corr_matrix', insights_dsid, page4)


        self.pbar.set_description_str('arranging cards on page...')
        layout4 = self._get_dashboard_layout(page4)
        data = json.loads(
            t.page4_layout
            .replace('<LAYOUT_ID>', str(layout4))
            .replace('<PAGE_0>', str(page_id))
            .replace('<PAGE_1>', str(page1))
            .replace('<PAGE_2>', str(page2))
            .replace('<PAGE_3>', str(page3))
            .replace('<PAGE_4>', str(page4))
            .replace('<NAV_PAGE_0>', str(cards['nav_page0_4']))
            .replace('<NAV_PAGE_1>', str(cards['nav_page1_4']))
            .replace('<NAV_PAGE_2>', str(cards['nav_page2_4']))
            .replace('<NAV_PAGE_3>', str(cards['nav_page3_4']))
            .replace('<NAV_PAGE_4>', str(cards['nav_page4_4']))
            .replace('<HEADER_1>', str(cards['page4_h1']))
            .replace('<HEADER_2>', str(cards['page4_h2']))
            .replace('<HEADER_3>', str(cards['page4_h3']))
            .replace('<SHAP_SUMM>', str(cards['shap_summ']))
            .replace('<SHAP_DEP>', str(cards['shap_dep']))
            .replace('<SHAP_DEP_FILTER>', str(cards['shap_dep_filter']))
            .replace('<CORR>', str(cards['corr_matrix']))
            .replace('<VIF>', str(cards['vif']))
        )    
        self._add_dashboard_layout(layout4, data)
        #self.pbar.update(1)

        self.pbar.set_description_str('adding default filters...')
        col = [c for c in sorted(list(X_train.columns)) if c != '__INDEX__'][0]
        data = json.loads(
            t.page4_filter
            .replace('<NAME>', 'init')
            .replace('<VALUE>', col)
            .replace('<DSID>', insights_dsid)
            .replace('<SHAP_DEP>', str(cards['shap_dep']))
            .replace('<SHAP_DEP_FILTER>', str(cards['shap_dep_filter']))
        )
        self._save_page_filter(data, page4)
        #self.pbar.update(1)
        # endregion

        # region  save configuration
        if save_config:
            filename = model_name.replace(' ', '_').replace('-', '_') + '.config'
            self.pbar.set_description_str('saving conifg...')
            config = {
                'insights_dsid': insights_dsid,
                'page_id': page_id,
                'pages': pages,
                'cards': cards,
                'theme': theme,
                'monitor_dsids': monitor_dsids,
            }
            with open(filename, 'wb') as f:
                pickle.dump(config, f)
            #self.pbar.update(1)

        self.pbar.set_description_str('all done!')
        #endregion

        self.pbar.close()


color_notes = '''
    menu_focus  5
    menu_idle   2
    header      4
    cm theme    select from available
    drift bars  focus, idle
    roc curve can be similar^
    metric history ???
    corr matrix select theme
    VIF could be set to `header`

    some are hard-coded to red/green

    DARKER
    DARK
    LIGHT
    HEATMAP_THEME

    theme = {
        'darker': '#123456',
        'dark': '#123456',
        'light': '#123456',
        'heatmap': 'gradient-2',
    }
'''
